"""Async transport to the same pinned Rust engine on desktop and in the browser."""
from __future__ import annotations
import asyncio
import json
from pathlib import Path
import sys


class EngineClient:
    def __init__(self):
        self.closed = False
        self.pending = {}
        self.next_id = 0
        self.browser = sys.platform == "emscripten"
        if self.browser:
            import flet_js
            from js import Object, URL, Worker
            from pyodide.ffi import create_proxy, to_js
            url = URL.new("smart/worker.js", flet_js.documentUrl).href
            self.worker = Worker.new(url, to_js({"type": "module"}, dict_converter=Object.fromEntries))
            self.message_proxy = create_proxy(self._message)
            self.error_proxy = create_proxy(self._error)
            self.worker.onmessage = self.message_proxy
            self.worker.onerror = self.error_proxy
        else:
            import subprocess
            import threading
            root = Path(__file__).resolve().parents[2]
            binary = root / "build/rust-target/release/trainer-engine"
            if not binary.exists():
                raise RuntimeError("Build the smart engine first: python tools/build_smart_engine.py")
            self.lock = threading.Lock()
            self.process = subprocess.Popen([str(binary), str(root / "vendor/smart_engine/models/v89w.bin")],
                                            stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                            stderr=subprocess.PIPE, text=True, bufsize=1)

    def _message(self, event):
        response = json.loads(str(event.data))
        future = self.pending.pop(response["id"], None)
        if future is None or future.done():
            return
        if response["ok"]:
            future.set_result(response["result"])
        else:
            future.set_exception(RuntimeError(response["error"]))

    def _error(self, event):
        for future in self.pending.values():
            if not future.done():
                future.set_exception(RuntimeError(str(event.message)))
        self.pending.clear()

    def _native_request(self, encoded):
        with self.lock:
            self.process.stdin.write(encoded + "\n")
            self.process.stdin.flush()
            line = self.process.stdout.readline()
            if not line:
                raise RuntimeError("Smart engine stopped: " + self.process.stderr.read()[:500])
            response = json.loads(line)
            if not response["ok"]:
                raise RuntimeError(response["error"])
            return response["result"]

    async def request(self, **request):
        if self.closed:
            raise RuntimeError("Smart engine has been closed")
        if not self.browser:
            return await asyncio.to_thread(self._native_request, json.dumps(request))
        self.next_id += 1
        request["id"] = self.next_id
        future = asyncio.get_running_loop().create_future()
        self.pending[self.next_id] = future
        self.worker.postMessage(json.dumps(request))
        try:
            return await future
        finally:
            self.pending.pop(request["id"], None)

    def close(self):
        if self.closed:
            return
        self.closed = True
        if self.browser:
            self.worker.terminate()
            for future in self.pending.values():
                if not future.done():
                    future.set_exception(RuntimeError("Smart engine has been closed"))
            self.pending.clear()
            self.message_proxy.destroy()
            self.error_proxy.destroy()
        else:
            self.process.terminate()
            self.process.wait(timeout=5)
            for stream in (self.process.stdin, self.process.stdout, self.process.stderr):
                stream.close()

    def __del__(self):
        if hasattr(self, "process") and not self.closed:
            self.close()

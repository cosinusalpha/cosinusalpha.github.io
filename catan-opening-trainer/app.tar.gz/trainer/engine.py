"""Catanatron adapter: opening transactions and independent game continuations."""

from __future__ import annotations

import asyncio
import copy
import random
import time
from collections import Counter
from dataclasses import dataclass, field
from typing import Callable

from catanatron import Game
from catanatron.models.enums import Action, ActionPrompt, ActionType, FastBuildingType, RESOURCES, SETTLEMENT, CITY, NodeRef
from catanatron.models.map import (
    BASE_MAP_TEMPLATE, BASE_NUMBERS_IN_SPIRAL_ORDER, CatanMap, initialize_tiles, PORT_DIRECTION_TO_NODEREFS,
)
from catanatron.models.player import Color
from catanatron.models.spiral import spiral_land_coordinates
from catanatron.players.minimax import AlphaBetaPlayer
from catanatron.state_functions import player_key
from trainer.ai import decide_cooperatively
from trainer.smart import EngineClient


CORNERS = ((2, -2, 0), (2, 0, -2), (0, 2, -2),
           (-2, 2, 0), (-2, 0, 2), (0, -2, 2))
MAX_TURNS = 600
MAX_ACTIONS = 30_000
MAX_SIMULATIONS = 1000
AI_DEPTH = 2
AI_NAME = "v89w · Tiefe 2 · Spielerhandel und Entwicklungskarten"
DEV_NAMES = ("Ritter", "Erfindung", "Monopol", "Straßenbau", "Siegpunkt")
COLOR_NAMES = {Color.RED: "Rot", Color.BLUE: "Blau", Color.ORANGE: "Orange", Color.WHITE: "Weiß"}
RESOURCE_NAMES = {"WOOD": "Holz", "BRICK": "Lehm", "SHEEP": "Wolle", "WHEAT": "Getreide", "ORE": "Erz"}


class TrainingGame(Game):
    """The official victory condition applies on the winning player's turn."""

    def winning_color(self):
        color = self.state.colors[self.state.current_turn_index]
        key = player_key(self.state, color)
        return color if self.state.player_state[f"{key}_ACTUAL_VICTORY_POINTS"] >= self.vps_to_win else None

    def copy(self):
        result = super().copy()
        result.__class__ = TrainingGame
        return result


def create_game(seed: int, seat: int | None = None, random_ports: bool = False):
    rng = random.Random(seed)
    # Fixed ports use the BASE template's stable resource order; random ports
    # follow the variable-board option in the supplied 3D Almanac.
    ports = None if random_ports else list(reversed(BASE_MAP_TEMPLATE.port_resources))
    tiles = initialize_tiles(BASE_MAP_TEMPLATE, shuffled_port_resources_param=ports,
                             number_placement="random", rng=rng)
    corner = rng.choice(CORNERS)
    number_iter = iter(BASE_NUMBERS_IN_SPIRAL_ORDER)
    for coord in spiral_land_coordinates(tiles, corner):
        tile = tiles[coord]
        tile.number = next(number_iter) if tile.resource is not None else None
    # These players identify seats in the opening mirror. Rust chooses every
    # actual bot move; the mirror never calls their Python decision methods.
    game = TrainingGame([AlphaBetaPlayer(c, AlphaBetaPlayer.Params(depth=AI_DEPTH)) for c in Color], seed=seed ^ 0x19C47,
                        catan_map=CatanMap.from_tiles(tiles))
    seat = rng.randrange(4) if seat is None else seat
    if seat not in range(4):
        raise ValueError("Startplatz muss zwischen 1 und 4 liegen.")
    return game, game.state.colors[seat], seat, corner


@dataclass(frozen=True)
class BoardSnapshot:
    """Only the changing board pieces; the session already owns the static map."""

    roads: tuple[tuple[tuple[int, int], Color], ...]
    buildings: tuple[tuple[int, tuple[Color, FastBuildingType]], ...]
    robber_coordinate: tuple[int, int, int]

    @classmethod
    def from_board(cls, board):
        return cls(
            tuple(sorted((edge, color) for edge, color in board.roads.items() if edge[0] < edge[1])),
            tuple(sorted(board.buildings.items())),
            tuple(board.robber_coordinate),
        )

    @classmethod
    def from_engine(cls, result, catan_map, colors):
        coord = next(coord for coord, tile in catan_map.land_tiles.items() if tile.id == result["robber"])
        return cls(tuple(sorted((tuple(sorted((a, b))), colors[seat]) for a, b, seat in result["roads"])),
                   tuple(sorted((node, (colors[seat], CITY if city else SETTLEMENT))
                                for node, seat, city in result["buildings"])), coord)


@dataclass(frozen=True)
class Activity:
    cards_bought: tuple[int, ...] = (0, 0, 0, 0, 0)
    cards_played: tuple[int, ...] = (0, 0, 0, 0)
    player_trades: int = 0
    bank_trades: int = 0
    offers: int = 0

    @classmethod
    def from_engine(cls, data):
        return cls(tuple(data["cards_bought"]), tuple(data["cards_played"]),
                   data["player_trades"], data["bank_trades"], data["offers"])


@dataclass(frozen=True)
class Sample:
    index: int
    seed: int
    winner: Color | None
    turns: int
    seconds: float
    points: tuple[int, ...]
    board: BoardSnapshot
    activity: Activity = field(default_factory=Activity)


@dataclass
class Results:
    samples: list[Sample] = field(default_factory=list)

    @property
    def wins(self):
        return Counter(s.winner for s in self.samples if s.winner is not None)

    @property
    def decided(self):
        return sum(s.winner is not None for s in self.samples)

    @property
    def limited(self):
        return len(self.samples) - self.decided


class OpeningSession:
    def __init__(self, seed: int | None = None, seat: int | None = None, random_ports=False):
        self.seed = random.randrange(1, 2**31) if seed is None else seed
        self.random_ports = random_ports
        self.game, self.human, self.seat, self.corner = create_game(self.seed, seat, random_ports)
        self.selected_node: int | None = None
        self.selected_edge: tuple[int, int] | None = None
        self.history: list[TrainingGame] = []
        self.results = Results()
        self.cancelled = False
        self.client = None

    def close(self):
        self.cancelled = True
        if self.client:
            self.client.close()
            self.client = None

    def engine_client(self):
        if self.client is None:
            self.client = EngineClient()
        return self.client

    def engine_position(self):
        """Preserve the exact existing board codes, topology and opening choices.

        Python keeps the small opening mirror for touch previews and undo. The
        Rust engine validates the opening and owns every complete continuation.
        """
        m = self.game.state.board.map
        resource = lambda r: -1 if r is None else RESOURCES.index(r)
        tiles = [{"resource": resource(m.tiles_by_id[i].resource), "number": m.tiles_by_id[i].number or 0,
                  "nodes": [m.tiles_by_id[i].nodes[ref] for ref in NodeRef]} for i in range(19)]
        ports = [{"resource": resource(p.resource),
                  "nodes": [p.nodes[ref] for ref in PORT_DIRECTION_TO_NODEREFS[p.direction]]}
                 for p in m.ports_by_id.values()]
        edges = sorted({tuple(sorted(edge)) for tile in m.land_tiles.values() for edge in tile.edges.values()})
        moves = []
        for record in self.game.state.action_records:
            a = record.action
            if a.action_type == ActionType.BUILD_SETTLEMENT:
                moves.append(("BUILD_SETTLEMENT", a.value, -1, -1))
            elif a.action_type == ActionType.BUILD_ROAD:
                moves.append(("BUILD_ROAD", edges.index(tuple(sorted(a.value))), -1, -1))
            else:
                raise ValueError("The opening contains a non-placement action")
        return {"op": "opening", "seed": str(self.seed), "board": {"tiles": tiles, "ports": ports}, "moves": moves}, edges

    async def sync_engine(self):
        position, edges = self.engine_position()
        result = await self.engine_client().request(**position)
        if result["current_player"] != self.game.state.color_to_index[self.game.state.current_color()]:
            raise RuntimeError("Opening turn differs between engines")
        if result["initial_phase"] != self.game.state.is_initial_build_phase:
            raise RuntimeError("Opening phase differs between engines")
        for i in range(4):
            hand = [self.game.state.player_state[f"P{i}_{r}_IN_HAND"] for r in RESOURCES]
            if result["hands"][i] != hand:
                raise RuntimeError("Opening resources differ between engines")
        return edges

    @property
    def complete(self):
        return not self.game.state.is_initial_build_phase

    @property
    def human_turn(self):
        return not self.complete and self.game.state.current_color() == self.human

    @property
    def legal_nodes(self):
        if not self.human_turn:
            return []
        return [a.value for a in self.game.playable_actions if a.action_type == ActionType.BUILD_SETTLEMENT]

    @property
    def legal_roads(self):
        if self.selected_node is None or not self.human_turn:
            return []
        preview = self.game.copy()
        preview.execute(Action(self.human, ActionType.BUILD_SETTLEMENT, self.selected_node))
        return [a.value for a in preview.playable_actions if a.action_type == ActionType.BUILD_ROAD]

    def select_node(self, node):
        if node not in self.legal_nodes:
            raise ValueError("Diese Kreuzung ist nicht frei oder verletzt die Abstandsregel.")
        self.selected_node = node
        self.selected_edge = None

    def select_road(self, edge):
        edge = tuple(sorted(edge))
        if edge not in self.legal_roads:
            raise ValueError("Die Straße muss an die gewählte Siedlung angrenzen.")
        self.selected_edge = edge

    def commit(self):
        if self.selected_node is None or self.selected_edge is None:
            raise ValueError("Wähle zuerst eine Siedlung und eine Straße.")
        if self.selected_node not in self.legal_nodes or self.selected_edge not in self.legal_roads:
            raise ValueError("Die Platzierung ist nicht mehr verfügbar.")
        self.history.append(copy.deepcopy(self.game))
        self.game.execute(Action(self.human, ActionType.BUILD_SETTLEMENT, self.selected_node))
        self.game.execute(Action(self.human, ActionType.BUILD_ROAD, self.selected_edge))
        self.selected_node = self.selected_edge = None
        self.results = Results()

    def undo(self):
        if not self.history:
            return False
        self.game = self.history.pop()
        self.selected_node = self.selected_edge = None
        self.results = Results()
        return True

    async def advance_bots(self, on_step: Callable | None = None):
        while not self.complete and not self.human_turn:
            edges = await self.sync_engine()
            decision = await self.engine_client().request(op="choose")
            kind, value, _, _ = decision["action"]
            if kind == "BUILD_ROAD":
                value = edges[value]
            self.game.execute(Action(self.game.state.current_color(), ActionType(kind), value))
            if on_step:
                on_step()
            await asyncio.sleep(0.001)

    def production(self, include_selected=False):
        nodes = list(self.game.state.buildings_by_color[self.human][SETTLEMENT])
        if include_selected and self.selected_node is not None:
            nodes.append(self.selected_node)
        result = dict.fromkeys(RESOURCES, 0)
        for n in nodes:
            for tile in self.game.state.board.map.adjacent_tiles[n]:
                if tile.resource:
                    result[tile.resource] += 6 - abs(7 - tile.number)
        return result

    def starting_resources(self):
        key = player_key(self.game.state, self.human)
        return {r: self.game.state.player_state[f"{key}_{r}_IN_HAND"] for r in RESOURCES}

    def simulation_game(self, index):
        if not self.complete:
            raise ValueError("Die Eröffnung ist noch nicht fertig.")
        # Game.copy deliberately shares the RNG; deep-copy the opening here
        # instead so neither simulations nor undo alter another run.
        game = copy.deepcopy(self.game)
        seed = (self.seed * 1_000_003 + index * 97_409 + 0xCA7A) & 0xFFFFFFFFFFFFFFFF
        game.random = random.Random(seed)
        game.state.random = game.random
        game.random.shuffle(game.state.development_listdeck)
        return game, seed

    async def simulate(self, count: int, on_progress: Callable | None = None,
                       max_turns=MAX_TURNS, max_actions=MAX_ACTIONS):
        if not 1 <= count <= MAX_SIMULATIONS:
            raise ValueError(f"Wähle 1 bis {MAX_SIMULATIONS} Simulationen.")
        if not self.complete:
            raise ValueError("Platziere zuerst beide Siedlungen und Straßen.")
        self.cancelled = False
        await self.sync_engine()
        initial = len(self.results.samples)
        for offset in range(count):
            index = initial + offset
            seed = (self.seed * 1_000_003 + index * 97_409 + 0xCA7A) & 0xFFFFFFFFFFFFFFFF
            started = time.perf_counter()
            last_update = started
            result = await self.engine_client().request(op="begin", seed=str(seed), max_turns=max_turns, max_actions=max_actions)
            while not result["done"]:
                if self.cancelled:
                    return
                result = await self.engine_client().request(op="step", count=8)
                if self.cancelled:
                    return
                now = time.perf_counter()
                if on_progress and now - last_update >= 0.2:
                    on_progress(offset, count, result["turns"])
                    last_update = now
                await asyncio.sleep(0.001)
            if self.cancelled:
                return
            colors = self.game.state.colors
            winner = colors[result["winner"]] if result["winner"] >= 0 else None
            self.results.samples.append(Sample(index, seed, winner, result["turns"],
                                               time.perf_counter() - started, tuple(result["points"]),
                                               BoardSnapshot.from_engine(result, self.game.state.board.map, colors),
                                               Activity.from_engine(result["activity"])))
            if on_progress:
                on_progress(offset + 1, count, 0)
            await asyncio.sleep(0.001)

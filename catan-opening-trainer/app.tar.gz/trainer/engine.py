"""Catanatron adapter: opening transactions and independent game continuations."""

from __future__ import annotations

import asyncio
import copy
import random
import time
from collections import Counter
from dataclasses import dataclass, field
from typing import Callable

from catanatron import Game
from catanatron.models.enums import Action, ActionPrompt, ActionType, FastBuildingType, RESOURCES, SETTLEMENT
from catanatron.models.map import (
    BASE_MAP_TEMPLATE, BASE_NUMBERS_IN_SPIRAL_ORDER, CatanMap, initialize_tiles,
)
from catanatron.models.player import Color
from catanatron.models.spiral import spiral_land_coordinates
from catanatron.players.minimax import AlphaBetaPlayer
from catanatron.state_functions import player_key
from trainer.ai import decide_cooperatively


CORNERS = ((2, -2, 0), (2, 0, -2), (0, 2, -2),
           (-2, 2, 0), (-2, 0, 2), (0, -2, 2))
MAX_TURNS = 600
MAX_ACTIONS = 30_000
MAX_SIMULATIONS = 1000
AI_DEPTH = 2
COLOR_NAMES = {Color.RED: "Rot", Color.BLUE: "Blau", Color.ORANGE: "Orange", Color.WHITE: "Weiß"}
RESOURCE_NAMES = {"WOOD": "Holz", "BRICK": "Lehm", "SHEEP": "Wolle", "WHEAT": "Getreide", "ORE": "Erz"}


class TrainingGame(Game):
    """The official victory condition applies on the winning player's turn."""

    def winning_color(self):
        color = self.state.colors[self.state.current_turn_index]
        key = player_key(self.state, color)
        return color if self.state.player_state[f"{key}_ACTUAL_VICTORY_POINTS"] >= self.vps_to_win else None

    def copy(self):
        result = super().copy()
        result.__class__ = TrainingGame
        return result


def create_game(seed: int, seat: int | None = None, random_ports: bool = False):
    rng = random.Random(seed)
    # Fixed ports use the BASE template's stable resource order; random ports
    # follow the variable-board option in the supplied 3D Almanac.
    ports = None if random_ports else list(reversed(BASE_MAP_TEMPLATE.port_resources))
    tiles = initialize_tiles(BASE_MAP_TEMPLATE, shuffled_port_resources_param=ports,
                             number_placement="random", rng=rng)
    corner = rng.choice(CORNERS)
    number_iter = iter(BASE_NUMBERS_IN_SPIRAL_ORDER)
    for coord in spiral_land_coordinates(tiles, corner):
        tile = tiles[coord]
        tile.number = next(number_iter) if tile.resource is not None else None
    game = TrainingGame([AlphaBetaPlayer(c, AlphaBetaPlayer.Params(depth=AI_DEPTH)) for c in Color], seed=seed ^ 0x19C47,
                        catan_map=CatanMap.from_tiles(tiles))
    seat = rng.randrange(4) if seat is None else seat
    if seat not in range(4):
        raise ValueError("Startplatz muss zwischen 1 und 4 liegen.")
    return game, game.state.colors[seat], seat, corner


@dataclass(frozen=True)
class BoardSnapshot:
    """Only the changing board pieces; the session already owns the static map."""

    roads: tuple[tuple[tuple[int, int], Color], ...]
    buildings: tuple[tuple[int, tuple[Color, FastBuildingType]], ...]
    robber_coordinate: tuple[int, int, int]

    @classmethod
    def from_board(cls, board):
        return cls(
            tuple((edge, color) for edge, color in board.roads.items() if edge[0] < edge[1]),
            tuple(board.buildings.items()),
            tuple(board.robber_coordinate),
        )


@dataclass(frozen=True)
class Sample:
    index: int
    seed: int
    winner: Color | None
    turns: int
    seconds: float
    points: tuple[int, ...]
    board: BoardSnapshot


@dataclass
class Results:
    samples: list[Sample] = field(default_factory=list)

    @property
    def wins(self):
        return Counter(s.winner for s in self.samples if s.winner is not None)

    @property
    def decided(self):
        return sum(s.winner is not None for s in self.samples)

    @property
    def limited(self):
        return len(self.samples) - self.decided


class OpeningSession:
    def __init__(self, seed: int | None = None, seat: int | None = None, random_ports=False):
        self.seed = random.randrange(1, 2**31) if seed is None else seed
        self.random_ports = random_ports
        self.game, self.human, self.seat, self.corner = create_game(self.seed, seat, random_ports)
        self.selected_node: int | None = None
        self.selected_edge: tuple[int, int] | None = None
        self.history: list[TrainingGame] = []
        self.results = Results()
        self.cancelled = False

    @property
    def complete(self):
        return not self.game.state.is_initial_build_phase

    @property
    def human_turn(self):
        return not self.complete and self.game.state.current_color() == self.human

    @property
    def legal_nodes(self):
        if not self.human_turn:
            return []
        return [a.value for a in self.game.playable_actions if a.action_type == ActionType.BUILD_SETTLEMENT]

    @property
    def legal_roads(self):
        if self.selected_node is None or not self.human_turn:
            return []
        preview = self.game.copy()
        preview.execute(Action(self.human, ActionType.BUILD_SETTLEMENT, self.selected_node))
        return [a.value for a in preview.playable_actions if a.action_type == ActionType.BUILD_ROAD]

    def select_node(self, node):
        if node not in self.legal_nodes:
            raise ValueError("Diese Kreuzung ist nicht frei oder verletzt die Abstandsregel.")
        self.selected_node = node
        self.selected_edge = None

    def select_road(self, edge):
        edge = tuple(sorted(edge))
        if edge not in self.legal_roads:
            raise ValueError("Die Straße muss an die gewählte Siedlung angrenzen.")
        self.selected_edge = edge

    def commit(self):
        if self.selected_node is None or self.selected_edge is None:
            raise ValueError("Wähle zuerst eine Siedlung und eine Straße.")
        if self.selected_node not in self.legal_nodes or self.selected_edge not in self.legal_roads:
            raise ValueError("Die Platzierung ist nicht mehr verfügbar.")
        self.history.append(copy.deepcopy(self.game))
        self.game.execute(Action(self.human, ActionType.BUILD_SETTLEMENT, self.selected_node))
        self.game.execute(Action(self.human, ActionType.BUILD_ROAD, self.selected_edge))
        self.selected_node = self.selected_edge = None
        self.results = Results()

    def undo(self):
        if not self.history:
            return False
        self.game = self.history.pop()
        self.selected_node = self.selected_edge = None
        self.results = Results()
        return True

    async def advance_bots(self, on_step: Callable | None = None):
        while not self.complete and not self.human_turn:
            self.game.execute(await decide_cooperatively(self.game))
            if on_step:
                on_step()
            await asyncio.sleep(0.001)

    def production(self, include_selected=False):
        nodes = list(self.game.state.buildings_by_color[self.human][SETTLEMENT])
        if include_selected and self.selected_node is not None:
            nodes.append(self.selected_node)
        result = dict.fromkeys(RESOURCES, 0)
        for n in nodes:
            for tile in self.game.state.board.map.adjacent_tiles[n]:
                if tile.resource:
                    result[tile.resource] += 6 - abs(7 - tile.number)
        return result

    def starting_resources(self):
        key = player_key(self.game.state, self.human)
        return {r: self.game.state.player_state[f"{key}_{r}_IN_HAND"] for r in RESOURCES}

    def simulation_game(self, index):
        if not self.complete:
            raise ValueError("Die Eröffnung ist noch nicht fertig.")
        # Game.copy deliberately shares the RNG; deep-copy the opening here
        # instead so neither simulations nor undo alter another run.
        game = copy.deepcopy(self.game)
        seed = (self.seed * 1_000_003 + index * 97_409 + 0xCA7A) & 0xFFFFFFFFFFFFFFFF
        game.random = random.Random(seed)
        game.state.random = game.random
        game.random.shuffle(game.state.development_listdeck)
        return game, seed

    async def simulate(self, count: int, on_progress: Callable | None = None,
                       max_turns=MAX_TURNS, max_actions=MAX_ACTIONS):
        if not 1 <= count <= MAX_SIMULATIONS:
            raise ValueError(f"Wähle 1 bis {MAX_SIMULATIONS} Simulationen.")
        if not self.complete:
            raise ValueError("Platziere zuerst beide Siedlungen und Straßen.")
        self.cancelled = False
        initial = len(self.results.samples)
        for offset in range(count):
            index = initial + offset
            game, seed = self.simulation_game(index)
            started = time.perf_counter()
            last_update = started
            last_yield = started
            actions = 0
            while game.winning_color() is None and game.state.num_turns < max_turns and actions < max_actions:
                if self.cancelled:
                    return
                action = await decide_cooperatively(game, lambda: self.cancelled)
                if self.cancelled:
                    return
                game.execute(action)
                actions += 1
                # No action history is needed for continuations or AlphaBeta.
                game.state.action_records.clear()
                now = time.perf_counter()
                if on_progress and now - last_update >= 0.2:
                    on_progress(offset, count, game.state.num_turns)
                    last_update = now
                if now - last_yield >= 0.012:
                    await asyncio.sleep(0.001)
                    last_yield = time.perf_counter()
            if self.cancelled:
                return
            points = tuple(game.state.player_state[f"{player_key(game.state, c)}_ACTUAL_VICTORY_POINTS"]
                           for c in game.state.colors)
            self.results.samples.append(Sample(index, seed, game.winning_color(), game.state.num_turns,
                                               time.perf_counter() - started, points,
                                               BoardSnapshot.from_board(game.state.board)))
            if on_progress:
                on_progress(offset + 1, count, 0)
            await asyncio.sleep(0.001)

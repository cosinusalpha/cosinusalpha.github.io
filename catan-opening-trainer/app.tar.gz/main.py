"""Run with `flet run src/main.py`; publish with `python tools/build_web.py`."""

from __future__ import annotations

import asyncio
import math
from collections import Counter
import flet as ft
import flet.canvas as cv

from catanatron.models.enums import SETTLEMENT
from trainer.engine import OpeningSession, COLOR_NAMES, RESOURCE_NAMES, MAX_SIMULATIONS, AI_NAME, DEV_NAMES
from trainer.board import BoardGeometry
from trainer.view import BACKGROUND, PANEL, MUTED, INK, ACCENT, COLORS, board_shapes, opening_shapes, resource_chips


class TrainerApp:
    def __init__(self, page: ft.Page):
        self.page = page
        self.session = OpeningSession()
        self.busy = False
        self.previous = None
        self.width = self.board_width()
        self.geometry = BoardGeometry(self.session.game.state.board.map, self.width)
        self.canvas = cv.Canvas(width=self.width, height=self.geometry.height)
        self.board_touch = ft.GestureDetector(content=self.canvas, on_tap_up=self.tap)
        self.pips = ft.Switch(label="Wahrscheinlichkeitspunkte", value=True,
                              active_color=ACCENT, label_text_style=ft.TextStyle(size=13, color=INK),
                              on_change=self.toggle_pips)
        self.node_pips = ft.Switch(label="Punktesumme an Kreuzungen", value=False,
                                   active_color=ACCENT, label_text_style=ft.TextStyle(size=13, color=INK),
                                   on_change=self.toggle_pips)
        self.node_pips_hint = ft.Text("Summe der angrenzenden Würfelpunkte · erwartete Rohstoffe pro 36 Würfe",
                                      size=11, color=MUTED, visible=False)
        self.status = ft.Text(size=16, weight=ft.FontWeight.BOLD, color=INK)
        self.detail = ft.Text(size=12, color=MUTED)
        self.error = ft.Text(size=12, color="#F17F77", visible=False)
        self.progress = ft.ProgressBar(value=0, color=ACCENT, bgcolor="#283C49", visible=False)
        self.progress_text = ft.Text(size=12, color=MUTED, visible=False)
        self.players = ft.Row(wrap=True, spacing=12)
        self.production = ft.Row(wrap=True, spacing=6, run_spacing=6)
        self.start_cards = ft.Text(size=12, color=MUTED)
        self.victory_preview = ft.Text(size=18, color=ACCENT, weight=ft.FontWeight.BOLD)
        self.victory_panel = ft.Container(ft.Column([
            ft.Text("Runden bis 10 Siegpunkte", size=14, color=INK, weight=ft.FontWeight.BOLD),
            self.victory_preview,
            ft.Text("Rohstoff-Schätzwert · 1 Runde = 4 Spielerzüge", size=11, color=MUTED),
            ft.ExpansionTile(title=ft.Text("Annahmen und Berechnung", size=12, color=MUTED), controls=[
                ft.Text("Fester Vergleichsplan ab 2 Start-Siedlungen: 4 weitere Siedlungen, 4 Stadtausbauten "
                        "und 8 zusätzliche Straßen ergeben 10 Siegpunkte. Bedarf: 12 Holz, 12 Lehm, 4 Wolle, "
                        "12 Getreide, 12 Erz. Startkarten und Bank-/Start-Hafenhandel zählen mit.\n"
                        "Gerechnet wird mit der durchschnittlichen Startproduktion, auch während des Ausbaus. "
                        "Spätere Produktionszuwächse, freie Bauplätze, Mitspieler, Räuber, Kartenlimit und Sonderpunkte "
                        "werden nicht eingerechnet. Ein Vergleichswert für Eröffnungen, keine Prognose der Spieldauer.",
                        size=11, color=MUTED),
            ]),
        ], spacing=6), padding=14, bgcolor=PANEL, border_radius=14)
        self.result_title = ft.Text(size=20, color=INK, weight=ft.FontWeight.BOLD)
        self.result_rows = ft.Column(spacing=8)
        self.sample_rows = ft.Column(spacing=6)
        self.sample_picker = ft.Dropdown(label="Endstand einer Partie", dense=True, text_size=13,
                                         on_select=self.select_sample)
        self.final_title = ft.Text(size=16, color=INK, weight=ft.FontWeight.BOLD)
        self.final_detail = ft.Text(size=12, color=MUTED)
        self.final_activity = ft.Text(size=12, color=MUTED)
        self.final_awards = ft.Column(spacing=6)
        self.final_scores = ft.Column(spacing=6)
        self.final_geometry = BoardGeometry(self.session.game.state.board.map, self.width - 36)
        self.final_canvas = cv.Canvas(width=self.final_geometry.width, height=self.final_geometry.height)
        self.final_render_key = None
        self.previous_text = ft.Text(size=12, color=MUTED, visible=False)
        self.results_panel = ft.Container(ft.Column([
            self.result_title, self.previous_text, self.result_rows,
            ft.Text("Einzelne Partien", color=MUTED, size=12), self.sample_rows,
            self.sample_picker, self.final_title, self.final_detail, self.final_awards, self.final_activity,
            ft.Container(self.final_canvas, alignment=ft.Alignment.CENTER, bgcolor="#142631", border_radius=12),
            ft.Text("Stadt: Haus mit Punkt · R: Räuber", color=MUTED, size=11), self.final_scores,
            ft.Text("Bei wenigen Partien schwankt das Ergebnis stark. Alle vier Plätze spielen mit derselben KI.",
                    color=MUTED, size=11),
        ], spacing=12), padding=18, bgcolor=PANEL, border_radius=16, visible=False)
        self.commit_btn = ft.Button("Platzierung bestätigen", icon=ft.Icons.CHECK,
                                    on_click=self.commit, height=46,
                                    style=ft.ButtonStyle(bgcolor=ACCENT, color=BACKGROUND))
        self.undo_btn = ft.TextButton("Zurück", icon=ft.Icons.UNDO, on_click=self.undo)
        self.new_btn = ft.OutlinedButton("Neues Brett", icon=ft.Icons.SHUFFLE, on_click=self.new_game)
        self.retry_btn = ft.TextButton("Dieses Brett erneut", icon=ft.Icons.REPLAY, on_click=self.retry)
        self.count = ft.TextField(label="Simulationen", value="5", width=128, dense=True,
                                  keyboard_type=ft.KeyboardType.NUMBER,
                                  input_filter=ft.InputFilter(allow=True, regex_string=r"[0-9]"))
        self.sim_btn = ft.Button("Simulieren", icon=ft.Icons.PLAY_ARROW, on_click=self.simulate, height=46,
                                 style=ft.ButtonStyle(bgcolor=ACCENT, color=BACKGROUND))
        self.stop_btn = ft.TextButton("Stoppen", icon=ft.Icons.STOP, on_click=self.stop, visible=False)
        self.seat = ft.Dropdown(label="Startplatz", value="random", width=154, dense=True,
                                options=[ft.DropdownOption("random", "Zufällig")] +
                                [ft.DropdownOption(str(i), f"Startplatz {i + 1}") for i in range(4)])
        self.ports = ft.Dropdown(label="Häfen", value="fixed", width=154, dense=True,
                                 options=[ft.DropdownOption("fixed", "Feste Anordnung"),
                                          ft.DropdownOption("random", "Zufällig")])
        self.seed = ft.TextField(label="Brett-Code", value=str(self.session.seed), width=185, dense=True,
                                 keyboard_type=ft.KeyboardType.NUMBER)
        self.load_btn = ft.TextButton("Code laden", on_click=self.load)
        quick = ft.Row([ft.TextButton(str(n), data=n, on_click=self.quick_count)
                        for n in (1, 5, 10, 25, 50, 100)], wrap=True, spacing=0)
        self.opening_actions = ft.Row([self.commit_btn, self.undo_btn], wrap=True)
        self.simulation_actions = ft.Column([ft.Row([self.count, self.sim_btn, self.stop_btn], wrap=True), quick])
        self.root = ft.Column([
            ft.Row([ft.Container(ft.Icon(ft.Icons.GRID_VIEW, color=BACKGROUND, size=25),
                                 padding=10, bgcolor=ACCENT, border_radius=12),
                    ft.Column([ft.Text("Catan", size=25, color=INK, weight=ft.FontWeight.BOLD),
                               ft.Text("Eröffnungstrainer", color=MUTED, size=13)], spacing=0)], spacing=12),
            ft.Text("Platziere zwei Siedlungen und Straßen. Lass die KI anschließend weiterspielen.",
                    size=13, color=MUTED),
            ft.Container(ft.Column([self.players, self.status, self.detail, self.error], spacing=6),
                         padding=16, bgcolor=PANEL, border_radius=14),
            ft.Container(self.board_touch, alignment=ft.Alignment.CENTER,
                         bgcolor="#142631", border_radius=16),
            self.pips,
            self.node_pips, self.node_pips_hint,
            self.opening_actions,
            ft.Text("Erwartete Produktion pro 36 Würfe · ohne Räuber", size=11, color=MUTED),
            self.production, self.start_cards, self.victory_panel,
            self.simulation_actions, self.progress, self.progress_text, self.results_panel,
            ft.Row([self.new_btn, self.retry_btn], wrap=True),
            ft.Divider(color="#293A47"),
            ft.Text("Nächstes Brett", size=13, color=INK, weight=ft.FontWeight.BOLD),
            ft.Row([self.seat, self.ports], wrap=True),
            ft.Row([self.seed, self.load_btn], wrap=True),
            ft.Text("1 → 2 → 3 → 4 → 4 → 3 → 2 → 1\nHäfen: H Holz · L Lehm · W Wolle · G Getreide · E Erz",
                    size=11, color=MUTED),
            ft.Text(f"Simulation: {AI_NAME}",
                    size=10, color=MUTED),
            ft.TextButton("Quellcode und Herkunft", url="smart/source.tar.gz"),
        ], spacing=12, horizontal_alignment=ft.CrossAxisAlignment.STRETCH)
        page.title = "Catan · Eröffnungstrainer"
        page.bgcolor = BACKGROUND
        page.theme_mode = ft.ThemeMode.DARK
        page.theme = ft.Theme(color_scheme_seed=ACCENT, font_family="Roboto")
        page.padding = 16
        page.scroll = ft.ScrollMode.AUTO
        page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
        page.on_resize = self.resize
        page.on_disconnect = self.disconnect
        self.root.width = min(720, max(280, (page.width or 640) - 32))
        page.add(self.root)

    def board_width(self):
        return min(688, max(248, (self.page.width or 640) - 32))

    async def start(self):
        await self.advance()

    def show_error(self, message=""):
        self.error.value = message
        self.error.visible = bool(message)

    def resize(self, e):
        self.width = self.board_width()
        self.root.width = min(720, max(280, (self.page.width or 640) - 32))
        self.canvas.width = self.width
        self.geometry = BoardGeometry(self.session.game.state.board.map, self.width)
        self.canvas.height = self.geometry.height
        self.refresh()

    def disconnect(self, e):
        self.session.close()

    def refresh(self):
        s = self.session
        self.canvas.shapes = opening_shapes(s, self.geometry, show_targets=not self.busy,
                                            show_pips=self.pips.value, show_node_pips=self.node_pips.value)
        self.node_pips.visible = not s.complete
        self.node_pips_hint.visible = not s.complete and self.node_pips.value
        self.players.controls = [ft.Text(f"{i + 1}. {COLOR_NAMES[c]}" + (" · Du" if c == s.human else ""),
                                        color=COLORS[c], size=12,
                                        weight=ft.FontWeight.BOLD if c == s.human else ft.FontWeight.NORMAL)
                                 for i, c in enumerate(s.game.state.colors)]
        own_count = len(s.game.state.buildings_by_color[s.human][SETTLEMENT])
        if s.complete:
            self.status.value = "Eröffnung fertig"
            self.detail.value = "Alle Plätze übernehmen dieselbe KI. Wähle die Anzahl der Partien."
        elif not s.human_turn:
            self.status.value = f"{COLOR_NAMES[s.game.state.current_color()]} platziert …"
            self.detail.value = f"Du bist auf Startplatz {s.seat + 1}."
        elif s.selected_node is None:
            self.status.value = f"Deine {'erste' if own_count == 0 else 'zweite'} Siedlung"
            self.detail.value = "Tippe auf eine helle Kreuzung."
        elif s.selected_edge is None:
            self.status.value = "Wähle die Straßenrichtung"
            self.detail.value = "Tippe auf einen markierten Straßenpunkt neben deiner Siedlung."
        else:
            self.status.value = "Siedlung und Straße gewählt"
            self.detail.value = "Bestätigen oder eine andere Kreuzung / Straße wählen."
        self.production.controls = resource_chips(s.production(include_selected=True))
        cards = s.starting_resources()
        if own_count == 1 and s.selected_node is not None:
            cards = Counter(t.resource for t in s.game.state.board.map.adjacent_tiles[s.selected_node] if t.resource)
        self.start_cards.value = ("Startkarten: " + ", ".join(f"{v} {RESOURCE_NAMES[r]}" for r, v in cards.items() if v)) if any(cards.values()) else "Startkarten erhältst du an deiner zweiten Siedlung."
        rounds = s.victory_rounds_preview()
        self.victory_preview.value = ("Wähle auch deine zweite Siedlung." if rounds is None else
                                      "Ohne Produktion nicht erreichbar" if math.isinf(rounds) else
                                      f"≈ {math.ceil(rounds - 1e-9)} Runden")
        self.opening_actions.visible = not s.complete or bool(s.history)
        self.commit_btn.visible = not s.complete
        self.undo_btn.content = "Letzte Platzierung ändern" if s.complete else "Zurück"
        self.commit_btn.disabled = self.busy or s.selected_edge is None
        self.undo_btn.disabled = self.busy or not s.history
        self.simulation_actions.visible = s.complete
        self.sim_btn.content = "Weitere simulieren" if s.results.samples else "Simulieren"
        self.sim_btn.disabled = self.busy
        for control in (self.new_btn, self.retry_btn, self.seat, self.ports, self.seed, self.load_btn, self.count):
            control.disabled = self.busy
        self.stop_btn.visible = self.busy and s.complete
        self.render_results()
        self.page.update()

    def render_results(self):
        s, results = self.session, self.session.results
        self.results_panel.visible = bool(results.samples)
        decided = results.decided
        self.result_title.value = f"Du gewinnst {results.wins[s.human]} von {decided} Partien"
        if results.limited:
            self.result_title.value += f" · {results.limited} am Zuglimit"
        self.result_rows.controls = []
        for i, c in enumerate(s.game.state.colors):
            wins = results.wins[c]
            self.result_rows.controls.append(ft.Column([
                ft.Row([ft.Text(f"{i + 1}. {COLOR_NAMES[c]}" + (" · Du" if c == s.human else ""), color=COLORS[c], expand=True),
                        ft.Text(f"{wins} Siege", color=INK, size=12)]),
                ft.ProgressBar(value=wins / decided if decided else 0, color=COLORS[c], bgcolor="#2B3B49", height=5),
            ], spacing=4))
        self.sample_rows.controls = [ft.Text(
            f"{sample.index + 1}. {'Zuglimit' if sample.winner is None else COLOR_NAMES[sample.winner] + ' gewinnt'}"
            f" · {sample.turns} Züge · {sample.seconds:.1f} s",
            color=COLORS.get(sample.winner, MUTED), size=12,
        ) for sample in results.samples[-12:]]
        previous = self.previous
        self.previous_text.visible = bool(previous and previous[0] == (s.seed, s.seat, s.random_ports))
        if self.previous_text.visible:
            self.previous_text.value = f"Voriger Versuch auf diesem Brett: {previous[1]} von {previous[2]} gewonnen."
        if not results.samples:
            self.sample_picker.value = None
            self.sample_picker.options = []
            self.final_canvas.shapes = []
            self.final_render_key = None
            return
        if len(self.sample_picker.options) != len(results.samples):
            self.sample_picker.options = [ft.DropdownOption(str(sample.index),
                f"Partie {sample.index + 1} · " + ("Kein Sieger (Limit)" if sample.winner is None else
                                                   f"{COLOR_NAMES[sample.winner]} gewinnt"))
                for sample in results.samples]
        sample = next((sample for sample in results.samples if str(sample.index) == self.sample_picker.value),
                      results.samples[0])
        self.sample_picker.value = str(sample.index)
        render_key = (sample, self.width - 36, self.pips.value)
        if render_key == self.final_render_key:
            return
        self.final_geometry = BoardGeometry(s.game.state.board.map, self.width - 36)
        self.final_canvas.width = self.final_geometry.width
        self.final_canvas.height = self.final_geometry.height
        self.final_canvas.shapes = board_shapes(s.game.state.board.map, sample.board, self.final_geometry,
                                                show_pips=self.pips.value)
        self.final_title.value = (f"Partie {sample.index + 1} · " +
                                  ("Kein Sieger" if sample.winner is None else
                                   f"{COLOR_NAMES[sample.winner]} gewinnt" + (" · Du" if sample.winner == s.human else "")))
        self.final_title.color = COLORS.get(sample.winner, INK)
        self.final_detail.value = (f"{sample.turns} Züge · {sample.seconds:.1f} s" +
                                   (" · Am Simulationslimit beendet" if sample.winner is None else ""))
        activity = sample.activity
        bought = ", ".join(f"{count} {name}" for name, count in zip(DEV_NAMES, activity.cards_bought) if count) or "keine"
        played = ", ".join(f"{count} {name}" for name, count in zip(DEV_NAMES, activity.cards_played) if count) or "keine"
        self.final_activity.value = (f"Entwicklungskarten gekauft: {bought}\nGespielt: {played}\n"
                                     f"Spielerhandel: {activity.player_trades} · Bank-/Hafenhandel: {activity.bank_trades}"
                                     f" · Angebote: {activity.offers}")
        self.final_awards.controls = []
        for label, holder, counts, unit in (
            ("Größte Rittermacht", sample.awards.largest_army, sample.awards.knights, "gespielte Ritter"),
            ("Längste Handelsstraße", sample.awards.longest_road, sample.awards.road_lengths, "Straßen"),
        ):
            description = "Noch nicht vergeben"
            if holder is not None:
                count = counts[s.game.state.colors.index(holder)]
                description = (COLOR_NAMES[holder] + (" · Du" if holder == s.human else "") +
                               f" · {count} {unit} · 2 Siegpunkte")
            self.final_awards.controls.append(ft.Text(f"{label}: {description}",
                                                      color=COLORS.get(holder, MUTED), size=12))
        self.final_scores.controls = [ft.Row([
            ft.Text(COLOR_NAMES[c] + (" · Du" if c == s.human else "") +
                    (" · Sieger" if c == sample.winner else ""), color=COLORS[c], expand=True,
                    weight=ft.FontWeight.BOLD if c == sample.winner else ft.FontWeight.NORMAL),
            ft.Text(f"{points} Siegpunkte", color=INK, size=12),
        ]) for c, points in zip(s.game.state.colors, sample.points)]
        self.final_render_key = render_key

    def toggle_pips(self, e):
        self.refresh()

    def select_sample(self, e):
        self.render_results()
        self.page.update()

    def tap(self, e):
        if self.busy or not self.session.human_turn or e.local_position is None:
            return
        hit = self.geometry.hit(e.local_position.x, e.local_position.y,
                                self.session.legal_nodes, self.session.legal_roads)
        if not hit:
            return
        self.show_error()
        if hit[0] == "node":
            self.session.select_node(hit[1])
        else:
            self.session.select_road(hit[1])
        self.refresh()

    async def advance(self):
        self.busy = True
        self.refresh()
        try:
            await self.session.advance_bots(self.refresh)
        except Exception as exc:
            self.show_error(f"Computerplatzierung fehlgeschlagen: {exc}")
        finally:
            self.busy = False
            self.refresh()

    async def commit(self, e):
        if self.busy:
            return
        try:
            self.session.commit()
            self.show_error()
            await self.advance()
        except ValueError as exc:
            self.show_error(str(exc))
            self.refresh()

    def undo(self, e):
        if not self.busy:
            self.session.undo()
            self.show_error()
            self.refresh()

    async def replace_session(self, seed=None, seat=None):
        if self.busy:
            return
        if self.session.results.decided:
            self.previous = ((self.session.seed, self.session.seat, self.session.random_ports),
                             self.session.results.wins[self.session.human], self.session.results.decided)
        self.session.close()
        self.session = OpeningSession(seed, seat, self.ports.value == "random")
        self.seed.value = str(self.session.seed)
        self.geometry = BoardGeometry(self.session.game.state.board.map, self.width)
        self.progress.visible = self.progress_text.visible = False
        self.show_error()
        await self.advance()

    async def new_game(self, e):
        seat = None if self.seat.value == "random" else int(self.seat.value)
        await self.replace_session(seat=seat)

    async def retry(self, e):
        # Retry the actual port setting/seat, even if settings for the next board changed.
        self.ports.value = "random" if self.session.random_ports else "fixed"
        await self.replace_session(self.session.seed, self.session.seat)

    async def load(self, e):
        try:
            seed = int(self.seed.value)
            if not 0 <= seed < 2**63:
                raise ValueError
            seat = None if self.seat.value == "random" else int(self.seat.value)
            await self.replace_session(seed, seat)
        except ValueError:
            self.show_error("Der Brett-Code muss eine ganze Zahl zwischen 0 und 9223372036854775807 sein.")
            self.refresh()

    def quick_count(self, e):
        if not self.busy:
            self.count.value = str(e.control.data)
            self.page.update()

    def stop(self, e):
        self.session.cancel()
        self.progress_text.value = "Wird gestoppt …"
        self.page.update()

    async def simulate(self, e):
        if self.busy:
            return
        try:
            count = int(self.count.value)
            if not 1 <= count <= MAX_SIMULATIONS:
                raise ValueError
        except (ValueError, TypeError):
            self.show_error(f"Wähle 1 bis {MAX_SIMULATIONS} Simulationen.")
            self.refresh()
            return
        self.show_error()
        self.busy = True
        self.progress.visible = self.progress_text.visible = True
        self.progress.value = 0
        self.progress_text.value = f"Partie 1 von {count} …"
        self.refresh()
        rendered_count = len(self.session.results.samples)
        def progress(done, target, turns):
            nonlocal rendered_count
            self.progress.value = done / target
            self.progress_text.value = (f"{done} von {target} Partien fertig" if not turns else
                                        f"{done} von {target} Partien fertig · Zug {turns}")
            if len(self.session.results.samples) != rendered_count:
                self.render_results()
                rendered_count = len(self.session.results.samples)
            self.page.update()
        try:
            await self.session.simulate(count, progress)
            if self.session.cancelled:
                self.progress_text.value = "Gestoppt. Abgeschlossene Partien bleiben erhalten."
            else:
                self.progress_text.value = f"Fertig · {len(self.session.results.samples)} Partien insgesamt"
        except Exception as exc:
            self.show_error(f"Simulation fehlgeschlagen: {exc}")
            self.progress_text.value = "Berechnung angehalten."
        finally:
            self.busy = False
            self.refresh()


async def main(page: ft.Page):
    app = TrainerApp(page)
    await app.start()


if __name__ == "__main__":
    ft.run(main)

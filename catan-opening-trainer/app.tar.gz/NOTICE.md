# Catanatron snapshot

`src/catanatron` contains the pure Python core and players of
[bcollazo/catanatron](https://github.com/bcollazo/catanatron), pinned to commit
`ecf931181b9a65bb4116a2153fb78c16f1438e00` (version 3.3.0).

The source files are unmodified. Optional `gym`, `web`, and `cli` modules are
omitted because the trainer uses its own Flet interface. The upstream GPL-3.0
license is included in `src/catanatron/LICENSE` and the repository root.

Vendoring the small Python core keeps the browser package reproducible and
avoids depending on older PyPI releases. Runtime dependencies are pinned in
`src/requirements.txt`.

The adapter in `src/trainer/engine.py` adds randomized number-spiral corners,
official on-turn victory detection, opening transactions, independent random
streams, and cooperative execution of Catanatron's ValueFunction evaluation.
The evaluator and move generator remain Catanatron's implementation.

The author of Catanatron is Bryan Collazo; additional contributors are credited
in the upstream repository. The trainer is an independent personal project.

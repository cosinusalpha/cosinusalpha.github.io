import test from "node:test";
import assert from "node:assert/strict";
import {EnginePool} from "../web/smart/pool.js";
import {runGame} from "../web/smart/runner.js";

function setup(cores = 4) {
  const workers = [];
  const pool = new EnginePool({cores, createWorker: () => {
    const worker = {
      requests: [], terminated: false,
      postMessage(request) { this.requests.push(request); },
      terminate() { this.terminated = true; },
      reply(request, result = {}) {
        this.onmessage({data: {id: request.id, ok: true, result}});
      },
    };
    workers.push(worker);
    return worker;
  }});
  const jobs = Array.from({length: 4}, (_, index) => ({index, seed: String(9007199254741001n + BigInt(index))}));
  const batch = {op: "batch", opening: {op: "opening"}, jobs, dice_mode: "deck36", max_turns: 600, max_actions: 30000};
  return {pool, workers, batch};
}

const tick = () => new Promise(resolve => setImmediate(resolve));

test("two workers schedule independent seeds, retain completion order, and reuse models", async () => {
  const {pool, workers, batch} = setup();
  const events = [];
  const pending = pool.request(batch, event => events.push(event));
  assert.equal(workers.length, 2);
  workers.forEach(w => w.reply(w.requests[0]));
  await tick();
  const a = workers[0], b = workers[1];
  assert.equal(a.requests[1].seed, batch.jobs[0].seed);
  assert.equal(b.requests[1].seed, batch.jobs[1].seed);
  assert.ok(workers.every(w => w.requests[1].dice_mode === "deck36"));
  b.reply(b.requests[1], {result: {done: true}, seconds: 1});
  await tick();
  assert.equal(events[0].index, 1);
  assert.equal(b.requests[2].index, 2);
  a.reply(a.requests[1], {result: {done: true}, seconds: 2});
  await tick();
  assert.equal(a.requests[2].index, 3);
  a.reply(a.requests[2], {result: {done: true}});
  b.reply(b.requests[2], {result: {done: true}});
  assert.deepEqual(await pending, {cancelled: false, completed: 4, workers: 2});
  assert.deepEqual(events.map(e => e.index), [1, 0, 3, 2]);
  const opening = pool.request({op: "opening", seed: "1"});
  a.reply(a.requests.at(-1), {initial_phase: true});
  await opening;
  assert.equal(workers.length, 2);
  pool.close();
  assert.ok(workers.every(w => w.terminated));
});

test("small/unknown core counts and one-game batches use one worker", async () => {
  for (const cores of [1, 2, 3, undefined]) {
    const {pool, workers, batch} = setup(cores ?? 1);
    const pending = pool.request({...batch, jobs: batch.jobs.slice(0, 1)});
    assert.equal(workers.length, 1);
    workers[0].reply(workers[0].requests[0]);
    await tick();
    workers[0].reply(workers[0].requests[1], {result: {done: true}});
    assert.equal((await pending).completed, 1);
    pool.close();
  }
});

test("cancel stops dispatch, preserves completed games, then allows another batch", async () => {
  const {pool, workers, batch} = setup();
  const events = [];
  const pending = pool.request(batch, event => events.push(event));
  workers.forEach(w => w.reply(w.requests[0]));
  await tick();
  pool.cancel();
  workers[1].reply(workers[1].requests[1], {result: {done: true}});
  workers[0].reply(workers[0].requests[1], {cancelled: true});
  assert.deepEqual(await pending, {cancelled: true, completed: 1, workers: 2});
  assert.equal(events[0].index, 1);
  assert.equal(workers.flatMap(w => w.requests).filter(r => r.op === "run").length, 2);
  const next = pool.request({...batch, dice_mode: "dice", jobs: batch.jobs.slice(2, 3)});
  workers[0].reply(workers[0].requests.at(-1));
  await tick();
  assert.equal(workers[0].requests.at(-1).dice_mode, "dice");
  workers[0].reply(workers[0].requests.at(-1), {result: {done: true}});
  assert.equal((await next).completed, 1);
  pool.close();
});

test("cancelling during initialization starts no games", async () => {
  const {pool, workers, batch} = setup();
  const pending = pool.request(batch);
  pool.cancel();
  workers.forEach(w => w.reply(w.requests[0]));
  assert.equal((await pending).completed, 0);
  assert.ok(workers.every(w => !w.requests.some(r => r.op === "run")));
  pool.close();
});

test("worker failures reject all lanes and fresh workers recover", async () => {
  const {pool, workers, batch} = setup();
  const pending = pool.request(batch);
  const rejected = assert.rejects(pending, /crashed/);
  workers[0].onerror({message: "crashed"});
  await rejected;
  assert.ok(workers.every(w => w.terminated));
  const next = pool.request({...batch, jobs: batch.jobs.slice(0, 1)});
  workers[2].reply(workers[2].requests[0]);
  await tick();
  workers[2].reply(workers[2].requests[1], {result: {done: true}});
  assert.equal((await next).completed, 1);
  pool.close();
});

test("progress is compact and throttled across both workers", async () => {
  const {pool, workers, batch} = setup();
  const events = [];
  const pending = pool.request(batch, e => events.push(e));
  workers.forEach(w => w.reply(w.requests[0]));
  await tick();
  for (const w of workers) {
    for (let i = 0; i < 5; i++) w.onmessage({data: {id: w.requests[1].id, event: "progress", turns: 9}});
  }
  assert.equal(events.length, 1);
  assert.equal(events[0].turns, 9);
  assert.equal(events[0].result, undefined);
  pool.cancel();
  workers.forEach(w => w.reply(w.requests[1], {cancelled: true}));
  await pending;
  pool.close();
});

test("game runner advances locally, returns only terminal snapshots, and cancels before another chunk", async () => {
  const requests = [];
  const engine = {request(data) {
    const request = JSON.parse(data);
    requests.push(request);
    return JSON.stringify({done: requests.length === 4, turns: requests.length, roads: []});
  }};
  const result = await runGame(engine, {seed: "42", dice_mode: "deck36", max_turns: 600, max_actions: 30000}, () => false, () => {});
  assert.equal(result.result.done, true);
  assert.equal(result.calls, 4);
  assert.ok(requests.every(r => r.compact));
  assert.equal(requests[0].dice_mode, "deck36");
  requests.length = 0;
  const cancelled = await runGame(engine, {seed: "42", dice_mode: "dice"}, () => true, () => {});
  assert.deepEqual(cancelled, {cancelled: true});
  assert.equal(requests.length, 1);
  assert.equal(requests[0].dice_mode, "dice");
});

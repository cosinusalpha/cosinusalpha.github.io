// Run with playwright-cli run-code --filename=tests/browser_checks.js after
// tools/benchmark_browser.py; page origin must serve the repository root.
async page => {
  return await page.evaluate(async () => {
    const assert = (condition, message) => { if (!condition) throw Error(message); };
    const root = "/build/browser-benchmark/";
    const {EnginePool} = await import(`${root}smart/pool.js`);
    const module = await import(`${root}smart/catan_engine.js`);
    await module.default();
    const weights = new Uint8Array(await (await fetch(`${root}smart/v89w.bin`)).arrayBuffer());
    const engine = new module.TrainerEngine(weights);
    const parity = await (await fetch("/vendor/smart_engine/testdata/v89w_parity.json")).json();
    const rows = new Float32Array(parity.x.flat());
    const actual = engine.evaluate(rows, false);
    const portable = engine.evaluate(rows, true);
    const actualBits = new Uint32Array(actual.buffer);
    const portableBits = new Uint32Array(portable.buffer);
    assert(actualBits.every((n, i) => n === portableBits[i]), "SIMD differs from portable inference");
    const worst = Math.max(...parity.heads.flat().map((v,i) => Math.abs(v - actual[i])));
    assert(worst < 1e-3, `PyTorch parity error ${worst}`);
    let invalid = false;
    try { engine.evaluate(new Float32Array(1), false); } catch { invalid = true; }
    assert(invalid, "incomplete inference row was accepted");
    engine.free();

    const fixtures = await (await fetch(`${root}fixtures.json`)).json();
    const pool = new EnginePool({cores:4, createWorker:() => new Worker(`${root}smart/worker.js`, {type:"module"})});
    const jobs = [0,1,2].map(index => ({index, seed: String(9007199254741001n + BigInt(index))}));
    const batches = [];
    try {
      for (const dice_mode of ["deck36", "dice"]) {
        for (const fixture of fixtures) {
          const batch = {op:"batch",opening:fixture.complete,jobs,dice_mode,max_turns:600,max_actions:128};
          const parallel = [];
          await pool.request(batch, event => { if (event.event === "completed") parallel.push(event); });
          assert(parallel.length === jobs.length, "lost completion");
          const single = new EnginePool({cores:1, createWorker:() => new Worker(`${root}smart/worker.js`, {type:"module"})});
          const serial = [];
          try {
            await single.request(batch, event => { if(event.event === "completed") serial.push(event); });
          } finally { single.close(); }
          for (const game of parallel) {
            const reference = serial.find(g => g.index === game.index);
            assert(JSON.stringify(reference.result) === JSON.stringify(game.result), "parallel game changed");
            assert(game.seed === jobs[game.index].seed, "large seed lost precision");
            assert(game.result.dice_mode === dice_mode, "roll mode was lost");
            const awards = game.result.awards;
            assert(awards && awards.knights.length === 4 && awards.road_lengths.length === 4,
                   "terminal result lost award details");
            assert(awards.largest_army >= -1 && awards.largest_army < 4 &&
                   awards.longest_road >= -1 && awards.longest_road < 4, "invalid award holder");
          }
          batches.push({board:fixture.seed, dice_mode, matched:parallel.length});
        }
        let progress = 0;
        const cancelled = await pool.request({op:"batch",opening:fixtures[0].complete,jobs,
          dice_mode,max_turns:600,max_actions:30000}, event => {
          if(event.event === "progress") { progress++; pool.cancel(); }
        });
        assert(progress > 0 && cancelled.cancelled, "cancellation was ignored");
        const resumed = await pool.request({op:"batch",opening:fixtures[1].complete,
          jobs:jobs.slice(0,1),dice_mode,max_turns:600,max_actions:16});
        assert(resumed.completed === 1 && !resumed.cancelled, "could not resume after cancellation");
      }
    } finally { pool.close(); }

    // Exercise the exact JSON event protocol used by Python, including nested
    // workers, rather than only the direct JavaScript benchmark API.
    const coordinator = new Worker(`${root}smart/coordinator.js`, {type:"module"});
    let completed = 0;
    const reply = await new Promise((resolve,reject) => {
      coordinator.onerror = event => reject(Error(event.message));
      coordinator.onmessage = ({data}) => {
        const response = JSON.parse(data);
        if(response.event === "completed") {
          if (response.result.dice_mode !== "deck36") {
            reject(Error("coordinator lost roll mode")); return;
          }
          completed++; return;
        }
        if(response.event) return;
        response.ok ? resolve(response.result) : reject(Error(response.error));
      };
      coordinator.postMessage(JSON.stringify({op:"batch",id:1,opening:fixtures[0].complete,
        jobs:jobs.slice(0,2),dice_mode:"deck36",max_turns:600,max_actions:16}));
    }).finally(() => {
      coordinator.postMessage(JSON.stringify({op:"close"}));
      coordinator.terminate();
    });
    assert(completed === 2 && reply.completed === 2, "coordinator lost completed games");
    return {inferenceBitwiseEqual:true, maxTorchError:worst, batches, cancellation:true, coordinator:true};
  });
}

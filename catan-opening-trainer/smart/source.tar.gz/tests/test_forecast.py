import math

import pytest

from catanatron.models.enums import RESOURCES
from trainer.engine import BoardSnapshot, OpeningSession
from trainer.forecast import VICTORY_BUDGET, opening_trade_ratios, resource_budget_rounds


def test_rounds_use_four_rolls_start_cards_and_resource_bottlenecks():
    bank = dict.fromkeys(RESOURCES, 4)
    # Income proportional to the full bill: one quarter of the resources per
    # round, with no surplus to exchange, pays for it in exactly four rounds.
    income = {r: cost * 9 / 4 for r, cost in VICTORY_BUDGET.items()}
    assert resource_budget_rounds(income, {}, bank) == pytest.approx(4)
    half_bill = {r: cost / 2 for r, cost in VICTORY_BUDGET.items()}
    assert resource_budget_rounds(income, half_bill, bank) == pytest.approx(2)
    assert resource_budget_rounds(income, VICTORY_BUDGET, bank) == 0
    assert math.isinf(resource_budget_rounds({}, {}, bank))


def test_missing_resources_can_be_bought_only_from_surplus_at_the_actual_port_rate():
    # Only wood is produced, one card per round. Reserve 12 wood for building;
    # the other 40 cards require 160 / 120 / 80 wood through 4:1 / 3:1 / 2:1.
    income = {"WOOD": 9}
    for ratio, expected in ((4, 172), (3, 132), (2, 92)):
        rates = {**dict.fromkeys(RESOURCES, 4), "WOOD": ratio}
        assert resource_budget_rounds(income, {}, rates) == pytest.approx(expected)
    rates = dict.fromkeys(RESOURCES, 4)
    assert resource_budget_rounds({"WOOD": 18}, {}, rates) == pytest.approx(86)


def test_ports_require_an_adjacent_starting_settlement_and_keep_the_best_rate():
    s = OpeningSession(5, 0)
    m = s.game.state.board.map
    assert set(opening_trade_ratios(m, []).values()) == {4}
    from catanatron.models.map import PORT_DIRECTION_TO_NODEREFS
    for port in m.ports_by_id.values():
        node = port.nodes[PORT_DIRECTION_TO_NODEREFS[port.direction][0]]
        ratios = opening_trade_ratios(m, [node])
        if port.resource is None:
            assert set(ratios.values()) == {3}
        else:
            assert ratios[port.resource] == 2
            assert all(ratios[r] == 4 for r in RESOURCES if r != port.resource)
    nodes = [p.nodes[PORT_DIRECTION_TO_NODEREFS[p.direction][0]] for p in m.ports_by_id.values()]
    assert set(opening_trade_ratios(m, nodes).values()) == {2}


def test_live_second_settlement_forecast_matches_confirmed_opening_without_mutation():
    s = OpeningSession(5, 0)
    assert s.victory_rounds_preview() is None
    s.select_node(s.legal_nodes[0])
    first_only = resource_budget_rounds(s.production(include_selected=True), {},
                                        opening_trade_ratios(s.game.state.board.map, [s.selected_node]))
    assert s.victory_rounds_preview() == first_only
    s.select_road(s.legal_roads[0])
    s.commit()
    assert s.victory_rounds_preview() == first_only
    while not s.human_turn:
        s.game.execute(s.game.playable_actions[0])
    forecasts = []
    for node in s.legal_nodes:
        s.select_node(node)
        before = BoardSnapshot.from_board(s.game.state.board)
        rng = s.game.random.getstate()
        forecasts.append(s.victory_rounds_preview())
        assert BoardSnapshot.from_board(s.game.state.board) == before
        assert s.game.random.getstate() == rng
    assert len(set(round(n, 4) for n in forecasts)) > 1
    expected = s.victory_rounds_preview()
    s.select_road(s.legal_roads[0])
    s.commit()
    assert s.complete
    assert s.victory_rounds_preview() == expected
    assert not s.results.samples and s.client is None
    assert s.undo() and s.victory_rounds_preview() == first_only
    assert s.undo() and s.victory_rounds_preview() is None

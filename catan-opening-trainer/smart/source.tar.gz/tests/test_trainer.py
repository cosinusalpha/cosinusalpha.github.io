import asyncio
import copy
from collections import Counter
from dataclasses import FrozenInstanceError
import random
from types import SimpleNamespace

import pytest
from catanatron.models.enums import Action, ActionType, CITY, RESOURCES, SETTLEMENT
from catanatron.models.map import BASE_NUMBERS_IN_SPIRAL_ORDER
from trainer.engine import Awards, BoardSnapshot, OpeningSession, Sample, COLOR_NAMES, CORNERS, create_game, decide_cooperatively
from trainer.board import BoardGeometry


def run(coro):
    return asyncio.run(coro)


def place_first(session):
    session.select_node(session.legal_nodes[0])
    session.select_road(session.legal_roads[0])
    session.commit()


async def finish_opening(session):
    await session.advance_bots()
    while not session.complete:
        place_first(session)
        await session.advance_bots()
    return session


def board_fingerprint(session):
    m = session.game.state.board.map
    return (tuple((coord, t.resource, t.number) for coord, t in m.land_tiles.items()),
            tuple((t.id, t.resource) for t in m.ports_by_id.values()))


class PageStub:
    width = 390

    def add(self, control):
        self.control = control

    def update(self):
        pass


def test_spiral_all_six_corners_against_independent_ring_order():
    outer = [(2,-2,0),(2,-1,-1),(2,0,-2),(1,1,-2),(0,2,-2),(-1,2,-1),
             (-2,2,0),(-2,1,1),(-2,0,2),(-1,-1,2),(0,-2,2),(1,-2,1)]
    inner = [(1,-1,0),(1,0,-1),(0,1,-1),(-1,1,0),(-1,0,1),(0,-1,1)]
    seen = set()
    for seed in range(60):
        game, _, _, corner = create_game(seed)
        rotations = CORNERS.index(corner)
        expected_coords = []
        for coord in outer + inner + [(0,0,0)]:
            for _ in range(rotations):
                x,y,z = coord
                coord = (-y,-z,-x)
            expected_coords.append(coord)
        tiles = game.state.board.map.land_tiles
        numbers = [tiles[c].number for c in expected_coords if tiles[c].resource is not None]
        assert numbers == BASE_NUMBERS_IN_SPIRAL_ORDER
        assert Counter(t.resource for t in tiles.values()) == {"WOOD":4,"BRICK":3,"SHEEP":4,"WHEAT":4,"ORE":3,None:1}
        seen.add(corner)
    assert seen == set(CORNERS)


@pytest.mark.parametrize("seat", range(4))
def test_opening_snake_order_distance_rule_and_start_cards(seat):
    s = OpeningSession(56, seat)
    game = s.game
    placements = []
    while game.state.is_initial_build_phase:
        action = game.playable_actions[0]
        if action.action_type == ActionType.BUILD_SETTLEMENT:
            color = action.color
            existing = len(game.state.buildings_by_color[color][SETTLEMENT])
            game.execute(action)
            placements.append(color)
            key = f"P{game.state.color_to_index[color]}"
            hand = {r: game.state.player_state[f"{key}_{r}_IN_HAND"] for r in RESOURCES}
            expected = Counter(t.resource for t in game.state.board.map.adjacent_tiles[action.value] if t.resource)
            assert hand == (dict.fromkeys(RESOURCES,0) if existing == 0 else {r:expected[r] for r in RESOURCES})
        else:
            last = game.state.buildings_by_color[action.color][SETTLEMENT][-1]
            assert last in action.value
            game.execute(action)
    assert placements == list(game.state.colors) + list(reversed(game.state.colors))
    nodes = list(game.state.board.buildings)
    for tile in game.state.board.map.land_tiles.values():
        for edge in tile.edges.values():
            assert not set(edge).issubset(nodes)
    assert len(game.state.board.buildings) == 8
    assert len({tuple(sorted(e)) for e in game.state.board.roads}) == 8


def test_selection_is_transactional_and_rejects_illegal_road():
    s = OpeningSession(7, 0)
    s.select_node(s.legal_nodes[0])
    assert not s.game.state.board.buildings
    assert not s.starting_resources()["WOOD"]
    assert 1 <= len(s.legal_roads) <= 3
    with pytest.raises(ValueError):
        s.select_road((1000,1001))
    with pytest.raises(ValueError):
        s.commit()
    assert not s.game.state.board.buildings
    s.select_road(s.legal_roads[0])
    s.commit()
    assert len(s.game.state.board.buildings) == 1
    assert len({tuple(sorted(e)) for e in s.game.state.board.roads}) == 1


def test_replay_and_fixed_ports_are_reproducible():
    s = OpeningSession(77)
    other = OpeningSession(77, s.seat)
    assert s.human == other.human
    assert board_fingerprint(s) == board_fingerprint(other)
    ports = board_fingerprint(s)[1]
    assert ports == board_fingerprint(OpeningSession(99))[1]
    assert len({board_fingerprint(OpeningSession(i,random_ports=True))[1] for i in range(8)}) > 1


def test_undo_restores_rng_and_opponent_placements():
    s = OpeningSession(4,0)
    state_before = copy.deepcopy(s.game.state)
    place_first(s)
    run(s.advance_bots())
    assert len(s.game.state.board.buildings) > 1
    assert s.undo()
    assert s.game.state.board.buildings == state_before.board.buildings
    assert s.game.state.random.getstate() == state_before.random.getstate()
    assert s.human_turn
    assert not s.undo()


def test_geometry_and_road_touch_on_phone():
    s = OpeningSession(5,0)
    for width in (280,328,390,688):
        g = BoardGeometry(s.game.state.board.map,width)
        assert len(g.nodes) == 54
        for x,y in g.nodes.values():
            assert 0 <= x <= g.width
            assert 0 <= y <= g.height
        for t in s.game.state.board.map.land_tiles.values():
            for a,b in t.edges.values():
                x,y = g.nodes[a]
                u,v = g.nodes[b]
                assert ((x-u)**2+(y-v)**2)**.5 == pytest.approx(g.radius)
        for _,_,(x,y) in g.ports:
            assert 0 <= x <= g.width
            assert 0 <= y <= g.height
        node = s.legal_nodes[0]
        s.select_node(node)
        for edge in s.legal_roads:
            assert g.hit(*g.midpoint(edge),s.legal_nodes,s.legal_roads) == ("road",edge)


def test_opening_bot_matches_catanatron_alpha_beta_depth_two():
    from catanatron.players.minimax import AlphaBetaPlayer
    s = OpeningSession(8,0)
    assert all(type(player) is AlphaBetaPlayer and player.params.depth == 2 for player in s.game.state.players)
    reference = copy.deepcopy(s.game)
    expected = reference.state.current_player().decide(reference,reference.playable_actions)
    before = s.game.state.random.getstate()
    assert run(decide_cooperatively(s.game)) == expected
    assert before == s.game.state.random.getstate()


def test_alpha_beta_matches_upstream_during_game_and_preserves_rng():
    s = run(finish_opening(OpeningSession(83, 3)))
    branching_colors = set()
    for _ in range(50):
        game = s.game
        if game.winning_color() is not None:
            break
        reference = copy.deepcopy(game)
        expected = reference.state.current_player().decide(reference, reference.playable_actions)
        before = game.state.random.getstate()
        actual = run(decide_cooperatively(game))
        assert actual == expected
        assert before == game.state.random.getstate()
        if len(game.playable_actions) > 1:
            branching_colors.add(game.state.current_color())
        game.execute(actual)
    assert len(branching_colors) > 1


def test_alpha_beta_can_stop_within_a_search_without_advancing_game():
    s = OpeningSession(8, 0)
    before = copy.deepcopy(s.game.state)
    checkpoints = 0

    def stop_during_search():
        nonlocal checkpoints
        checkpoints += 1
        return checkpoints >= 5

    assert run(decide_cooperatively(s.game, stop_during_search)) is None
    assert s.game.state.board.buildings == before.board.buildings
    assert s.game.state.random.getstate() == before.random.getstate()


def test_simulation_clones_have_independent_rng_and_development_decks():
    s = run(finish_opening(OpeningSession(83,3)))
    original_rng = s.game.state.random.getstate()
    a,seed_a = s.simulation_game(0)
    b,seed_b = s.simulation_game(0)
    c,seed_c = s.simulation_game(1)
    assert seed_a == seed_b != seed_c
    assert a.state.random is a.random
    assert a.random is not b.random and a.random is not s.game.random
    assert a.state.development_listdeck == b.state.development_listdeck
    a.random.random()
    assert original_rng == s.game.state.random.getstate()
    assert a.state.development_listdeck is not b.state.development_listdeck
    assert Counter(a.state.development_listdeck) == Counter(s.game.state.development_listdeck)


def test_off_turn_points_do_not_end_game():
    s = OpeningSession(3,0)
    game = s.game
    c = game.state.colors[1]
    game.state.player_state[f"P1_ACTUAL_VICTORY_POINTS"] = 10
    assert game.winning_color() is None
    game.state.current_turn_index = 1
    assert game.winning_color() == c
    assert game.copy().winning_color() == c


def test_cutoffs_and_cancel_are_not_counted_as_losses_or_duplicate_samples():
    s = run(finish_opening(OpeningSession(89,2)))
    fingerprint = board_fingerprint(s)
    buildings = dict(s.game.state.board.buildings)
    rng_state = s.game.state.random.getstate()
    run(s.simulate(2,max_turns=1))
    assert len(s.results.samples) == 2
    assert s.results.decided == 0 and s.results.limited == 2
    def cancel_after_first(done,total,turns):
        if done:
            s.cancelled = True
    run(s.simulate(5,cancel_after_first,max_turns=1))
    assert [sample.index for sample in s.results.samples] == [0,1,2]
    run(s.simulate(1,max_turns=1))
    assert [sample.index for sample in s.results.samples] == [0,1,2,3]
    assert len({sample.seed for sample in s.results.samples}) == 4
    assert fingerprint == board_fingerprint(s)
    assert buildings == s.game.state.board.buildings
    assert rng_state == s.game.state.random.getstate()
    assert all(sample.board == BoardSnapshot.from_board(s.game.state.board) for sample in s.results.samples)
    for count in (0,-1,1001):
        with pytest.raises(ValueError):
            run(s.simulate(count))


def test_flet_controls_construct_and_draw_at_phone_widths():
    from main import TrainerApp
    page = PageStub()
    app = TrainerApp(page)
    app.refresh()
    assert app.canvas.shapes
    assert app.count.value == "5"
    assert app.root.width <= page.width
    page.width = 320
    app.resize(None)
    assert app.canvas.width <= page.width
    run(app.start())


def test_intersection_point_sums_preview_selection_and_preserve_placement():
    import flet.canvas as cv
    from main import TrainerApp

    app = TrainerApp(PageStub())
    s = app.session = OpeningSession(5, 0)
    m = s.game.state.board.map
    before = BoardSnapshot.from_board(s.game.state.board)
    rng = s.game.random.getstate()
    app.node_pips.value = True
    app.pips.value = False
    app.resize(None)
    assert "Tippe" in app.victory_preview.value
    assert app.node_pips.visible and app.node_pips_hint.visible
    for width in (320, 390, 720):
        app.page.width = width
        app.resize(None)
        labels = {(shape.x, shape.y): shape.value for shape in app.canvas.shapes
                  if isinstance(shape, cv.Text)}
        for node in s.legal_nodes:
            expected = sum({2:1, 3:2, 4:3, 5:4, 6:5, 8:5, 9:4, 10:3, 11:2, 12:1}.get(tile.number, 0)
                           for tile in m.adjacent_tiles[node] if tile.resource)
            assert labels[app.geometry.nodes[node]] == str(expected)
    node = s.legal_nodes[0]
    x, y = app.geometry.nodes[node]
    assert app.geometry.hit(x, y, s.legal_nodes, s.legal_roads) == ("node", node)
    s.select_node(node)
    s.select_road(s.legal_roads[0])
    selected = (s.selected_node, s.selected_edge)
    app.toggle_pips(None)
    app.node_pips.value = False
    app.toggle_pips(None)
    assert not app.node_pips_hint.visible
    assert selected == (s.selected_node, s.selected_edge)
    assert BoardSnapshot.from_board(s.game.state.board) == before
    assert s.game.random.getstate() == rng
    s.commit()
    while not s.complete:
        s.game.execute(s.game.playable_actions[0])
    app.refresh()
    assert not app.node_pips.visible and not app.node_pips_hint.visible
    assert "≈" in app.victory_preview.value and "Runden" in app.victory_preview.value
    app.undo(None)
    assert "Tippe" in app.victory_preview.value


def test_tapping_unconfirmed_spots_updates_the_visible_win_estimate_without_roads():
    from main import TrainerApp

    app = TrainerApp(PageStub())
    s = app.session = OpeningSession(5, 0)
    app.resize(None)

    def tap_node(node):
        x, y = app.geometry.nodes[node]
        app.tap(SimpleNamespace(local_position=SimpleNamespace(x=x, y=y)))
        assert s.selected_edge is None and app.commit_btn.disabled
        assert "≈" in app.live_victory.value
        assert "Runden" in app.victory_preview.value

    before = BoardSnapshot.from_board(s.game.state.board)
    rng = s.game.random.getstate()
    tap_node(0)
    first_value = app.victory_preview.value
    assert "Vorläufig (1 Siedlung)" in app.live_victory.value
    assert "zweite Siedlung noch offen" in app.victory_context.value
    assert app.victory_context.visible
    tap_node(1)
    assert app.victory_preview.value != first_value
    assert BoardSnapshot.from_board(s.game.state.board) == before
    assert s.game.random.getstate() == rng
    # Confirm the first spot, then advance the other opening seats using only
    # legal placements. No engine client or simulation is involved in previews.
    s.select_road(s.legal_roads[0])
    s.commit()
    while not s.human_turn:
        s.game.execute(s.game.playable_actions[0])
    before_second = BoardSnapshot.from_board(s.game.state.board)
    values = []
    for node in s.legal_nodes[:4]:
        tap_node(node)
        values.append(app.victory_preview.value)
        assert app.live_victory.value.startswith("Vorschau:")
        assert "unbestätigten" in app.victory_context.value
    assert len(set(values)) > 1
    assert BoardSnapshot.from_board(s.game.state.board) == before_second
    s.select_road(s.legal_roads[0])
    expected = app.victory_preview.value
    s.commit()
    app.refresh()
    assert app.victory_preview.value == expected
    assert not app.victory_context.visible
    app.undo(None)
    assert "Vorläufig" in app.live_victory.value
    app.undo(None)
    assert "Antippen" in app.live_victory.value
    assert not app.victory_context.visible
    assert BoardSnapshot.from_board(s.game.state.board) == before
    assert s.client is None and not s.results.samples


def test_final_snapshots_match_engine_results_and_are_independent(monkeypatch):
    s = run(finish_opening(OpeningSession(89, 2)))
    opening = BoardSnapshot.from_board(s.game.state.board)
    payloads = []
    client = s.engine_client()
    original_request = client.request

    async def terminal_result(**request):
        if request["op"] != "begin":
            return await original_request(**request)
        i = len(payloads)
        payload = {"done": True, "winner": i, "turns": 80, "points": [10, 10, 4, 3],
                   "roads": [[a, b, s.game.state.colors.index(color)] for (a, b), color in opening.roads],
                   "buildings": [[node, s.game.state.colors.index(color), s.game.state.colors.index(color) == i]
                                 for node, (color, _) in opening.buildings],
                   "robber": i,
                   "awards": {"largest_army": i, "longest_road": 1, "knights": [3, 3, 3, 0],
                              "road_lengths": [6, 6, 2, 1]},
                   "activity": {"cards_bought": [3, 1, 1, 0, 2], "cards_played": [2, 1, 1, 0],
                                "player_trades": 9, "bank_trades": 4, "offers": 30}}
        payloads.append(payload)
        return payload

    monkeypatch.setattr(client, "request", terminal_result)
    run(s.simulate(1))
    first = s.results.samples[0]
    run(s.simulate(1))
    for sample, payload in zip(s.results.samples, payloads):
        assert sample.winner == s.game.state.colors[payload["winner"]]
        assert sample.points == tuple(payload["points"])
        assert dict(sample.board.buildings) == {node: (s.game.state.colors[seat], CITY if city else SETTLEMENT)
                                               for node, seat, city in payload["buildings"]}
        assert dict(sample.board.roads) == dict(opening.roads)
        assert sample.board.robber_coordinate == next(coord for coord, tile in s.game.state.board.map.land_tiles.items()
                                                       if tile.id == payload["robber"])
        assert sample.activity.player_trades == 9 and sum(sample.activity.cards_bought) == 7
        assert sample.awards.largest_army == s.game.state.colors[payload["winner"]]
        assert sample.awards.longest_road == s.game.state.colors[1]
        assert sample.awards.knights == (3, 3, 3, 0)
        assert sample.awards.road_lengths == (6, 6, 2, 1)
    assert first.board != s.results.samples[1].board
    saved = copy.deepcopy(first.board)
    for payload in payloads:
        payload["roads"].clear()
        payload["buildings"].clear()
        payload["activity"]["cards_bought"][0] = 999
        payload["awards"]["knights"][0] = 999
    assert first.board == saved
    assert first.awards.knights == (3, 3, 3, 0)
    assert BoardSnapshot.from_board(s.game.state.board) == opening
    with pytest.raises(FrozenInstanceError):
        first.board.robber_coordinate = (0, 0, 0)


def test_cancel_during_a_game_does_not_save_a_partial_board(monkeypatch):
    s = run(finish_opening(OpeningSession(83, 0)))
    run(s.simulate(1, max_turns=1))
    completed = s.results.samples[:]

    client = s.engine_client()
    original_request = client.request
    async def cancel_during_action(**request):
        result = await original_request(**request)
        if request["op"] == "step":
            s.cancelled = True
        return result
    monkeypatch.setattr(client, "request", cancel_during_action)
    run(s.simulate(2))
    assert s.results.samples == completed


def test_browser_batch_orders_results_and_does_not_reuse_seeds_after_cancel():
    s = OpeningSession(83, 0)
    while not s.complete:
        s.game.execute(s.game.playable_actions[0])
    snapshot = BoardSnapshot.from_board(s.game.state.board)
    calls = []

    class BrowserClient:
        browser = True
        stopped = False

        def cancel(self):
            self.stopped = True

        async def request(self, on_event=None, **request):
            if request["op"] == "opening":
                return {"current_player": 0, "initial_phase": False,
                        "hands": [[s.game.state.player_state[f"P{i}_{r}_IN_HAND"] for r in RESOURCES]
                                  for i in range(4)]}
            calls.append(request)
            jobs = request["jobs"]
            # The first batch is cancelled with index 0 unfinished; index 1
            # must survive. The next batch must start at 2, regardless of length.
            for done, job in enumerate(reversed(jobs[1:] if len(calls) == 1 else jobs), 1):
                payload = {"done": True, "winner": -1, "turns": 600, "points": [2, 2, 2, 2],
                    "roads": [[a, b, s.game.state.colors.index(c)] for (a, b), c in snapshot.roads],
                    "buildings": [[n, s.game.state.colors.index(c), False] for n, (c, _) in snapshot.buildings],
                    "robber": 0,
                    "awards": {"largest_army": 2, "longest_road": -1, "knights": [0, 1, 3, 0],
                               "road_lengths": [2, 3, 4, 1]},
                    "activity": {"cards_bought": [0]*5, "cards_played": [0]*4,
                        "player_trades": 0, "bank_trades": 0, "offers": 0}}
                on_event({"event": "completed", **job, "result": payload, "seconds": 1, "done": done})
            return {"cancelled": len(calls) == 1}

    s.client = BrowserClient()
    run(s.simulate(2))
    assert calls[0]["dice_mode"] == "deck36"
    assert s.cancelled and [sample.index for sample in s.results.samples] == [1]
    first = s.results.samples[0]
    assert first.awards.largest_army == s.game.state.colors[2]
    assert first.awards.longest_road is None
    run(s.simulate(2))
    assert not s.cancelled
    assert [sample.index for sample in s.results.samples] == [1, 2, 3]
    assert s.results.samples[0] == first
    assert [job["index"] for job in calls[1]["jobs"]] == [2, 3]
    for sample in s.results.samples:
        assert sample.seed == (s.seed * 1_000_003 + sample.index * 97_409 + 0xCA7A) & 0xFFFFFFFFFFFFFFFF
    assert BoardSnapshot.from_board(s.game.state.board) == snapshot
    s.cancel()
    assert s.cancelled and s.client.stopped


def test_dice_mode_validation_and_identical_assignment_preserve_results():
    s = OpeningSession(83, 0)
    assert s.dice_mode == "deck36"
    results = s.results
    s.dice_mode = "deck36"
    assert s.results is results
    with pytest.raises(ValueError, match="Würfelmodus"):
        s.dice_mode = "deck32"
    assert s.results is results and s.dice_mode == "deck36"
    with pytest.raises(ValueError):
        OpeningSession(83, 0, dice_mode="unknown")


@pytest.mark.parametrize("mode", ["deck36", "dice"])
def test_native_simulations_send_selected_dice_mode_and_restart_after_switch(mode, monkeypatch):
    s = OpeningSession(83, 0, dice_mode=mode)
    while not s.complete:
        s.game.execute(s.game.playable_actions[0])
    client = s.engine_client()
    original = client.request
    begins = []

    async def request(**payload):
        result = await original(**payload)
        if payload["op"] == "begin":
            begins.append(payload)
            assert result["dice_mode"] == payload["dice_mode"]
        return result

    monkeypatch.setattr(client, "request", request)
    try:
        run(s.simulate(1, max_turns=1))
        run(s.simulate(1, max_turns=1))
        assert [sample.index for sample in s.results.samples] == [0, 1]
        assert all(payload["dice_mode"] == mode for payload in begins)
        first_seed = s.results.samples[0].seed
        s.dice_mode = "dice" if mode == "deck36" else "deck36"
        assert not s.results.samples
        run(s.simulate(1, max_turns=1))
        assert begins[-1]["dice_mode"] == s.dice_mode
        assert s.results.samples[0].index == 0 and s.results.samples[0].seed == first_seed
    finally:
        s.close()


def test_ui_mode_switch_clears_results_preserves_opening_and_is_disabled_while_busy():
    from main import TrainerApp
    app = TrainerApp(PageStub())
    s = app.session = OpeningSession(83, 0)
    place_first(s)
    while not s.complete:
        s.game.execute(s.game.playable_actions[0])
    snapshot = BoardSnapshot.from_board(s.game.state.board)
    rng = s.game.random.getstate()
    history = s.history[:]
    records = s.game.state.action_records[:]
    sample = Sample(0, 42, s.human, 80, 1.0, (10, 2, 3, 4), snapshot)
    s.results.samples.append(sample)
    app.previous = ((s.seed, s.seat, s.random_ports, "deck36"), 1, 1)
    app.progress.visible = app.progress_text.visible = True
    app.refresh()
    assert app.dice_mode.value == "deck36" and app.result_mode.value == "36er-Kartenstapel"
    assert app.sample_picker.value == "0" and app.previous_text.visible
    app.change_dice_mode(None)
    assert s.results.samples == [sample] and app.previous is not None

    app.busy = True
    app.refresh()
    assert app.dice_mode.disabled
    app.dice_mode.value = "dice"
    app.change_dice_mode(None)
    assert s.dice_mode == "deck36" and s.results.samples == [sample]
    app.busy = False
    app.dice_mode.value = "dice"
    app.change_dice_mode(None)
    assert s.dice_mode == "dice" and app.result_mode.value == "Normale Würfel"
    assert not s.results.samples and app.previous is None
    assert not app.results_panel.visible and not app.previous_text.visible
    assert app.sample_picker.value is None and app.sample_picker.options == []
    assert app.final_canvas.shapes == [] and app.final_render_key is None
    assert not app.progress.visible and not app.progress_text.visible
    assert s.history == history and s.game.state.action_records == records
    assert BoardSnapshot.from_board(s.game.state.board) == snapshot
    assert s.game.random.getstate() == rng
    s.results.samples.append(sample)
    app.previous = ((s.seed, s.seat, s.random_ports, "deck36"), 1, 1)
    app.refresh()
    assert not app.previous_text.visible


def test_dice_mode_survives_retry_load_and_new_board(monkeypatch):
    from main import TrainerApp
    app = TrainerApp(PageStub())
    app.session.dice_mode = "dice"

    async def advance():
        app.refresh()

    monkeypatch.setattr(app, "advance", advance)
    seed = app.session.seed
    run(app.retry(None))
    assert app.session.seed == seed and app.session.dice_mode == "dice"
    app.seed.value = "83"
    run(app.load(None))
    assert app.session.seed == 83 and app.session.dice_mode == "dice"
    run(app.new_game(None))
    assert app.session.dice_mode == "dice" and app.dice_mode.value == "dice"


def test_simulation_progress_does_not_rebuild_unchanged_results(monkeypatch):
    from main import TrainerApp
    app = TrainerApp(PageStub())
    renders = []
    original = app.render_results

    def render():
        renders.append(len(app.session.results.samples))
        original()

    async def simulate(count, progress):
        before = len(renders)
        for turns in (10, 20, 30):
            progress(0, count, turns)
        assert len(renders) == before

    monkeypatch.setattr(app, "render_results", render)
    monkeypatch.setattr(app.session, "simulate", simulate)
    run(app.simulate(None))
    assert not app.busy


def test_result_selection_pips_and_resize_preserve_the_opening():
    import flet.canvas as cv
    from main import TrainerApp

    def pips(canvas):
        return [shape.value for shape in canvas.shapes if isinstance(shape, cv.Text)
                and shape.value and set(shape.value) == {"·"}]

    page = PageStub()
    app = TrainerApp(page)
    app.session = run(finish_opening(OpeningSession(5, 0)))
    s = app.session
    opening = BoardSnapshot.from_board(s.game.state.board)
    rng = s.game.state.random.getstate()
    final = s.simulation_game(0)[0]
    color = s.game.state.colors[1]
    node = final.state.buildings_by_color[color][SETTLEMENT][0]
    final.state.board.buildings[node] = (color, CITY)
    final.state.board.robber_coordinate = next(coord for coord, tile in final.state.board.map.land_tiles.items()
                                               if tile.number is not None)
    snapshot = BoardSnapshot.from_board(final.state.board)
    # More than the twelve recent summaries: every game must still be selectable.
    awards = Awards(color, s.human, (3, 3, 0, 0), (6, 6, 1, 2))
    s.results.samples = [Sample(i, i, color if i else None, 40 + i, 1.0, (2, 10, 3, 4), snapshot,
                               awards=awards if i else Awards())
                         for i in range(14)]
    app.resize(None)
    assert app.pips.value is True
    assert app.sample_picker.value == "0"
    assert len(app.sample_picker.options) == 14
    assert "Kein Sieger" in app.final_title.value
    assert "Simulationslimit" in app.final_detail.value
    assert all("Noch nicht vergeben" in row.value for row in app.final_awards.controls)
    assert len(pips(app.canvas)) == len(pips(app.final_canvas)) == 18
    assert any(isinstance(shape, cv.Text) and shape.value == "R" for shape in app.final_canvas.shapes)

    app.sample_picker.value = "1"
    app.select_sample(None)
    assert "gewinnt" in app.final_title.value
    assert "Simulationslimit" not in app.final_detail.value
    assert "Sieger" in app.final_scores.controls[1].controls[0].value
    assert COLOR_NAMES[color] in app.final_awards.controls[0].value
    assert "3 gespielte Ritter" in app.final_awards.controls[0].value
    assert "6 Straßen" in app.final_awards.controls[1].value
    assert "2 Siegpunkte" in app.final_awards.controls[1].value
    assert [row.controls[1].value for row in app.final_scores.controls] == [
        "2 Siegpunkte", "10 Siegpunkte", "3 Siegpunkte", "4 Siegpunkte"]
    app.pips.value = False
    app.toggle_pips(None)
    assert not pips(app.canvas) and not pips(app.final_canvas)
    assert app.sample_picker.value == "1"
    app.pips.value = True
    app.toggle_pips(None)
    assert len(pips(app.canvas)) == len(pips(app.final_canvas)) == 18

    s.results.samples.append(Sample(14, 14, s.human, 80, 2.0, (10, 5, 3, 4), opening))
    app.render_results()
    assert app.sample_picker.value == "1"
    assert len(app.sample_picker.options) == 15
    assert len(app.sample_rows.controls) == 12
    for width in (320, 390, 720):
        page.width = width
        app.resize(None)
        assert app.final_canvas.width <= app.root.width - 36
        assert app.final_canvas.height == app.final_geometry.height
        assert app.sample_picker.value == "1"
    assert BoardSnapshot.from_board(s.game.state.board) == opening
    assert s.game.state.random.getstate() == rng
    assert len(s.results.samples) == 15

    app.pips.value = False
    app.undo(None)
    assert not app.results_panel.visible
    assert app.sample_picker.value is None
    assert not app.sample_picker.options and not app.final_canvas.shapes
    assert not app.pips.value
    run(app.replace_session(9, 0))
    assert not app.pips.value and app.sample_picker.value is None


def test_fixed_harbor_order_matches_official_coastal_frame():
    game, _, _, _ = create_game(42, random_ports=False)
    tiles = game.state.board.map.tiles
    ccw_port_coords = [
        (2, 1, -3),   # Top
        (0, 3, -3),   # Top-Left
        (-2, 3, -1),  # Left-Top
        (-3, 2, 1),   # Left-Bottom
        (-3, 0, 3),   # Bottom-Left
        (-1, -2, 3),  # Bottom
        (1, -3, 2),   # Bottom-Right
        (3, -3, 0),   # Right
        (3, -1, -2),  # Top-Right
    ]
    assert [tiles[c].resource for c in ccw_port_coords] == [
        "SHEEP",
        None,
        "ORE",
        "WHEAT",
        None,
        "WOOD",
        "BRICK",
        None,
        None,
    ]


def test_longest_road_split_and_enemy_endpoint_rules():
    from catanatron.apply_action import yield_resources
    from catanatron.state_functions import maintain_longest_road

    game, _, _, _ = create_game(10, seat=0)
    state = game.state
    board = state.board
    p0, p1 = state.colors[0], state.colors[1]

    # Build a 5-road chain for p0: 0-1-2-9-10-29
    board.build_settlement(p0, 0, initial_build_phase=True)
    for a, b in [(0, 1), (1, 2), (2, 9), (9, 10), (10, 29)]:
        prev, cur, lengths = board.build_road(p0, (a, b))
        maintain_longest_road(state, prev, cur, lengths)
    assert board.road_color == p0 and board.road_length == 5
    assert state.player_state["P0_HAS_ROAD"] is True
    assert state.player_state["P0_VICTORY_POINTS"] == 2

    # Enemy settlement on dead-end endpoint (node 29) must NOT shorten p0's road
    board.build_settlement(p1, 27, initial_build_phase=True)
    board.build_road(p1, (27, 28))
    board.build_road(p1, (28, 29))
    prev, cur, lengths = board.build_settlement(p1, 29, initial_build_phase=False)
    maintain_longest_road(state, prev, cur, lengths)
    assert board.road_lengths[p0] == 5
    assert board.road_color == p0 and state.player_state["P0_HAS_ROAD"] is True

    # Enemy settlement splitting p0's road at node 2 (into 2 + 3, < 5) must set road_color=None and strip 2 VP
    board.build_settlement(p1, 4, initial_build_phase=True)
    board.build_road(p1, (4, 3))
    board.build_road(p1, (3, 2))
    prev, cur, lengths = board.build_settlement(p1, 2, initial_build_phase=False)
    maintain_longest_road(state, prev, cur, lengths)
    assert board.road_lengths[p0] == 3
    assert board.road_color is None and board.road_length == 0
    assert state.player_state["P0_HAS_ROAD"] is False
    assert state.player_state["P0_VICTORY_POINTS"] == 0

    # Bank depletion: single recipient gets remaining cards; multiple recipients get none
    tile = next(t for t in board.map.land_tiles.values() if t.resource is not None)
    res_idx = RESOURCES.index(tile.resource)
    nodes = list(tile.nodes.values())
    board.buildings.clear()
    board.buildings[nodes[0]] = (p0, CITY)
    bank = [19, 19, 19, 19, 19]
    bank[res_idx] = 1
    payout, depleted = yield_resources(board, bank, tile.number)
    assert tile.resource not in depleted
    assert payout[p0][res_idx] == 1

    board.buildings[nodes[2]] = (p1, SETTLEMENT)
    payout2, depleted2 = yield_resources(board, bank, tile.number)
    assert tile.resource in depleted2
    assert payout2[p0][res_idx] == 0 and payout2[p1][res_idx] == 0


def test_ai_opening_avoids_low_pip_duplicate_traps():
    for seed in (2, 42):
        s = OpeningSession(seed, seat=3)
        try:
            run(s.advance_bots())
            place_first(s)
            place_first(s)
            run(s.advance_bots())
            m = s.game.state.board.map
            for i in range(3):
                color = s.game.state.colors[i]
                nodes = s.game.state.buildings_by_color[color][SETTLEMENT]
                assert len(nodes) == 2
                pips = sum(
                    6 - abs(7 - t.number)
                    for n in nodes
                    for t in m.adjacent_tiles[n]
                    if t.resource is not None
                )
                resources = {
                    t.resource
                    for n in nodes
                    for t in m.adjacent_tiles[n]
                    if t.resource is not None
                }
                assert pips >= 16, f"seed {seed} seat {i} only got {pips} pips"
                assert len(resources) >= 3, f"seed {seed} seat {i} only covered {resources}"
        finally:
            s.close()


def test_ui_history_records_sorts_reviews_restores_and_exports(monkeypatch):
    import json
    import flet.canvas as cv
    from main import TrainerApp

    app = TrainerApp(PageStub())

    def finish_manual(seed, seat, first_idx, second_idx):
        s = OpeningSession(seed, seat)
        picks = [first_idx, second_idx]
        idx = 0
        while not s.complete:
            if s.human_turn:
                s.select_node(s.legal_nodes[picks[idx]])
                s.select_road(s.legal_roads[0])
                s.commit()
                idx += 1
            else:
                s.game.execute(s.game.playable_actions[0])
        return s

    async def fake_sim_factory(wins_mask):
        async def fake_simulate(count, progress):
            snap = BoardSnapshot.from_board(app.session.game.state.board)
            start = max(app.session.initial_sample_index,
                        max((sample.index + 1 for sample in app.session.results.samples), default=0))
            other = app.session.game.state.colors[(app.session.seat + 1) % 4]
            for offset, won in enumerate(wins_mask[:count]):
                idx = start + offset
                app.session.results.samples.append(
                    Sample(idx, 500 + idx, app.session.human if won else other, 75, 0.4, (10, 5, 4, 3), snap)
                )
                progress(offset + 1, count, 0)
        return fake_simulate

    assert app.history_empty.visible and not app.history_body.visible

    # Attempt 1 on board 5: 1/5 = 20% (bad)
    app.session = finish_manual(5, 0, 0, 0)
    app.count.value = "5"
    monkeypatch.setattr(app.session, "simulate", run(fake_sim_factory([True, False, False, False, False])))
    run(app.simulate(None))
    assert not app.history_empty.visible and app.history_body.visible
    assert app.history_store.total_boards == 1 and app.history_store.total_attempts == 1

    # Attempt 2 on board 5: 4/5 = 80% (good) — must rank #1 above 20%
    app.session = finish_manual(5, 0, 2, 1)
    good_nodes = app.session.opening_placements()[0][0], app.session.opening_placements()[7][0]
    monkeypatch.setattr(app.session, "simulate", run(fake_sim_factory([True, True, True, True, False])))
    run(app.simulate(None))
    assert app.history_store.total_boards == 1 and app.history_store.total_attempts == 2
    assert "#1 · 80 % gewonnen" in app.attempt_rows.controls[0].content.controls[0].controls[0].value
    assert "#2 · 20 % gewonnen" in app.attempt_rows.controls[1].content.controls[0].controls[0].value

    # Board 9: 3/6 = 50% (neutral, since good is strictly > 50%)
    app.session = finish_manual(9, 1, 0, 0)
    app.count.value = "6"
    monkeypatch.setattr(app.session, "simulate", run(fake_sim_factory([True, True, True, False, False, False])))
    run(app.simulate(None))
    assert app.history_store.total_boards == 2
    assert "Mittel" in app.attempt_rows.controls[0].content.controls[0].controls[1].content.value

    # Switch back to board 5 via dropdown and inspect both review canvas modes across widths
    app.board_picker.value = "5:0"
    app.select_history_board(None)
    texts = [shape.value for shape in app.review_canvas.shapes if isinstance(shape, cv.Text)]
    assert "1" in texts and "2" in texts

    app.show_spots_view(None)
    spot_texts = [shape.value for shape in app.review_canvas.shapes if isinstance(shape, cv.Text)]
    assert "80%" in spot_texts and "20%" in spot_texts
    for width in (280, 390, 720):
        app.page.width = width
        app.resize(None)
        assert app.review_canvas.width <= app.root.width - 36

    # Restore the #1 opening on board 5 and run 2 more games: must start at sample index 5 and merge to 6/7
    app.show_attempt_view(None)
    app.load_history_attempt(None)
    assert app.session.seed == 5 and app.session.complete
    assert app.session.initial_sample_index == 5
    assert app.sim_btn.content == "Weitere simulieren"
    assert (app.session.opening_placements()[0][0], app.session.opening_placements()[7][0]) == good_nodes
    app.count.value = "2"
    monkeypatch.setattr(app.session, "simulate", run(fake_sim_factory([True, True])))
    run(app.simulate(None))
    assert [sample.index for sample in app.session.results.samples] == [5, 6]
    merged = app.history_store.get_board(5, False).sorted_attempts()[0]
    assert merged.wins == 6 and merged.decided == 7 and merged.next_index == 7

    # Export and clipboard copy produce valid ranked JSON
    run(app.export_history(None))
    exported = json.loads(app.last_exported_json)
    assert [b["seed"] for b in exported["boards"]] == [5, 9]
    assert exported["boards"][0]["attempts"][0]["wins"] == 6
    run(app.copy_history(None))
    assert app.history_notice.visible and "Zwischenablage" in app.history_notice.value

    # Deleting an attempt updates the board list cleanly
    run(app.delete_history_attempt(None))
    assert len(app.history_store.get_board(5, False).attempts) == 1


def test_match_results_show_drawn_vp_cards_knights_and_clickable_samples():
    from trainer.engine import Activity
    from main import TrainerApp

    app = TrainerApp(PageStub())
    app.session = run(finish_opening(OpeningSession(17, 1)))
    s = app.session
    colors = s.game.state.colors
    snap = BoardSnapshot.from_board(s.game.state.board)
    buildings0 = dict(snap.buildings)
    for node, (owner, _) in list(buildings0.items()):
        if owner == colors[0]:
            buildings0[node] = (owner, CITY)
    snap0 = BoardSnapshot(snap.roads, tuple(sorted(buildings0.items())), snap.robber_coordinate)
    s.results.samples = [
        Sample(
            index=0,
            seed=101,
            winner=colors[0],
            turns=64,
            seconds=0.8,
            points=(10, 4, 3, 2),
            board=snap0,
            activity=Activity(cards_bought=(4, 0, 0, 0, 4), cards_played=(3, 0, 0, 0), player_trades=2, bank_trades=1, offers=5),
            awards=Awards(largest_army=colors[0], longest_road=colors[2], knights=(3, 2, 1, 0), road_lengths=(4, 3, 6, 2)),
        ),
        Sample(
            index=1,
            seed=102,
            winner=colors[1],
            turns=71,
            seconds=0.9,
            points=(3, 10, 5, 2),
            board=snap,
            activity=Activity(cards_bought=(5, 1, 0, 0, 8), cards_played=(4, 1, 0, 0)),
            awards=Awards(largest_army=colors[1], longest_road=None, knights=(1, 4, 2, 0), road_lengths=(3, 4, 5, 2)),
        ),
    ]
    app.refresh()
    assert len(app.sample_rows.controls) == 2
    # Seat 0 has 2 cities (4 VP) + largest army (2 VP) = 6 VP -> 4 drawn VP cards; 3 knights
    seat0_detail = app.final_scores.controls[0].controls[2].content.value
    seat1_detail = app.final_scores.controls[1].controls[2].content.value
    assert "SP-Karten vom Stapel: 4" in seat0_detail and "Ritter: 3 (Größte Rittermacht)" in seat0_detail
    assert "SP-Karten vom Stapel: 2" in seat1_detail and "Ritter: 2" in seat1_detail
    assert "4 Siegpunkt-Karten gezogen" in app.final_activity.value

    # Tapping the second sample chip updates the selected sample and detailed breakdown
    app.select_sample_chip(SimpleNamespace(control=SimpleNamespace(data="1")))
    assert app.sample_picker.value == "1"
    assert "Partie 2" in app.final_title.value
    assert "SP-Karten vom Stapel: 6" in app.final_scores.controls[1].controls[2].content.value
    assert "Ritter: 4 (Größte Rittermacht)" in app.final_scores.controls[1].controls[2].content.value


def test_navigation_tabs_and_history_saved_matches_inspector(monkeypatch):
    from trainer.engine import Activity
    from main import TrainerApp

    app = TrainerApp(PageStub())
    assert app.active_tab == "play"
    assert app.play_section.visible and not app.history_panel.visible and not app.setup_section.visible
    assert app.page.navigation_bar is app.nav_bar
    assert len(app.nav_bar.destinations) == 3

    app.switch_tab("history")
    assert app.active_tab == "history"
    assert not app.play_section.visible and app.history_panel.visible and not app.setup_section.visible
    assert app.nav_bar.selected_index == 1

    app.nav_bar.selected_index = 2
    app.on_nav_change(None)
    assert app.active_tab == "setup"
    assert not app.play_section.visible and not app.history_panel.visible and app.setup_section.visible

    app.session = run(finish_opening(OpeningSession(23, 0)))
    colors = app.session.game.state.colors
    snap = BoardSnapshot.from_board(app.session.game.state.board)

    async def fake_sim(count, progress):
        app.session.results.samples.append(
            Sample(
                index=0,
                seed=777,
                winner=colors[0],
                turns=58,
                seconds=0.7,
                points=(10, 4, 3, 2),
                board=snap,
                activity=Activity(cards_bought=(3, 0, 0, 0, 6), cards_played=(3, 0, 0, 0)),
                awards=Awards(largest_army=colors[0], longest_road=None, knights=(3, 2, 1, 0), road_lengths=(4, 3, 2, 2)),
            )
        )
        progress(1, count, 0)

    monkeypatch.setattr(app.session, "simulate", fake_sim)
    app.count.value = "1"
    run(app.simulate(None))
    assert app.nav_bar.destinations[1].badge == "1"

    app.switch_tab("history")
    app.show_matches_view(None)
    assert app.history_match_picker.visible
    assert len(app.history_match_picker.options) == 1
    assert len(app.history_match_chips.controls) == 1
    assert app.history_match_scores.visible
    assert "SP-Karten vom Stapel: 6" in app.history_match_scores.controls[0].controls[2].content.value
    assert "Ritter: 3 (Größte Rittermacht)" in app.history_match_scores.controls[0].controls[2].content.value
    assert "Ritter: 2" in app.history_match_scores.controls[1].controls[2].content.value

    # Loading an attempt from history automatically switches back to the play tab
    app.load_history_attempt(None)
    assert app.active_tab == "play"
    assert app.play_section.visible and not app.history_panel.visible
    assert app.nav_bar.selected_index == 0


def test_native_engine_exposes_devs_and_ui_renders_action_cards():
    import flet.canvas as cv
    from trainer.engine import Activity
    from main import TrainerApp

    s = OpeningSession(42, 0)
    try:
        run(finish_opening(s))
        run(s.simulate(1))
        sample = s.results.samples[0]
        assert len(sample.devs_in_hand) == 4
        assert len(sample.devs_played) == 4
        assert all(len(row) == 5 for row in sample.devs_in_hand)
        assert all(len(row) == 5 for row in sample.devs_played)
        colors = s.game.state.colors
        stats = sample.player_stats(colors)
        for i in range(4):
            assert stats[i].knights == sample.awards.knights[i]
            assert stats[i].knights_in_hand == sample.devs_in_hand[i][0]
            assert stats[i].yop_played == sample.devs_played[i][1]
            assert stats[i].monopoly_played == sample.devs_played[i][2]
            assert stats[i].road_building_played == sample.devs_played[i][3]
    finally:
        s.close()

    app = TrainerApp(PageStub())
    app.session = run(finish_opening(OpeningSession(21, 0)))
    try:
        colors = app.session.game.state.colors
        snap = BoardSnapshot.from_board(app.session.game.state.board)
        app.session.results.samples = [
            Sample(
                index=0,
                seed=888,
                winner=colors[0],
                turns=62,
                seconds=0.8,
                points=(10, 5, 3, 2),
                board=snap,
                activity=Activity(cards_bought=(4, 1, 1, 2, 1), cards_played=(2, 1, 1, 2)),
                awards=Awards(largest_army=None, longest_road=None, knights=(2, 1, 0, 0), road_lengths=(4, 3, 2, 2)),
                devs_in_hand=((2, 0, 0, 0, 1), (0, 0, 0, 0, 0), (1, 0, 0, 0, 0), (0, 0, 0, 0, 0)),
                devs_played=((2, 1, 0, 2, 0), (1, 0, 1, 0, 0), (0, 0, 0, 0, 0), (0, 0, 0, 0, 0)),
            )
        ]
        app.refresh()
        seat0_detail = app.final_scores.controls[0].controls[2].content.value
        seat1_detail = app.final_scores.controls[1].controls[2].content.value
        assert "Ritter: 2 (+2 Hand)" in seat0_detail
        assert "Aktionen: Erfindung, 2× Straßenbau" in seat0_detail
        assert "Aktionen: Monopol" in seat1_detail
    finally:
        app.session.close()


def test_ai_opening_compare_and_apply():
    import flet.canvas as cv
    from main import TrainerApp

    app = TrainerApp(PageStub())
    app.session = OpeningSession(31, 1)
    try:
        run(app.session.advance_bots())
        run(app.toggle_ai_opening(None))
        assert app.show_ai_opening is True
        assert app.ai_opening_text.visible is True
        assert "KI-Wahl (Startplatz 2):" in app.ai_opening_text.value
        labels = {shape.value for shape in app.canvas.shapes if isinstance(shape, cv.Text)}
        assert "KI 1" in labels and "KI 2" in labels

        run(app.toggle_ai_opening(None))
        assert app.show_ai_opening is False
        labels_after = {shape.value for shape in app.canvas.shapes if isinstance(shape, cv.Text)}
        assert "KI 1" not in labels_after

        run(app.apply_ai_opening(None))
        assert app.session.complete is True
        assert app.session.opening_placements() == app.session.ai_placements_cache
        assert app.show_ai_opening is True
        assert len(app.session.opening_placements()) == 8
    finally:
        app.session.close()


def test_history_spot_seat_filter_tap_review_json_import_and_responsive_nav():
    from main import TrainerApp

    app = TrainerApp(PageStub())
    try:
        # PageStub.width == 390 (< 520) auto-hides top tab_bar while keeping bottom nav_bar
        assert app.tab_bar.visible is False
        assert app.page.navigation_bar is app.nav_bar

        app.page.width = 640
        app.resize(None)
        assert app.tab_bar.visible is True

        app.page.width = 390
        app.resize(None)
        assert app.tab_bar.visible is False

        s0 = run(finish_opening(OpeningSession(42, 0)))
        colors0 = s0.game.state.colors
        snap0 = BoardSnapshot.from_board(s0.game.state.board)
        app.history_store.record_samples(s0, [
            Sample(0, 10, colors0[0], 50, 0.3, (10, 4, 3, 2), snap0),
        ], now="2026-11-15T10:00:00Z")

        s1 = run(finish_opening(OpeningSession(42, 1)))
        colors1 = s1.game.state.colors
        snap1 = BoardSnapshot.from_board(s1.game.state.board)
        app.history_store.record_samples(s1, [
            Sample(0, 20, colors1[2], 60, 0.4, (4, 5, 10, 3), snap1),
        ], now="2026-11-15T11:00:00Z")
        s0.close()
        s1.close()

        app.switch_tab("history")
        app.show_spots_view(None)
        assert app.spot_seat_chips.visible is True
        assert len(app.spot_seat_chips.controls) == 5

        # Filter by Platz 2 (seat 1)
        app.select_spot_seat(SimpleNamespace(control=SimpleNamespace(data=1)))
        assert app.history_spot_seat == 1
        assert "Platz 2" in app.review_title.value
        assert "2 getestete Siedlungsplätze" in app.review_title.value

        # Reset to Alle and tap a tested node on the review canvas
        app.select_spot_seat(SimpleNamespace(control=SimpleNamespace(data=None)))
        tested_node = app.history_store.boards[(42, False)].attempts[0].human_nodes[0]
        nx, ny = app.review_geometry.nodes[tested_node]
        app.tap_review_board(SimpleNamespace(local_position=SimpleNamespace(x=nx, y=ny)))
        assert app.selected_review_node == tested_node
        assert f"Ausgewählt (K{tested_node}):" in app.review_cards.value

        # JSON import merges new boards from another store and via paste_import_history fallback
        from trainer.history import HistoryStore
        external = HistoryStore()
        s_ext = run(finish_opening(OpeningSession(77, 0)))
        snap_ext = BoardSnapshot.from_board(s_ext.game.state.board)
        external.record_samples(s_ext, [
            Sample(0, 30, s_ext.game.state.colors[0], 55, 0.3, (10, 3, 2, 2), snap_ext),
        ], now="2026-11-15T12:00:00Z")
        s_ext.close()

        run(app._apply_imported_json(external.to_export_json(exported_at="2026-11-15T12:05:00Z")))
        assert app.history_store.total_boards == 2
        assert "Importiert: 1 neue, 0 aktualisierte Versuche." == app.history_notice.value

        app.last_exported_json = app.history_store.to_storage_json()
        run(app.paste_import_history(None))
        assert app.history_notice.value == "Keine neuen oder neueren Einträge im JSON gefunden."
    finally:
        app.session.close()




import asyncio
import copy
from collections import Counter
from dataclasses import FrozenInstanceError
import random
from types import SimpleNamespace

import pytest
from catanatron.models.enums import Action, ActionType, CITY, RESOURCES, SETTLEMENT
from catanatron.models.map import BASE_NUMBERS_IN_SPIRAL_ORDER
from trainer.engine import Awards, BoardSnapshot, OpeningSession, Sample, COLOR_NAMES, CORNERS, create_game, decide_cooperatively
from trainer.board import BoardGeometry


def run(coro):
    return asyncio.run(coro)


def place_first(session):
    session.select_node(session.legal_nodes[0])
    session.select_road(session.legal_roads[0])
    session.commit()


async def finish_opening(session):
    await session.advance_bots()
    while not session.complete:
        place_first(session)
        await session.advance_bots()
    return session


def board_fingerprint(session):
    m = session.game.state.board.map
    return (tuple((coord, t.resource, t.number) for coord, t in m.land_tiles.items()),
            tuple((t.id, t.resource) for t in m.ports_by_id.values()))


class PageStub:
    width = 390

    def add(self, control):
        self.control = control

    def update(self):
        pass


def test_spiral_all_six_corners_against_independent_ring_order():
    outer = [(2,-2,0),(2,-1,-1),(2,0,-2),(1,1,-2),(0,2,-2),(-1,2,-1),
             (-2,2,0),(-2,1,1),(-2,0,2),(-1,-1,2),(0,-2,2),(1,-2,1)]
    inner = [(1,-1,0),(1,0,-1),(0,1,-1),(-1,1,0),(-1,0,1),(0,-1,1)]
    seen = set()
    for seed in range(60):
        game, _, _, corner = create_game(seed)
        rotations = CORNERS.index(corner)
        expected_coords = []
        for coord in outer + inner + [(0,0,0)]:
            for _ in range(rotations):
                x,y,z = coord
                coord = (-y,-z,-x)
            expected_coords.append(coord)
        tiles = game.state.board.map.land_tiles
        numbers = [tiles[c].number for c in expected_coords if tiles[c].resource is not None]
        assert numbers == BASE_NUMBERS_IN_SPIRAL_ORDER
        assert Counter(t.resource for t in tiles.values()) == {"WOOD":4,"BRICK":3,"SHEEP":4,"WHEAT":4,"ORE":3,None:1}
        seen.add(corner)
    assert seen == set(CORNERS)


@pytest.mark.parametrize("seat", range(4))
def test_opening_snake_order_distance_rule_and_start_cards(seat):
    s = OpeningSession(56, seat)
    game = s.game
    placements = []
    while game.state.is_initial_build_phase:
        action = game.playable_actions[0]
        if action.action_type == ActionType.BUILD_SETTLEMENT:
            color = action.color
            existing = len(game.state.buildings_by_color[color][SETTLEMENT])
            game.execute(action)
            placements.append(color)
            key = f"P{game.state.color_to_index[color]}"
            hand = {r: game.state.player_state[f"{key}_{r}_IN_HAND"] for r in RESOURCES}
            expected = Counter(t.resource for t in game.state.board.map.adjacent_tiles[action.value] if t.resource)
            assert hand == (dict.fromkeys(RESOURCES,0) if existing == 0 else {r:expected[r] for r in RESOURCES})
        else:
            last = game.state.buildings_by_color[action.color][SETTLEMENT][-1]
            assert last in action.value
            game.execute(action)
    assert placements == list(game.state.colors) + list(reversed(game.state.colors))
    nodes = list(game.state.board.buildings)
    for tile in game.state.board.map.land_tiles.values():
        for edge in tile.edges.values():
            assert not set(edge).issubset(nodes)
    assert len(game.state.board.buildings) == 8
    assert len({tuple(sorted(e)) for e in game.state.board.roads}) == 8


def test_selection_is_transactional_and_rejects_illegal_road():
    s = OpeningSession(7, 0)
    s.select_node(s.legal_nodes[0])
    assert not s.game.state.board.buildings
    assert not s.starting_resources()["WOOD"]
    assert 1 <= len(s.legal_roads) <= 3
    with pytest.raises(ValueError):
        s.select_road((1000,1001))
    with pytest.raises(ValueError):
        s.commit()
    assert not s.game.state.board.buildings
    s.select_road(s.legal_roads[0])
    s.commit()
    assert len(s.game.state.board.buildings) == 1
    assert len({tuple(sorted(e)) for e in s.game.state.board.roads}) == 1


def test_replay_and_fixed_ports_are_reproducible():
    s = OpeningSession(77)
    other = OpeningSession(77, s.seat)
    assert s.human == other.human
    assert board_fingerprint(s) == board_fingerprint(other)
    ports = board_fingerprint(s)[1]
    assert ports == board_fingerprint(OpeningSession(99))[1]
    assert len({board_fingerprint(OpeningSession(i,random_ports=True))[1] for i in range(8)}) > 1


def test_undo_restores_rng_and_opponent_placements():
    s = OpeningSession(4,0)
    state_before = copy.deepcopy(s.game.state)
    place_first(s)
    run(s.advance_bots())
    assert len(s.game.state.board.buildings) > 1
    assert s.undo()
    assert s.game.state.board.buildings == state_before.board.buildings
    assert s.game.state.random.getstate() == state_before.random.getstate()
    assert s.human_turn
    assert not s.undo()


def test_geometry_and_road_touch_on_phone():
    s = OpeningSession(5,0)
    for width in (280,328,390,688):
        g = BoardGeometry(s.game.state.board.map,width)
        assert len(g.nodes) == 54
        for x,y in g.nodes.values():
            assert 0 <= x <= g.width
            assert 0 <= y <= g.height
        for t in s.game.state.board.map.land_tiles.values():
            for a,b in t.edges.values():
                x,y = g.nodes[a]
                u,v = g.nodes[b]
                assert ((x-u)**2+(y-v)**2)**.5 == pytest.approx(g.radius)
        for _,_,(x,y) in g.ports:
            assert 0 <= x <= g.width
            assert 0 <= y <= g.height
        node = s.legal_nodes[0]
        s.select_node(node)
        for edge in s.legal_roads:
            assert g.hit(*g.midpoint(edge),s.legal_nodes,s.legal_roads) == ("road",edge)


def test_opening_bot_matches_catanatron_alpha_beta_depth_two():
    from catanatron.players.minimax import AlphaBetaPlayer
    s = OpeningSession(8,0)
    assert all(type(player) is AlphaBetaPlayer and player.params.depth == 2 for player in s.game.state.players)
    reference = copy.deepcopy(s.game)
    expected = reference.state.current_player().decide(reference,reference.playable_actions)
    before = s.game.state.random.getstate()
    assert run(decide_cooperatively(s.game)) == expected
    assert before == s.game.state.random.getstate()


def test_alpha_beta_matches_upstream_during_game_and_preserves_rng():
    s = run(finish_opening(OpeningSession(83, 3)))
    branching_colors = set()
    for _ in range(50):
        game = s.game
        if game.winning_color() is not None:
            break
        reference = copy.deepcopy(game)
        expected = reference.state.current_player().decide(reference, reference.playable_actions)
        before = game.state.random.getstate()
        actual = run(decide_cooperatively(game))
        assert actual == expected
        assert before == game.state.random.getstate()
        if len(game.playable_actions) > 1:
            branching_colors.add(game.state.current_color())
        game.execute(actual)
    assert len(branching_colors) > 1


def test_alpha_beta_can_stop_within_a_search_without_advancing_game():
    s = OpeningSession(8, 0)
    before = copy.deepcopy(s.game.state)
    checkpoints = 0

    def stop_during_search():
        nonlocal checkpoints
        checkpoints += 1
        return checkpoints >= 5

    assert run(decide_cooperatively(s.game, stop_during_search)) is None
    assert s.game.state.board.buildings == before.board.buildings
    assert s.game.state.random.getstate() == before.random.getstate()


def test_simulation_clones_have_independent_rng_and_development_decks():
    s = run(finish_opening(OpeningSession(83,3)))
    original_rng = s.game.state.random.getstate()
    a,seed_a = s.simulation_game(0)
    b,seed_b = s.simulation_game(0)
    c,seed_c = s.simulation_game(1)
    assert seed_a == seed_b != seed_c
    assert a.state.random is a.random
    assert a.random is not b.random and a.random is not s.game.random
    assert a.state.development_listdeck == b.state.development_listdeck
    a.random.random()
    assert original_rng == s.game.state.random.getstate()
    assert a.state.development_listdeck is not b.state.development_listdeck
    assert Counter(a.state.development_listdeck) == Counter(s.game.state.development_listdeck)


def test_off_turn_points_do_not_end_game():
    s = OpeningSession(3,0)
    game = s.game
    c = game.state.colors[1]
    game.state.player_state[f"P1_ACTUAL_VICTORY_POINTS"] = 10
    assert game.winning_color() is None
    game.state.current_turn_index = 1
    assert game.winning_color() == c
    assert game.copy().winning_color() == c


def test_cutoffs_and_cancel_are_not_counted_as_losses_or_duplicate_samples():
    s = run(finish_opening(OpeningSession(89,2)))
    fingerprint = board_fingerprint(s)
    buildings = dict(s.game.state.board.buildings)
    rng_state = s.game.state.random.getstate()
    run(s.simulate(2,max_turns=1))
    assert len(s.results.samples) == 2
    assert s.results.decided == 0 and s.results.limited == 2
    def cancel_after_first(done,total,turns):
        if done:
            s.cancelled = True
    run(s.simulate(5,cancel_after_first,max_turns=1))
    assert [sample.index for sample in s.results.samples] == [0,1,2]
    run(s.simulate(1,max_turns=1))
    assert [sample.index for sample in s.results.samples] == [0,1,2,3]
    assert len({sample.seed for sample in s.results.samples}) == 4
    assert fingerprint == board_fingerprint(s)
    assert buildings == s.game.state.board.buildings
    assert rng_state == s.game.state.random.getstate()
    assert all(sample.board == BoardSnapshot.from_board(s.game.state.board) for sample in s.results.samples)
    for count in (0,-1,1001):
        with pytest.raises(ValueError):
            run(s.simulate(count))


def test_flet_controls_construct_and_draw_at_phone_widths():
    from main import TrainerApp
    page = PageStub()
    app = TrainerApp(page)
    app.refresh()
    assert app.canvas.shapes
    assert app.count.value == "5"
    assert app.root.width <= page.width
    page.width = 320
    app.resize(None)
    assert app.canvas.width <= page.width
    run(app.start())


def test_intersection_point_sums_preview_selection_and_preserve_placement():
    import flet.canvas as cv
    from main import TrainerApp

    app = TrainerApp(PageStub())
    s = app.session = OpeningSession(5, 0)
    m = s.game.state.board.map
    before = BoardSnapshot.from_board(s.game.state.board)
    rng = s.game.random.getstate()
    app.node_pips.value = True
    app.pips.value = False
    app.resize(None)
    assert "Tippe" in app.victory_preview.value
    assert app.node_pips.visible and app.node_pips_hint.visible
    for width in (320, 390, 720):
        app.page.width = width
        app.resize(None)
        labels = {(shape.x, shape.y): shape.value for shape in app.canvas.shapes
                  if isinstance(shape, cv.Text)}
        for node in s.legal_nodes:
            expected = sum({2:1, 3:2, 4:3, 5:4, 6:5, 8:5, 9:4, 10:3, 11:2, 12:1}.get(tile.number, 0)
                           for tile in m.adjacent_tiles[node] if tile.resource)
            assert labels[app.geometry.nodes[node]] == str(expected)
    node = s.legal_nodes[0]
    x, y = app.geometry.nodes[node]
    assert app.geometry.hit(x, y, s.legal_nodes, s.legal_roads) == ("node", node)
    s.select_node(node)
    s.select_road(s.legal_roads[0])
    selected = (s.selected_node, s.selected_edge)
    app.toggle_pips(None)
    app.node_pips.value = False
    app.toggle_pips(None)
    assert not app.node_pips_hint.visible
    assert selected == (s.selected_node, s.selected_edge)
    assert BoardSnapshot.from_board(s.game.state.board) == before
    assert s.game.random.getstate() == rng
    s.commit()
    while not s.complete:
        s.game.execute(s.game.playable_actions[0])
    app.refresh()
    assert not app.node_pips.visible and not app.node_pips_hint.visible
    assert "≈" in app.victory_preview.value and "Runden" in app.victory_preview.value
    app.undo(None)
    assert "Tippe" in app.victory_preview.value


def test_tapping_unconfirmed_spots_updates_the_visible_win_estimate_without_roads():
    from main import TrainerApp

    app = TrainerApp(PageStub())
    s = app.session = OpeningSession(5, 0)
    app.resize(None)

    def tap_node(node):
        x, y = app.geometry.nodes[node]
        app.tap(SimpleNamespace(local_position=SimpleNamespace(x=x, y=y)))
        assert s.selected_edge is None and app.commit_btn.disabled
        assert "≈" in app.live_victory.value
        assert "Runden" in app.victory_preview.value

    before = BoardSnapshot.from_board(s.game.state.board)
    rng = s.game.random.getstate()
    tap_node(0)
    first_value = app.victory_preview.value
    assert "Vorläufig (1 Siedlung)" in app.live_victory.value
    assert "zweite Siedlung noch offen" in app.victory_context.value
    assert app.victory_context.visible
    tap_node(1)
    assert app.victory_preview.value != first_value
    assert BoardSnapshot.from_board(s.game.state.board) == before
    assert s.game.random.getstate() == rng
    # Confirm the first spot, then advance the other opening seats using only
    # legal placements. No engine client or simulation is involved in previews.
    s.select_road(s.legal_roads[0])
    s.commit()
    while not s.human_turn:
        s.game.execute(s.game.playable_actions[0])
    before_second = BoardSnapshot.from_board(s.game.state.board)
    values = []
    for node in s.legal_nodes[:4]:
        tap_node(node)
        values.append(app.victory_preview.value)
        assert app.live_victory.value.startswith("Vorschau:")
        assert "unbestätigten" in app.victory_context.value
    assert len(set(values)) > 1
    assert BoardSnapshot.from_board(s.game.state.board) == before_second
    s.select_road(s.legal_roads[0])
    expected = app.victory_preview.value
    s.commit()
    app.refresh()
    assert app.victory_preview.value == expected
    assert not app.victory_context.visible
    app.undo(None)
    assert "Vorläufig" in app.live_victory.value
    app.undo(None)
    assert "Antippen" in app.live_victory.value
    assert not app.victory_context.visible
    assert BoardSnapshot.from_board(s.game.state.board) == before
    assert s.client is None and not s.results.samples


def test_final_snapshots_match_engine_results_and_are_independent(monkeypatch):
    s = run(finish_opening(OpeningSession(89, 2)))
    opening = BoardSnapshot.from_board(s.game.state.board)
    payloads = []
    client = s.engine_client()
    original_request = client.request

    async def terminal_result(**request):
        if request["op"] != "begin":
            return await original_request(**request)
        i = len(payloads)
        payload = {"done": True, "winner": i, "turns": 80, "points": [10, 10, 4, 3],
                   "roads": [[a, b, s.game.state.colors.index(color)] for (a, b), color in opening.roads],
                   "buildings": [[node, s.game.state.colors.index(color), s.game.state.colors.index(color) == i]
                                 for node, (color, _) in opening.buildings],
                   "robber": i,
                   "awards": {"largest_army": i, "longest_road": 1, "knights": [3, 3, 3, 0],
                              "road_lengths": [6, 6, 2, 1]},
                   "activity": {"cards_bought": [3, 1, 1, 0, 2], "cards_played": [2, 1, 1, 0],
                                "player_trades": 9, "bank_trades": 4, "offers": 30}}
        payloads.append(payload)
        return payload

    monkeypatch.setattr(client, "request", terminal_result)
    run(s.simulate(1))
    first = s.results.samples[0]
    run(s.simulate(1))
    for sample, payload in zip(s.results.samples, payloads):
        assert sample.winner == s.game.state.colors[payload["winner"]]
        assert sample.points == tuple(payload["points"])
        assert dict(sample.board.buildings) == {node: (s.game.state.colors[seat], CITY if city else SETTLEMENT)
                                               for node, seat, city in payload["buildings"]}
        assert dict(sample.board.roads) == dict(opening.roads)
        assert sample.board.robber_coordinate == next(coord for coord, tile in s.game.state.board.map.land_tiles.items()
                                                       if tile.id == payload["robber"])
        assert sample.activity.player_trades == 9 and sum(sample.activity.cards_bought) == 7
        assert sample.awards.largest_army == s.game.state.colors[payload["winner"]]
        assert sample.awards.longest_road == s.game.state.colors[1]
        assert sample.awards.knights == (3, 3, 3, 0)
        assert sample.awards.road_lengths == (6, 6, 2, 1)
    assert first.board != s.results.samples[1].board
    saved = copy.deepcopy(first.board)
    for payload in payloads:
        payload["roads"].clear()
        payload["buildings"].clear()
        payload["activity"]["cards_bought"][0] = 999
        payload["awards"]["knights"][0] = 999
    assert first.board == saved
    assert first.awards.knights == (3, 3, 3, 0)
    assert BoardSnapshot.from_board(s.game.state.board) == opening
    with pytest.raises(FrozenInstanceError):
        first.board.robber_coordinate = (0, 0, 0)


def test_cancel_during_a_game_does_not_save_a_partial_board(monkeypatch):
    s = run(finish_opening(OpeningSession(83, 0)))
    run(s.simulate(1, max_turns=1))
    completed = s.results.samples[:]

    client = s.engine_client()
    original_request = client.request
    async def cancel_during_action(**request):
        result = await original_request(**request)
        if request["op"] == "step":
            s.cancelled = True
        return result
    monkeypatch.setattr(client, "request", cancel_during_action)
    run(s.simulate(2))
    assert s.results.samples == completed


def test_browser_batch_orders_results_and_does_not_reuse_seeds_after_cancel():
    s = OpeningSession(83, 0)
    while not s.complete:
        s.game.execute(s.game.playable_actions[0])
    snapshot = BoardSnapshot.from_board(s.game.state.board)
    calls = []

    class BrowserClient:
        browser = True
        stopped = False

        def cancel(self):
            self.stopped = True

        async def request(self, on_event=None, **request):
            if request["op"] == "opening":
                return {"current_player": 0, "initial_phase": False,
                        "hands": [[s.game.state.player_state[f"P{i}_{r}_IN_HAND"] for r in RESOURCES]
                                  for i in range(4)]}
            calls.append(request)
            jobs = request["jobs"]
            # The first batch is cancelled with index 0 unfinished; index 1
            # must survive. The next batch must start at 2, regardless of length.
            for done, job in enumerate(reversed(jobs[1:] if len(calls) == 1 else jobs), 1):
                payload = {"done": True, "winner": -1, "turns": 600, "points": [2, 2, 2, 2],
                    "roads": [[a, b, s.game.state.colors.index(c)] for (a, b), c in snapshot.roads],
                    "buildings": [[n, s.game.state.colors.index(c), False] for n, (c, _) in snapshot.buildings],
                    "robber": 0,
                    "awards": {"largest_army": 2, "longest_road": -1, "knights": [0, 1, 3, 0],
                               "road_lengths": [2, 3, 4, 1]},
                    "activity": {"cards_bought": [0]*5, "cards_played": [0]*4,
                        "player_trades": 0, "bank_trades": 0, "offers": 0}}
                on_event({"event": "completed", **job, "result": payload, "seconds": 1, "done": done})
            return {"cancelled": len(calls) == 1}

    s.client = BrowserClient()
    run(s.simulate(2))
    assert s.cancelled and [sample.index for sample in s.results.samples] == [1]
    first = s.results.samples[0]
    assert first.awards.largest_army == s.game.state.colors[2]
    assert first.awards.longest_road is None
    run(s.simulate(2))
    assert not s.cancelled
    assert [sample.index for sample in s.results.samples] == [1, 2, 3]
    assert s.results.samples[0] == first
    assert [job["index"] for job in calls[1]["jobs"]] == [2, 3]
    for sample in s.results.samples:
        assert sample.seed == (s.seed * 1_000_003 + sample.index * 97_409 + 0xCA7A) & 0xFFFFFFFFFFFFFFFF
    assert BoardSnapshot.from_board(s.game.state.board) == snapshot
    s.cancel()
    assert s.cancelled and s.client.stopped


def test_simulation_progress_does_not_rebuild_unchanged_results(monkeypatch):
    from main import TrainerApp
    app = TrainerApp(PageStub())
    renders = []
    original = app.render_results

    def render():
        renders.append(len(app.session.results.samples))
        original()

    async def simulate(count, progress):
        before = len(renders)
        for turns in (10, 20, 30):
            progress(0, count, turns)
        assert len(renders) == before

    monkeypatch.setattr(app, "render_results", render)
    monkeypatch.setattr(app.session, "simulate", simulate)
    run(app.simulate(None))
    assert not app.busy


def test_result_selection_pips_and_resize_preserve_the_opening():
    import flet.canvas as cv
    from main import TrainerApp

    def pips(canvas):
        return [shape.value for shape in canvas.shapes if isinstance(shape, cv.Text)
                and shape.value and set(shape.value) == {"·"}]

    page = PageStub()
    app = TrainerApp(page)
    app.session = run(finish_opening(OpeningSession(5, 0)))
    s = app.session
    opening = BoardSnapshot.from_board(s.game.state.board)
    rng = s.game.state.random.getstate()
    final = s.simulation_game(0)[0]
    color = s.game.state.colors[1]
    node = final.state.buildings_by_color[color][SETTLEMENT][0]
    final.state.board.buildings[node] = (color, CITY)
    final.state.board.robber_coordinate = next(coord for coord, tile in final.state.board.map.land_tiles.items()
                                               if tile.number is not None)
    snapshot = BoardSnapshot.from_board(final.state.board)
    # More than the twelve recent summaries: every game must still be selectable.
    awards = Awards(color, s.human, (3, 3, 0, 0), (6, 6, 1, 2))
    s.results.samples = [Sample(i, i, color if i else None, 40 + i, 1.0, (2, 10, 3, 4), snapshot,
                               awards=awards if i else Awards())
                         for i in range(14)]
    app.resize(None)
    assert app.pips.value is True
    assert app.sample_picker.value == "0"
    assert len(app.sample_picker.options) == 14
    assert "Kein Sieger" in app.final_title.value
    assert "Simulationslimit" in app.final_detail.value
    assert all("Noch nicht vergeben" in row.value for row in app.final_awards.controls)
    assert len(pips(app.canvas)) == len(pips(app.final_canvas)) == 18
    assert any(isinstance(shape, cv.Text) and shape.value == "R" for shape in app.final_canvas.shapes)

    app.sample_picker.value = "1"
    app.select_sample(None)
    assert "gewinnt" in app.final_title.value
    assert "Simulationslimit" not in app.final_detail.value
    assert "Sieger" in app.final_scores.controls[1].controls[0].value
    assert COLOR_NAMES[color] in app.final_awards.controls[0].value
    assert "3 gespielte Ritter" in app.final_awards.controls[0].value
    assert "6 Straßen" in app.final_awards.controls[1].value
    assert "2 Siegpunkte" in app.final_awards.controls[1].value
    assert [row.controls[1].value for row in app.final_scores.controls] == [
        "2 Siegpunkte", "10 Siegpunkte", "3 Siegpunkte", "4 Siegpunkte"]
    app.pips.value = False
    app.toggle_pips(None)
    assert not pips(app.canvas) and not pips(app.final_canvas)
    assert app.sample_picker.value == "1"
    app.pips.value = True
    app.toggle_pips(None)
    assert len(pips(app.canvas)) == len(pips(app.final_canvas)) == 18

    s.results.samples.append(Sample(14, 14, s.human, 80, 2.0, (10, 5, 3, 4), opening))
    app.render_results()
    assert app.sample_picker.value == "1"
    assert len(app.sample_picker.options) == 15
    assert len(app.sample_rows.controls) == 12
    for width in (320, 390, 720):
        page.width = width
        app.resize(None)
        assert app.final_canvas.width <= app.root.width - 36
        assert app.final_canvas.height == app.final_geometry.height
        assert app.sample_picker.value == "1"
    assert BoardSnapshot.from_board(s.game.state.board) == opening
    assert s.game.state.random.getstate() == rng
    assert len(s.results.samples) == 15

    app.pips.value = False
    app.undo(None)
    assert not app.results_panel.visible
    assert app.sample_picker.value is None
    assert not app.sample_picker.options and not app.final_canvas.shapes
    assert not app.pips.value
    run(app.replace_session(9, 0))
    assert not app.pips.value and app.sample_picker.value is None

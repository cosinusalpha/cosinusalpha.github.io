import copy
import json

import pytest

from catanatron.models.enums import CITY, SETTLEMENT
from trainer.engine import Activity, Awards, BoardSnapshot, OpeningSession, Sample
from trainer.history import (
    board_layout, classify_win_rate, describe_node, format_percent, HistoryStore,
    MAX_STORED_SAMPLES_PER_ATTEMPT, opening_snapshot, reconstruct_session,
)


def complete_with_choice(seed: int, seat: int = 0, first_idx: int = 0, second_idx: int = 0,
                         random_ports: bool = False, dice_mode: str = "deck36") -> OpeningSession:
    session = OpeningSession(seed, seat, random_ports=random_ports, dice_mode=dice_mode)
    choices = [first_idx, second_idx]
    pick = 0
    while not session.complete:
        if session.human_turn:
            node = session.legal_nodes[choices[pick]]
            session.select_node(node)
            session.select_road(session.legal_roads[0])
            session.commit()
            pick += 1
        else:
            session.game.execute(session.game.playable_actions[0])
    return session


def make_samples(session: OpeningSession, human_wins: int, other_wins: int, limited: int = 0,
                 start_index: int = 0) -> list[Sample]:
    snap = BoardSnapshot.from_board(session.game.state.board)
    colors = session.game.state.colors
    other_color = colors[(session.seat + 1) % 4]
    winners = ([session.human] * human_wins) + ([other_color] * other_wins) + ([None] * limited)
    return [
        Sample(
            index=start_index + idx,
            seed=1000 + start_index + idx,
            winner=winner,
            turns=80,
            seconds=0.5,
            points=(10, 4, 3, 2),
            board=snap,
        )
        for idx, winner in enumerate(winners)
    ]


def test_win_rate_classification_strictly_above_fifty_percent():
    assert classify_win_rate(None) == "unrated"
    assert classify_win_rate(0.0) == "bad"
    assert classify_win_rate(0.249) == "bad"
    assert classify_win_rate(0.25) == "neutral"
    assert classify_win_rate(0.50) == "neutral"
    assert classify_win_rate(0.5001) == "good"
    assert classify_win_rate(1.0) == "good"
    assert format_percent(None) == "— %"
    assert format_percent(0.5) == "50 %"
    assert format_percent(5 / 8) == "62.5 %"


def test_per_board_grouping_and_attempt_sorting_by_win_percent():
    store = HistoryStore()
    s_bad = complete_with_choice(42, seat=0, first_idx=0, second_idx=0)
    s_tie_small = complete_with_choice(42, seat=0, first_idx=1, second_idx=0)
    s_tie_large = complete_with_choice(42, seat=0, first_idx=2, second_idx=0)
    s_good = complete_with_choice(42, seat=0, first_idx=3, second_idx=1)
    s_unrated = complete_with_choice(42, seat=0, first_idx=4, second_idx=0)

    store.record_samples(s_bad, make_samples(s_bad, 1, 4), now="2026-11-07T10:00:00Z")
    store.record_samples(s_tie_small, make_samples(s_tie_small, 2, 2), now="2026-11-07T10:01:00Z")
    store.record_samples(s_tie_large, make_samples(s_tie_large, 5, 5), now="2026-11-07T10:02:00Z")
    store.record_samples(s_good, make_samples(s_good, 4, 1, limited=2), now="2026-11-07T10:03:00Z")
    store.record_samples(s_unrated, make_samples(s_unrated, 0, 0, limited=3), now="2026-11-07T10:04:00Z")

    assert store.total_boards == 1
    assert store.total_attempts == 5
    board = store.get_board(42, False)
    ordered = board.sorted_attempts()
    assert [a.verdict for a in ordered] == ["good", "neutral", "neutral", "bad", "unrated"]
    assert [a.win_percent for a in ordered] == [80.0, 50.0, 50.0, 20.0, None]
    assert ordered[1].decided == 10 and ordered[2].decided == 4
    assert ordered[0].limited == 2 and ordered[0].total_games == 7


def test_board_sorting_modes_best_overall_and_recent():
    store = HistoryStore()
    b1_high = complete_with_choice(11, seat=0, first_idx=0, second_idx=0)
    b1_low = complete_with_choice(11, seat=0, first_idx=1, second_idx=1)
    b2_mid = complete_with_choice(22, seat=1, first_idx=0, second_idx=0)

    store.record_samples(b1_high, make_samples(b1_high, 4, 1), now="2026-11-07T09:00:00Z")
    store.record_samples(b1_low, make_samples(b1_low, 0, 5), now="2026-11-07T09:05:00Z")
    store.record_samples(b2_mid, make_samples(b2_mid, 6, 4), now="2026-11-07T10:00:00Z")

    # Board 11: best = 80%, overall = 4/10 = 40%, older
    # Board 22: best = 60%, overall = 6/10 = 60%, newer
    assert [b.seed for b in store.sorted_boards("best_win_rate")] == [11, 22]
    assert [b.seed for b in store.sorted_boards("overall_win_rate")] == [22, 11]
    assert [b.seed for b in store.sorted_boards("recent")] == [22, 11]
    with pytest.raises(ValueError):
        store.sorted_boards("invalid")  # type: ignore[arg-type]


def test_merging_identical_placement_and_separating_dice_mode_or_ports():
    store = HistoryStore()
    s1 = complete_with_choice(77, seat=2, first_idx=0, second_idx=1, dice_mode="deck36")
    s1_repeat = complete_with_choice(77, seat=2, first_idx=0, second_idx=1, dice_mode="deck36")
    s1_dice = complete_with_choice(77, seat=2, first_idx=0, second_idx=1, dice_mode="dice")
    s1_rand_ports = complete_with_choice(77, seat=2, first_idx=0, second_idx=1, random_ports=True)

    rec1 = store.record_samples(s1, make_samples(s1, 3, 2, start_index=0), now="2026-11-07T10:00:00Z")
    assert rec1.wins == 3 and rec1.decided == 5 and rec1.next_index == 5
    matched = store.matching_attempt(s1_repeat)
    assert matched is rec1

    rec2 = store.record_samples(s1_repeat, make_samples(s1_repeat, 4, 1, start_index=matched.next_index),
                                now="2026-11-07T10:10:00Z")
    assert rec2 is rec1
    assert store.get_board(77, False).attempts == [rec1]
    assert rec1.wins == 7 and rec1.decided == 10 and rec1.next_index == 10 and rec1.verdict == "good"

    store.record_samples(s1_dice, make_samples(s1_dice, 1, 4))
    assert len(store.get_board(77, False).attempts) == 2

    store.record_samples(s1_rand_ports, make_samples(s1_rand_ports, 2, 3))
    assert store.total_boards == 2
    assert store.get_board(77, True) is not None


def test_spot_stats_aggregate_good_and_bad_intersections():
    store = HistoryStore()
    s_good = complete_with_choice(55, seat=0, first_idx=0, second_idx=0)
    s_bad = complete_with_choice(55, seat=0, first_idx=0, second_idx=2)
    shared_node, good_only_node = s_good.opening_placements()[0][0], s_good.opening_placements()[7][0]
    _, bad_only_node = s_bad.opening_placements()[0][0], s_bad.opening_placements()[7][0]
    assert good_only_node != bad_only_node

    store.record_samples(s_good, make_samples(s_good, 4, 1))   # 80%
    store.record_samples(s_bad, make_samples(s_bad, 0, 5))     # 0%

    spots = store.spot_stats(55, False)
    assert list(spots) == [good_only_node, shared_node, bad_only_node]
    assert spots[good_only_node].verdict == "good" and spots[good_only_node].win_percent == 80.0
    assert spots[shared_node].verdict == "neutral" and spots[shared_node].win_percent == 40.0
    assert spots[shared_node].attempts == 2
    assert spots[bad_only_node].verdict == "bad" and spots[bad_only_node].win_percent == 0.0


def test_reconstruct_session_restores_board_hands_undo_stack_and_next_index():
    store = HistoryStore()
    original = complete_with_choice(64, seat=1, first_idx=1, second_idx=2, dice_mode="dice")
    store.record_samples(original, make_samples(original, 3, 1, limited=1))
    board = store.get_board(64, False)
    attempt = board.attempts[0]

    catan_map, colors = board_layout(board.seed, board.random_ports)
    fast_snap = opening_snapshot(catan_map, colors, attempt)
    assert fast_snap == BoardSnapshot.from_board(original.game.state.board)

    restored = reconstruct_session(board, attempt)
    assert restored.complete
    assert restored.dice_mode == "dice"
    assert restored.seat == 1
    assert restored.initial_sample_index == 5
    assert BoardSnapshot.from_board(restored.game.state.board) == fast_snap
    assert restored.starting_resources() == original.starting_resources()
    assert restored.production() == original.production()
    assert restored.victory_rounds_preview() == pytest.approx(original.victory_rounds_preview())
    assert len(restored.history) == 2

    assert restored.undo()
    assert restored.human_turn and len(restored.game.state.buildings_by_color[restored.human]["SETTLEMENT"]) == 1
    assert restored.undo()
    assert restored.human_turn and len(restored.game.state.buildings_by_color[restored.human]["SETTLEMENT"]) == 0
    assert not restored.undo()


def test_storage_roundtrip_corrupt_recovery_and_export_json():
    store = HistoryStore()
    s = complete_with_choice(83, seat=0, first_idx=0, second_idx=1)
    attempt = store.record_samples(s, make_samples(s, 6, 4), now="2026-11-07T11:00:00Z")

    raw = store.to_storage_json()
    reloaded = HistoryStore.from_storage_json(raw)
    assert reloaded.total_boards == 1 and reloaded.total_attempts == 1
    reloaded_attempt = reloaded.get_board(83, False).attempts[0]
    assert reloaded_attempt == attempt

    # Malformed or partial payloads never raise
    assert HistoryStore.from_storage_json(None).total_boards == 0
    assert HistoryStore.from_storage_json("{not-json").total_boards == 0
    partial = json.loads(raw)
    partial["boards"].append({"seed": -5, "attempts": []})
    partial["boards"][0]["attempts"].append({"seat": 99})
    recovered = HistoryStore.from_storage_json(json.dumps(partial))
    assert recovered.total_boards == 1 and recovered.total_attempts == 1

    exported = json.loads(store.to_export_json(exported_at="2026-11-07T11:05:00Z"))
    assert exported["format"] == "catan-opening-trainer-history"
    assert exported["thresholds"] == {"good_gt_percent": 50.0, "neutral_min_percent": 25.0}
    assert exported["summary"]["win_percent"] == 60.0
    board_export = exported["boards"][0]
    assert board_export["seed"] == 83
    assert len(board_export["tiles"]) == 19 and len(board_export["ports"]) == 9
    assert board_export["attempts"][0]["verdict"] == "good"
    assert len(board_export["attempts"][0]["human_settlements"]) == 2
    catan_map, _ = board_layout(83, False)
    assert board_export["attempts"][0]["human_settlements"][0]["description"] == describe_node(
        catan_map, attempt.human_nodes[0]
    )
    assert len(board_export["attempts"][0]["saved_matches"]) == 10


def test_sample_player_stats_computes_drawn_vp_cards_knights_and_buildings():
    session = complete_with_choice(42, seat=0, first_idx=0, second_idx=1)
    colors = session.game.state.colors
    snap = BoardSnapshot.from_board(session.game.state.board)
    buildings = dict(snap.buildings)
    # Give seat 0 one city and one settlement (= 3 board VP) + largest army (+2 VP) + 2 VP cards = 7 total
    seat0_nodes = [n for n, (c, _) in buildings.items() if c == colors[0]]
    buildings[seat0_nodes[0]] = (colors[0], CITY)
    # Give seat 1 two settlements (= 2 board VP) + longest road (+2 VP) + 6 VP cards? Let's test 10 VP with 3 VP cards:
    # Actually seat 1: 2 cities (4 VP) -> wait, only upgrade existing 2 settlements of seat 1 to cities (4 VP) + longest road (2 VP) + 4 VP cards = 10 VP
    seat1_nodes = [n for n, (c, _) in buildings.items() if c == colors[1]]
    buildings[seat1_nodes[0]] = (colors[1], CITY)
    buildings[seat1_nodes[1]] = (colors[1], CITY)
    rich_snap = BoardSnapshot(snap.roads, tuple(sorted(buildings.items())), snap.robber_coordinate)
    sample = Sample(
        index=0,
        seed=999,
        winner=colors[1],
        turns=72,
        seconds=1.25,
        points=(7, 10, 3, 2),
        board=rich_snap,
        activity=Activity(cards_bought=(4, 1, 0, 1, 6), cards_played=(3, 1, 0, 1), player_trades=5, bank_trades=3, offers=12),
        awards=Awards(largest_army=colors[0], longest_road=colors[1], knights=(3, 2, 1, 0), road_lengths=(4, 7, 3, 2)),
    )
    stats = sample.player_stats(colors)
    assert stats[0].settlements == 1 and stats[0].cities == 1
    assert stats[0].has_army is True and stats[0].has_road is False
    assert stats[0].knights == 3 and stats[0].road_length == 4
    assert stats[0].vp_cards == 2  # 7 - (1 + 2 + 2)

    assert stats[1].settlements == 0 and stats[1].cities == 2
    assert stats[1].has_army is False and stats[1].has_road is True
    assert stats[1].knights == 2 and stats[1].road_length == 7
    assert stats[1].vp_cards == 4  # 10 - (0 + 4 + 2)

    assert stats[2].vp_cards == 1 and stats[2].knights == 1
    assert stats[3].vp_cards == 0 and stats[3].knights == 0


def test_history_persists_match_samples_and_backward_compatible_load():
    store = HistoryStore()
    s = complete_with_choice(83, seat=0, first_idx=0, second_idx=1)
    colors = s.game.state.colors
    snap = BoardSnapshot.from_board(s.game.state.board)
    total_count = MAX_STORED_SAMPLES_PER_ATTEMPT + 6
    samples = [
        Sample(
            index=i,
            seed=2000 + i,
            winner=colors[i % 4],
            turns=60 + i,
            seconds=0.5,
            points=(10, 5, 4, 3) if i % 4 == 0 else (4, 10, 3, 2),
            board=snap,
            activity=Activity(cards_bought=(2, 0, 0, 0, 1), cards_played=(2, 0, 0, 0)),
            awards=Awards(largest_army=colors[0], longest_road=None, knights=(3, 1, 0, 0), road_lengths=(4, 5, 2, 2)),
        )
        for i in range(total_count)
    ]
    attempt = store.record_samples(s, samples, now="2026-11-15T12:00:00Z")
    assert len(attempt.samples) == MAX_STORED_SAMPLES_PER_ATTEMPT
    assert attempt.samples[0].index == 6
    assert attempt.samples[-1].index == total_count - 1

    reloaded = HistoryStore.from_storage_json(store.to_storage_json())
    reloaded_attempt = reloaded.get_board(83, False).attempts[0]
    assert reloaded_attempt == attempt
    assert reloaded_attempt.samples[0].player_stats(colors)[0].knights == 3

    exported = json.loads(store.to_export_json(exported_at="2026-11-15T12:05:00Z"))
    saved_matches = exported["boards"][0]["attempts"][0]["saved_matches"]
    assert len(saved_matches) == MAX_STORED_SAMPLES_PER_ATTEMPT
    assert saved_matches[0]["players"][0]["knights"] == 3

    # Legacy payloads without "samples" must still load cleanly.
    legacy = json.loads(store.to_storage_json())
    del legacy["boards"][0]["attempts"][0]["samples"]
    legacy_reloaded = HistoryStore.from_storage_json(json.dumps(legacy))
    assert legacy_reloaded.get_board(83, False).attempts[0].samples == []


def test_sample_devs_in_hand_played_and_storage_roundtrip():
    session = complete_with_choice(42, seat=0, first_idx=0, second_idx=1)
    colors = session.game.state.colors
    snap = BoardSnapshot.from_board(session.game.state.board)
    sample = Sample(
        index=2,
        seed=555,
        winner=colors[0],
        turns=64,
        seconds=0.8,
        points=(10, 4, 3, 2),
        board=snap,
        activity=Activity(cards_bought=(5, 1, 1, 2, 1), cards_played=(3, 1, 1, 2)),
        awards=Awards(largest_army=colors[0], longest_road=colors[0], knights=(3, 1, 0, 0), road_lengths=(6, 3, 2, 2)),
        devs_in_hand=((2, 0, 0, 0, 1), (0, 0, 0, 0, 0), (1, 0, 0, 0, 0), (0, 0, 0, 0, 0)),
        devs_played=((3, 1, 0, 2, 0), (1, 0, 1, 0, 0), (0, 0, 0, 0, 0), (0, 0, 0, 0, 0)),
    )
    stats = sample.player_stats(colors)
    assert stats[0].knights == 3
    assert stats[0].knights_in_hand == 2
    assert stats[0].yop_played == 1
    assert stats[0].monopoly_played == 0
    assert stats[0].road_building_played == 2
    assert stats[0].vp_cards == 1
    assert stats[1].monopoly_played == 1
    assert stats[2].knights_in_hand == 1

    roundtripped = Sample.from_storage_dict(sample.to_storage_dict(colors), colors)
    assert roundtripped == sample


def test_history_merge_import_json_and_spot_seat_filter():
    store_a = HistoryStore()
    s0 = complete_with_choice(42, seat=0, first_idx=0, second_idx=1)
    snap0 = BoardSnapshot.from_board(s0.game.state.board)
    colors0 = s0.game.state.colors
    store_a.record_samples(s0, [
        Sample(0, 100, colors0[0], 50, 0.4, (10, 4, 3, 2), snap0),
    ], now="2026-11-15T10:00:00Z")

    store_b = HistoryStore()
    # Same opening with more simulations + different seat + second board
    store_b.record_samples(s0, [
        Sample(0, 100, colors0[0], 50, 0.4, (10, 4, 3, 2), snap0),
        Sample(1, 101, colors0[0], 55, 0.4, (10, 5, 3, 2), snap0),
    ], now="2026-11-15T11:00:00Z")
    s1 = complete_with_choice(42, seat=1, first_idx=0, second_idx=1)
    colors1 = s1.game.state.colors
    snap1 = BoardSnapshot.from_board(s1.game.state.board)
    store_b.record_samples(s1, [
        Sample(0, 200, colors1[2], 60, 0.5, (4, 5, 10, 3), snap1),
    ], now="2026-11-15T11:05:00Z")
    s_other = complete_with_choice(99, seat=0, first_idx=0, second_idx=1)
    snap_other = BoardSnapshot.from_board(s_other.game.state.board)
    store_b.record_samples(s_other, [
        Sample(0, 300, s_other.game.state.colors[0], 52, 0.4, (10, 3, 3, 2), snap_other),
    ], now="2026-11-15T11:10:00Z")

    # Seat filtering in spot_stats separates seat 0 vs seat 1 placements
    all_spots = store_b.spot_stats(42, False)
    seat0_spots = store_b.spot_stats(42, False, seat=0)
    seat1_spots = store_b.spot_stats(42, False, seat=1)
    assert set(seat0_spots) == set(s0.opening_placements()[i][0] for i in (0, 7))
    assert set(seat1_spots) == set(s1.opening_placements()[i][0] for i in (1, 6))
    assert set(all_spots) == set(seat0_spots) | set(seat1_spots)

    storage_json = store_b.to_storage_json()
    added, updated = store_a.merge_import_json(storage_json)
    assert added == 2 and updated == 1
    assert store_a.total_boards == 2
    assert store_a.get_board(42, False).overall_decided == 3

    # Duplicate import is idempotent and does not double-count
    added_dup, updated_dup = store_a.merge_import_json(storage_json)
    assert (added_dup, updated_dup) == (0, 0)
    assert store_a.get_board(42, False).overall_decided == 3

    # Export JSON is also directly importable into an empty store
    fresh = HistoryStore()
    exp_added, exp_updated = fresh.merge_import_json(store_b.to_export_json(exported_at="2026-11-15T11:15:00Z"))
    assert exp_added == 3 and exp_updated == 0
    assert fresh.total_boards == 2

    import pytest
    for bad in ("", "not-json", "{}", '{"boards": [{"seed": "bad"}]}'):
        with pytest.raises(ValueError):
            fresh.merge_import_json(bad)

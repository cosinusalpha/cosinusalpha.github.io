import copy
import json

import pytest

from trainer.engine import BoardSnapshot, OpeningSession, Sample
from trainer.history import (
    board_layout, classify_win_rate, describe_node, format_percent, HistoryStore,
    opening_snapshot, reconstruct_session,
)


def complete_with_choice(seed: int, seat: int = 0, first_idx: int = 0, second_idx: int = 0,
                         random_ports: bool = False, dice_mode: str = "deck36") -> OpeningSession:
    session = OpeningSession(seed, seat, random_ports=random_ports, dice_mode=dice_mode)
    choices = [first_idx, second_idx]
    pick = 0
    while not session.complete:
        if session.human_turn:
            node = session.legal_nodes[choices[pick]]
            session.select_node(node)
            session.select_road(session.legal_roads[0])
            session.commit()
            pick += 1
        else:
            session.game.execute(session.game.playable_actions[0])
    return session


def make_samples(session: OpeningSession, human_wins: int, other_wins: int, limited: int = 0,
                 start_index: int = 0) -> list[Sample]:
    snap = BoardSnapshot.from_board(session.game.state.board)
    colors = session.game.state.colors
    other_color = colors[(session.seat + 1) % 4]
    winners = ([session.human] * human_wins) + ([other_color] * other_wins) + ([None] * limited)
    return [
        Sample(
            index=start_index + idx,
            seed=1000 + start_index + idx,
            winner=winner,
            turns=80,
            seconds=0.5,
            points=(10, 4, 3, 2),
            board=snap,
        )
        for idx, winner in enumerate(winners)
    ]


def test_win_rate_classification_strictly_above_fifty_percent():
    assert classify_win_rate(None) == "unrated"
    assert classify_win_rate(0.0) == "bad"
    assert classify_win_rate(0.249) == "bad"
    assert classify_win_rate(0.25) == "neutral"
    assert classify_win_rate(0.50) == "neutral"
    assert classify_win_rate(0.5001) == "good"
    assert classify_win_rate(1.0) == "good"
    assert format_percent(None) == "— %"
    assert format_percent(0.5) == "50 %"
    assert format_percent(5 / 8) == "62.5 %"


def test_per_board_grouping_and_attempt_sorting_by_win_percent():
    store = HistoryStore()
    s_bad = complete_with_choice(42, seat=0, first_idx=0, second_idx=0)
    s_tie_small = complete_with_choice(42, seat=0, first_idx=1, second_idx=0)
    s_tie_large = complete_with_choice(42, seat=0, first_idx=2, second_idx=0)
    s_good = complete_with_choice(42, seat=0, first_idx=3, second_idx=1)
    s_unrated = complete_with_choice(42, seat=0, first_idx=4, second_idx=0)

    store.record_samples(s_bad, make_samples(s_bad, 1, 4), now="2026-11-07T10:00:00Z")
    store.record_samples(s_tie_small, make_samples(s_tie_small, 2, 2), now="2026-11-07T10:01:00Z")
    store.record_samples(s_tie_large, make_samples(s_tie_large, 5, 5), now="2026-11-07T10:02:00Z")
    store.record_samples(s_good, make_samples(s_good, 4, 1, limited=2), now="2026-11-07T10:03:00Z")
    store.record_samples(s_unrated, make_samples(s_unrated, 0, 0, limited=3), now="2026-11-07T10:04:00Z")

    assert store.total_boards == 1
    assert store.total_attempts == 5
    board = store.get_board(42, False)
    ordered = board.sorted_attempts()
    assert [a.verdict for a in ordered] == ["good", "neutral", "neutral", "bad", "unrated"]
    assert [a.win_percent for a in ordered] == [80.0, 50.0, 50.0, 20.0, None]
    assert ordered[1].decided == 10 and ordered[2].decided == 4
    assert ordered[0].limited == 2 and ordered[0].total_games == 7


def test_board_sorting_modes_best_overall_and_recent():
    store = HistoryStore()
    b1_high = complete_with_choice(11, seat=0, first_idx=0, second_idx=0)
    b1_low = complete_with_choice(11, seat=0, first_idx=1, second_idx=1)
    b2_mid = complete_with_choice(22, seat=1, first_idx=0, second_idx=0)

    store.record_samples(b1_high, make_samples(b1_high, 4, 1), now="2026-11-07T09:00:00Z")
    store.record_samples(b1_low, make_samples(b1_low, 0, 5), now="2026-11-07T09:05:00Z")
    store.record_samples(b2_mid, make_samples(b2_mid, 6, 4), now="2026-11-07T10:00:00Z")

    # Board 11: best = 80%, overall = 4/10 = 40%, older
    # Board 22: best = 60%, overall = 6/10 = 60%, newer
    assert [b.seed for b in store.sorted_boards("best_win_rate")] == [11, 22]
    assert [b.seed for b in store.sorted_boards("overall_win_rate")] == [22, 11]
    assert [b.seed for b in store.sorted_boards("recent")] == [22, 11]
    with pytest.raises(ValueError):
        store.sorted_boards("invalid")  # type: ignore[arg-type]


def test_merging_identical_placement_and_separating_dice_mode_or_ports():
    store = HistoryStore()
    s1 = complete_with_choice(77, seat=2, first_idx=0, second_idx=1, dice_mode="deck36")
    s1_repeat = complete_with_choice(77, seat=2, first_idx=0, second_idx=1, dice_mode="deck36")
    s1_dice = complete_with_choice(77, seat=2, first_idx=0, second_idx=1, dice_mode="dice")
    s1_rand_ports = complete_with_choice(77, seat=2, first_idx=0, second_idx=1, random_ports=True)

    rec1 = store.record_samples(s1, make_samples(s1, 3, 2, start_index=0), now="2026-11-07T10:00:00Z")
    assert rec1.wins == 3 and rec1.decided == 5 and rec1.next_index == 5
    matched = store.matching_attempt(s1_repeat)
    assert matched is rec1

    rec2 = store.record_samples(s1_repeat, make_samples(s1_repeat, 4, 1, start_index=matched.next_index),
                                now="2026-11-07T10:10:00Z")
    assert rec2 is rec1
    assert store.get_board(77, False).attempts == [rec1]
    assert rec1.wins == 7 and rec1.decided == 10 and rec1.next_index == 10 and rec1.verdict == "good"

    store.record_samples(s1_dice, make_samples(s1_dice, 1, 4))
    assert len(store.get_board(77, False).attempts) == 2

    store.record_samples(s1_rand_ports, make_samples(s1_rand_ports, 2, 3))
    assert store.total_boards == 2
    assert store.get_board(77, True) is not None


def test_spot_stats_aggregate_good_and_bad_intersections():
    store = HistoryStore()
    s_good = complete_with_choice(55, seat=0, first_idx=0, second_idx=0)
    s_bad = complete_with_choice(55, seat=0, first_idx=0, second_idx=2)
    shared_node, good_only_node = s_good.opening_placements()[0][0], s_good.opening_placements()[7][0]
    _, bad_only_node = s_bad.opening_placements()[0][0], s_bad.opening_placements()[7][0]
    assert good_only_node != bad_only_node

    store.record_samples(s_good, make_samples(s_good, 4, 1))   # 80%
    store.record_samples(s_bad, make_samples(s_bad, 0, 5))     # 0%

    spots = store.spot_stats(55, False)
    assert list(spots) == [good_only_node, shared_node, bad_only_node]
    assert spots[good_only_node].verdict == "good" and spots[good_only_node].win_percent == 80.0
    assert spots[shared_node].verdict == "neutral" and spots[shared_node].win_percent == 40.0
    assert spots[shared_node].attempts == 2
    assert spots[bad_only_node].verdict == "bad" and spots[bad_only_node].win_percent == 0.0


def test_reconstruct_session_restores_board_hands_undo_stack_and_next_index():
    store = HistoryStore()
    original = complete_with_choice(64, seat=1, first_idx=1, second_idx=2, dice_mode="dice")
    store.record_samples(original, make_samples(original, 3, 1, limited=1))
    board = store.get_board(64, False)
    attempt = board.attempts[0]

    catan_map, colors = board_layout(board.seed, board.random_ports)
    fast_snap = opening_snapshot(catan_map, colors, attempt)
    assert fast_snap == BoardSnapshot.from_board(original.game.state.board)

    restored = reconstruct_session(board, attempt)
    assert restored.complete
    assert restored.dice_mode == "dice"
    assert restored.seat == 1
    assert restored.initial_sample_index == 5
    assert BoardSnapshot.from_board(restored.game.state.board) == fast_snap
    assert restored.starting_resources() == original.starting_resources()
    assert restored.production() == original.production()
    assert restored.victory_rounds_preview() == pytest.approx(original.victory_rounds_preview())
    assert len(restored.history) == 2

    assert restored.undo()
    assert restored.human_turn and len(restored.game.state.buildings_by_color[restored.human]["SETTLEMENT"]) == 1
    assert restored.undo()
    assert restored.human_turn and len(restored.game.state.buildings_by_color[restored.human]["SETTLEMENT"]) == 0
    assert not restored.undo()


def test_storage_roundtrip_corrupt_recovery_and_export_json():
    store = HistoryStore()
    s = complete_with_choice(83, seat=0, first_idx=0, second_idx=1)
    attempt = store.record_samples(s, make_samples(s, 6, 4), now="2026-11-07T11:00:00Z")

    raw = store.to_storage_json()
    reloaded = HistoryStore.from_storage_json(raw)
    assert reloaded.total_boards == 1 and reloaded.total_attempts == 1
    reloaded_attempt = reloaded.get_board(83, False).attempts[0]
    assert reloaded_attempt == attempt

    # Malformed or partial payloads never raise
    assert HistoryStore.from_storage_json(None).total_boards == 0
    assert HistoryStore.from_storage_json("{not-json").total_boards == 0
    partial = json.loads(raw)
    partial["boards"].append({"seed": -5, "attempts": []})
    partial["boards"][0]["attempts"].append({"seat": 99})
    recovered = HistoryStore.from_storage_json(json.dumps(partial))
    assert recovered.total_boards == 1 and recovered.total_attempts == 1

    exported = json.loads(store.to_export_json(exported_at="2026-11-07T11:05:00Z"))
    assert exported["format"] == "catan-opening-trainer-history"
    assert exported["thresholds"] == {"good_gt_percent": 50.0, "neutral_min_percent": 25.0}
    assert exported["summary"]["win_percent"] == 60.0
    board_export = exported["boards"][0]
    assert board_export["seed"] == 83
    assert len(board_export["tiles"]) == 19 and len(board_export["ports"]) == 9
    assert board_export["attempts"][0]["verdict"] == "good"
    assert len(board_export["attempts"][0]["human_settlements"]) == 2
    catan_map, _ = board_layout(83, False)
    assert board_export["attempts"][0]["human_settlements"][0]["description"] == describe_node(
        catan_map, attempt.human_nodes[0]
    )

"""Run with `flet run src/main.py`; publish with `python tools/build_web.py`."""

from __future__ import annotations

import asyncio
import math
from collections import Counter
import flet as ft
import flet.canvas as cv

from catanatron.models.enums import SETTLEMENT
from trainer.engine import OpeningSession, COLOR_NAMES, RESOURCE_NAMES, MAX_SIMULATIONS, AI_NAME, DEV_NAMES, DICE_MODES
from trainer.board import BoardGeometry
from trainer.history import (
    attempt_analysis, BOARD_SORT_MODES, board_layout, describe_node, format_percent, HistoryStore,
    opening_snapshot, reconstruct_session, STORAGE_KEY, VERDICT_SHORT,
)
from trainer.view import (
    ACCENT, AI_COLOR, attempt_review_shapes, BACKGROUND, board_shapes, COLORS, INK, MUTED, opening_shapes,
    PANEL, resource_chips, spot_comparison_shapes, VERDICT_COLORS,
)


class TrainerApp:
    def __init__(self, page: ft.Page):
        self.page = page
        self.prefs = ft.SharedPreferences()
        self.file_picker = ft.FilePicker()
        self.clipboard = ft.Clipboard()
        self.history_store = HistoryStore()
        self.history_board_key: tuple[int, bool] | None = None
        self.history_attempt_key = None
        self.history_view_mode = "attempt"
        self.history_spot_seat: int | None = None
        self.selected_review_node: int | None = None
        self.history_match_index: str | None = None
        self.history_current_only = False
        self.history_render_key = None
        self.active_tab = "play"
        self.last_exported_json = ""
        self.show_ai_opening = False
        self.session = OpeningSession()
        self.busy = False
        self.previous = None
        self.width = self.board_width()
        self.geometry = BoardGeometry(self.session.game.state.board.map, self.width)
        self.canvas = cv.Canvas(width=self.width, height=self.geometry.height)
        self.board_touch = ft.GestureDetector(content=self.canvas, on_tap_up=self.tap)
        self.pips = ft.Switch(label="Wahrscheinlichkeitspunkte", value=True,
                              active_color=ACCENT, label_text_style=ft.TextStyle(size=13, color=INK),
                              on_change=self.toggle_pips)
        self.node_pips = ft.Switch(label="Punktesumme an Kreuzungen", value=False,
                                   active_color=ACCENT, label_text_style=ft.TextStyle(size=13, color=INK),
                                   on_change=self.toggle_pips)
        self.node_pips_hint = ft.Text("Summe der angrenzenden Würfelpunkte · erwartete Rohstoffe pro 36 Würfe",
                                      size=11, color=MUTED, visible=False)
        self.status = ft.Text(size=16, weight=ft.FontWeight.BOLD, color=INK)
        self.detail = ft.Text(size=12, color=MUTED)
        self.live_victory = ft.Text(size=12, color=ACCENT, max_lines=2)
        self.error = ft.Text(size=12, color="#F17F77", visible=False)
        self.progress = ft.ProgressBar(value=0, color=ACCENT, bgcolor="#283C49", visible=False)
        self.progress_text = ft.Text(size=12, color=MUTED, visible=False)
        self.players = ft.Row(wrap=True, spacing=12)
        self.production = ft.Row(wrap=True, spacing=6, run_spacing=6)
        self.start_cards = ft.Text(size=12, color=MUTED)
        self.victory_preview = ft.Text(size=18, color=ACCENT, weight=ft.FontWeight.BOLD)
        self.victory_context = ft.Text(size=11, color=MUTED, visible=False)
        self.victory_panel = ft.Container(ft.Column([
            ft.Text("Runden bis 10 Siegpunkte", size=14, color=INK, weight=ft.FontWeight.BOLD),
            self.victory_preview, self.victory_context,
            ft.Text("Rohstoff-Schätzwert · 1 Runde = 4 Spielerzüge", size=11, color=MUTED),
            ft.ExpansionTile(title=ft.Text("Annahmen und Berechnung", size=12, color=MUTED), controls=[
                ft.Text("Fester Vergleichsplan ab 2 Start-Siedlungen: 4 weitere Siedlungen, 4 Stadtausbauten "
                        "und 8 zusätzliche Straßen ergeben 10 Siegpunkte. Bedarf: 12 Holz, 12 Lehm, 4 Wolle, "
                        "12 Getreide, 12 Erz. Startkarten und Bank-/Start-Hafenhandel zählen mit.\n"
                        "Solange erst eine Siedlung gewählt ist, zählt vorläufig nur deren Ertrag und Hafen; "
                        "der Ertrag und die Startkarten der zweiten Siedlung sind noch offen.\n"
                        "Gerechnet wird mit der durchschnittlichen Startproduktion, auch während des Ausbaus. "
                        "Spätere Produktionszuwächse, freie Bauplätze, Mitspieler, Räuber, Kartenlimit und Sonderpunkte "
                        "werden nicht eingerechnet. Ein Vergleichswert für Eröffnungen, keine Prognose der Spieldauer.",
                        size=11, color=MUTED),
            ]),
        ], spacing=6), padding=14, bgcolor=PANEL, border_radius=14)
        self.result_title = ft.Text(size=20, color=INK, weight=ft.FontWeight.BOLD)
        self.result_mode = ft.Text(size=12, color=MUTED)
        self.result_rows = ft.Column(spacing=8)
        self.sample_rows = ft.Column(spacing=6)
        self.sample_picker = ft.Dropdown(label="Endstand einer Partie", dense=True, text_size=13,
                                         on_select=self.select_sample)
        self.final_title = ft.Text(size=16, color=INK, weight=ft.FontWeight.BOLD)
        self.final_detail = ft.Text(size=12, color=MUTED)
        self.final_activity = ft.Text(size=12, color=MUTED)
        self.final_awards = ft.Column(spacing=6)
        self.final_scores = ft.Column(spacing=6)
        self.final_geometry = BoardGeometry(self.session.game.state.board.map, self.width - 36)
        self.final_canvas = cv.Canvas(width=self.final_geometry.width, height=self.final_geometry.height)
        self.final_render_key = None
        self.previous_text = ft.Text(size=12, color=MUTED, visible=False)
        self.saved_attempt_text = ft.Text(size=12, color=ACCENT, visible=False)
        self.results_panel = ft.Container(ft.Column([
            self.result_title, self.result_mode, self.previous_text, self.saved_attempt_text, self.result_rows,
            ft.Text("Einzelne Partien", color=MUTED, size=12), self.sample_rows,
            self.sample_picker, self.final_title, self.final_detail, self.final_awards, self.final_activity,
            ft.Container(self.final_canvas, alignment=ft.Alignment.CENTER, bgcolor="#142631", border_radius=12),
            ft.Text("Stadt: Haus mit Punkt · R: Räuber", color=MUTED, size=11), self.final_scores,
            ft.Text("Bei wenigen Partien schwankt das Ergebnis stark. Alle vier Plätze spielen mit derselben KI.",
                    color=MUTED, size=11),
        ], spacing=12), padding=18, bgcolor=PANEL, border_radius=16, visible=False)
        self.history_summary = ft.Text(size=12, color=MUTED)
        self.history_empty = ft.Text(
            "Noch keine simulierten Bretter gespeichert. Nach einer Simulation werden deine Eröffnungen "
            "hier pro Brett nach % gewonnen sortiert.",
            size=12, color=MUTED,
        )
        self.export_btn = ft.OutlinedButton("JSON exportieren", icon=ft.Icons.DOWNLOAD, on_click=self.export_history)
        self.copy_export_btn = ft.TextButton("JSON kopieren", icon=ft.Icons.CONTENT_COPY, on_click=self.copy_history)
        self.import_btn = ft.OutlinedButton("JSON importieren", icon=ft.Icons.UPLOAD_FILE, on_click=self.import_history)
        self.paste_import_btn = ft.TextButton("JSON einfügen", icon=ft.Icons.CONTENT_PASTE,
                                              on_click=self.paste_import_history)
        self.history_notice = ft.Text(size=11, color=ACCENT, visible=False)
        self.history_filter_btn = ft.OutlinedButton(
            "Nur aktuelles Brett", icon=ft.Icons.FILTER_ALT, on_click=self.toggle_history_filter, height=36,
        )
        self.board_sort = ft.Dropdown(
            label="Brett-Sortierung", value="best_win_rate", dense=True, text_size=13,
            options=[ft.DropdownOption(key, label) for key, label in BOARD_SORT_MODES.items()],
            on_select=self.change_board_sort,
        )
        self.board_chips = ft.Row(scroll=ft.ScrollMode.AUTO, spacing=6)
        self.board_picker = ft.Dropdown(label="Gespieltes Brett", dense=True, text_size=13,
                                        on_select=self.select_history_board)
        self.current_board_btn = ft.TextButton("Aktuelles Brett zeigen", icon=ft.Icons.MY_LOCATION,
                                               on_click=self.focus_current_board, visible=False)
        self.board_stats_text = ft.Text(size=12, color=MUTED)
        self.attempt_rows = ft.Column(spacing=8)
        self.mode_attempt_btn = ft.Button("Eröffnung", icon=ft.Icons.HOME,
                                          on_click=self.show_attempt_view, height=36,
                                          style=ft.ButtonStyle(bgcolor=ACCENT, color=BACKGROUND))
        self.mode_spots_btn = ft.OutlinedButton("Plätze (%)", icon=ft.Icons.ANALYTICS,
                                                on_click=self.show_spots_view, height=36)
        self.mode_matches_btn = ft.OutlinedButton("Endstände", icon=ft.Icons.EMOJI_EVENTS,
                                                  on_click=self.show_matches_view, height=36)
        self.review_title = ft.Text(size=15, color=INK, weight=ft.FontWeight.BOLD)
        self.review_detail = ft.Text(size=12, color=MUTED)
        self.review_production = ft.Row(wrap=True, spacing=6, run_spacing=6)
        self.review_cards = ft.Text(size=12, color=MUTED)
        self.history_match_picker = ft.Dropdown(label="Gespeicherte Partie", dense=True, text_size=13,
                                                on_select=self.select_history_match, visible=False)
        self.history_match_chips = ft.Row(scroll=ft.ScrollMode.AUTO, spacing=6, visible=False)
        self.spot_seat_chips = ft.Row(scroll=ft.ScrollMode.AUTO, spacing=6, visible=False)
        self.review_geometry = BoardGeometry(self.session.game.state.board.map, self.width - 44)
        self.review_canvas = cv.Canvas(width=self.review_geometry.width, height=self.review_geometry.height)
        self.review_touch = ft.GestureDetector(content=self.review_canvas, on_tap_up=self.tap_review_board)
        self.history_match_scores = ft.Column(spacing=6, visible=False)
        self.review_legend = ft.Text(size=11, color=MUTED)
        self.replay_board_btn = ft.OutlinedButton("Dieses Brett spielen", icon=ft.Icons.REPLAY,
                                                  on_click=self.play_history_board)
        self.load_attempt_btn = ft.TextButton("Diese Eröffnung laden", icon=ft.Icons.RESTORE,
                                              on_click=self.load_history_attempt)
        self.delete_attempt_btn = ft.TextButton("Versuch löschen", icon=ft.Icons.DELETE_OUTLINE,
                                                on_click=self.delete_history_attempt)
        self.review_preview_card = ft.Container(
            ft.Column([
                ft.Row([self.mode_attempt_btn, self.mode_spots_btn, self.mode_matches_btn], wrap=True, spacing=6),
                self.spot_seat_chips,
                self.review_title,
                self.review_detail,
                self.review_production,
                self.review_cards,
                self.history_match_picker,
                self.history_match_chips,
                ft.Container(self.review_touch, alignment=ft.Alignment.CENTER, bgcolor="#101923", border_radius=12),
                self.history_match_scores,
                self.review_legend,
                ft.Row([self.replay_board_btn, self.load_attempt_btn, self.delete_attempt_btn], wrap=True),
            ], spacing=8),
            padding=12,
            bgcolor="#14222D",
            border=ft.Border.all(1, "#273947"),
            border_radius=14,
        )
        self.history_body = ft.Column([
            self.history_summary,
            ft.Row([self.export_btn, self.copy_export_btn, self.import_btn,
                    self.paste_import_btn, self.history_filter_btn], wrap=True, spacing=6),
            self.history_notice,
            self.board_sort,
            self.board_chips,
            self.board_picker,
            self.current_board_btn,
            self.board_stats_text,
            self.review_preview_card,
            ft.Text("Platzierungen auf diesem Brett · sortiert nach % gewonnen", size=12, color=MUTED),
            self.attempt_rows,
        ], spacing=10, visible=False)
        self.history_panel = ft.Container(ft.Column([
            ft.Text("Brett-Verlauf & Platzierungs-Analyse", size=18, color=INK, weight=ft.FontWeight.BOLD),
            self.history_empty,
            self.history_body,
        ], spacing=10), padding=16, bgcolor=PANEL, border_radius=16, visible=False)
        self.commit_btn = ft.Button("Platzierung bestätigen", icon=ft.Icons.CHECK,
                                    on_click=self.commit, height=46,
                                    style=ft.ButtonStyle(bgcolor=ACCENT, color=BACKGROUND))
        self.undo_btn = ft.TextButton("Zurück", icon=ft.Icons.UNDO, on_click=self.undo)
        self.new_btn = ft.OutlinedButton("Neues Brett", icon=ft.Icons.SHUFFLE, on_click=self.new_game)
        self.retry_btn = ft.TextButton("Dieses Brett erneut", icon=ft.Icons.REPLAY, on_click=self.retry)
        self.count = ft.TextField(label="Simulationen", value="5", width=128, dense=True,
                                  keyboard_type=ft.KeyboardType.NUMBER,
                                  input_filter=ft.InputFilter(allow=True, regex_string=r"[0-9]"))
        self.sim_btn = ft.Button("Simulieren", icon=ft.Icons.PLAY_ARROW, on_click=self.simulate, height=46,
                                 style=ft.ButtonStyle(bgcolor=ACCENT, color=BACKGROUND))
        self.stop_btn = ft.TextButton("Stoppen", icon=ft.Icons.STOP, on_click=self.stop, visible=False)
        self.dice_mode = ft.Dropdown(label="Würfelmodus", value=self.session.dice_mode, dense=True,
                                     options=[ft.DropdownOption(key, label) for key, label in DICE_MODES.items()],
                                     on_select=self.change_dice_mode)
        self.dice_hint = ft.Text(size=11, color=MUTED)
        self.seat = ft.Dropdown(label="Startplatz", value="random", width=154, dense=True,
                                options=[ft.DropdownOption("random", "Zufällig")] +
                                [ft.DropdownOption(str(i), f"Startplatz {i + 1}") for i in range(4)])
        self.ports = ft.Dropdown(label="Häfen", value="fixed", width=154, dense=True,
                                 options=[ft.DropdownOption("fixed", "Feste Anordnung"),
                                          ft.DropdownOption("random", "Zufällig")])
        self.seed = ft.TextField(label="Brett-Code", value=str(self.session.seed), width=185, dense=True,
                                 keyboard_type=ft.KeyboardType.NUMBER)
        self.load_btn = ft.TextButton("Code laden", on_click=self.load)
        quick = ft.Row([ft.TextButton(str(n), data=n, on_click=self.quick_count)
                        for n in (1, 5, 10, 25, 50, 100)], wrap=True, spacing=0)
        self.opening_actions = ft.Row([self.commit_btn, self.undo_btn], wrap=True)
        self.ai_opening_btn = ft.OutlinedButton("KI-Eröffnung zeigen", icon=ft.Icons.PSYCHOLOGY,
                                                on_click=self.toggle_ai_opening, height=36)
        self.apply_ai_opening_btn = ft.OutlinedButton("KI-Eröffnung übernehmen", icon=ft.Icons.SMART_TOY,
                                                      on_click=self.apply_ai_opening, height=36)
        self.ai_opening_text = ft.Text(size=11, color=AI_COLOR, visible=False)
        self.ai_actions = ft.Row([self.ai_opening_btn, self.apply_ai_opening_btn], wrap=True, spacing=6)
        self.simulation_actions = ft.Column([self.dice_mode, self.dice_hint,
                                             ft.Row([self.count, self.sim_btn, self.stop_btn], wrap=True), quick])
        self.header_board_badge = ft.Text(size=11, color=ACCENT)
        self.tab_buttons = {
            "play": ft.Button("Spiel & Sim", icon=ft.Icons.SPORTS_ESPORTS, data="play",
                              on_click=self.on_tab_click, height=36),
            "history": ft.Button("Verlauf", icon=ft.Icons.HISTORY, data="history",
                                 on_click=self.on_tab_click, height=36),
            "setup": ft.Button("Setup", icon=ft.Icons.TUNE, data="setup",
                               on_click=self.on_tab_click, height=36),
        }
        self.tab_bar = ft.Row(list(self.tab_buttons.values()), wrap=True, spacing=6)
        self.nav_bar = ft.NavigationBar(
            selected_index=0,
            bgcolor="#14222D",
            indicator_color="#263D4E",
            on_change=self.on_nav_change,
            destinations=[
                ft.NavigationBarDestination(icon=ft.Icons.SPORTS_ESPORTS, label="Spiel & Sim"),
                ft.NavigationBarDestination(icon=ft.Icons.HISTORY, label="Verlauf"),
                ft.NavigationBarDestination(icon=ft.Icons.TUNE, label="Brett-Setup"),
            ],
        )
        self.play_section = ft.Column([
            ft.Text("Platziere zwei Siedlungen und Straßen. Lass die KI anschließend weiterspielen.",
                    size=12, color=MUTED),
            ft.Container(ft.Column([self.players, self.status, ft.Container(self.detail, height=34),
                                     ft.Container(self.live_victory, height=34)], spacing=6),
                         padding=14, bgcolor=PANEL, border_radius=14),
            ft.Container(self.board_touch, alignment=ft.Alignment.CENTER,
                         bgcolor="#142631", border_radius=16),
            ft.Row([self.pips, self.node_pips], wrap=True, spacing=12),
            self.node_pips_hint,
            self.opening_actions,
            self.ai_actions,
            self.ai_opening_text,
            ft.Text("Erwartete Produktion pro 36 Würfe · ohne Räuber", size=11, color=MUTED),
            self.production, self.start_cards, self.victory_panel,
            self.simulation_actions, self.progress, self.progress_text, self.results_panel,
        ], spacing=10, horizontal_alignment=ft.CrossAxisAlignment.STRETCH, visible=True)
        self.setup_start_btn = ft.Button("Neues Brett mit Einstellungen starten", icon=ft.Icons.SHUFFLE,
                                         on_click=self.new_game, height=44,
                                         style=ft.ButtonStyle(bgcolor=ACCENT, color=BACKGROUND))
        self.setup_section = ft.Container(ft.Column([
            ft.Text("Brett-Setup & Regeln", size=18, color=INK, weight=ft.FontWeight.BOLD),
            ft.Text("Konfiguriere Startplatz, Häfen oder lade einen gespeicherten Brett-Code.",
                    size=12, color=MUTED),
            ft.Row([self.seat, self.ports], wrap=True),
            self.setup_start_btn,
            ft.Divider(color="#293A47"),
            ft.Row([self.seed, self.load_btn], wrap=True),
            ft.Divider(color="#293A47"),
            ft.Text("1 → 2 → 3 → 4 → 4 → 3 → 2 → 1\nHäfen: H Holz · L Lehm · W Wolle · G Getreide · E Erz",
                    size=11, color=MUTED),
            ft.Text(f"Simulation: {AI_NAME}", size=10, color=MUTED),
            ft.TextButton("Quellcode und Herkunft", url="smart/source.tar.gz"),
        ], spacing=12), padding=16, bgcolor=PANEL, border_radius=16, visible=False)
        self.root = ft.Column([
            ft.Row([
                ft.Container(ft.Icon(ft.Icons.GRID_VIEW, color=BACKGROUND, size=22),
                             padding=9, bgcolor=ACCENT, border_radius=11),
                ft.Column([
                    ft.Text("Catan · Eröffnungstrainer", size=20, color=INK, weight=ft.FontWeight.BOLD),
                    self.header_board_badge,
                ], spacing=1, expand=True),
            ], spacing=10),
            ft.Row([self.new_btn, self.retry_btn], wrap=True, spacing=6),
            self.tab_bar,
            self.error,
            self.play_section,
            self.history_panel,
            self.setup_section,
        ], spacing=10, horizontal_alignment=ft.CrossAxisAlignment.STRETCH)
        page.title = "Catan · Eröffnungstrainer"
        page.bgcolor = BACKGROUND
        page.theme_mode = ft.ThemeMode.DARK
        page.theme = ft.Theme(color_scheme_seed=ACCENT, font_family="Roboto")
        page.padding = 16
        page.scroll = ft.ScrollMode.AUTO
        page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
        page.navigation_bar = self.nav_bar
        page.on_resize = self.resize
        page.on_disconnect = self.disconnect
        self.root.width = min(720, max(280, (page.width or 640) - 32))
        self._update_responsive_nav()
        self.switch_tab("play")
        page.add(self.root)

    def _update_responsive_nav(self):
        page_width = getattr(self.page, "width", None)
        self.tab_bar.visible = (page_width or 640) >= 520

    def board_width(self):
        return min(688, max(248, (self.page.width or 640) - 32))

    def _has_page_services(self) -> bool:
        return isinstance(self.page, ft.Page)

    async def load_history(self):
        if not self._has_page_services():
            return
        try:
            raw = await self.prefs.get(STORAGE_KEY)
        except Exception:
            return
        self.history_store = HistoryStore.from_storage_json(raw)

    async def save_history(self):
        if not self._has_page_services():
            return
        try:
            await self.prefs.set(STORAGE_KEY, self.history_store.to_storage_json())
        except Exception as exc:
            self.show_error(f"Verlauf konnte nicht gespeichert werden: {exc}")

    async def start(self):
        await self.load_history()
        await self.advance()

    def show_error(self, message=""):
        self.error.value = message
        self.error.visible = bool(message)

    def resize(self, e):
        self.width = self.board_width()
        self.root.width = min(720, max(280, (self.page.width or 640) - 32))
        self._update_responsive_nav()
        self.canvas.width = self.width
        self.geometry = BoardGeometry(self.session.game.state.board.map, self.width)
        self.canvas.height = self.geometry.height
        self.refresh()

    def disconnect(self, e):
        self.session.close()

    def switch_tab(self, tab: str):
        if tab not in ("play", "history", "setup"):
            tab = "play"
        self.active_tab = tab
        self.play_section.visible = tab == "play"
        self.history_panel.visible = tab == "history"
        self.setup_section.visible = tab == "setup"
        self.nav_bar.selected_index = ("play", "history", "setup").index(tab)
        for key, btn in self.tab_buttons.items():
            active = key == tab
            btn.style = ft.ButtonStyle(
                bgcolor=ACCENT if active else "#14222D",
                color=BACKGROUND if active else INK,
            )

    def on_nav_change(self, e):
        tabs = ("play", "history", "setup")
        idx = self.nav_bar.selected_index
        if 0 <= idx < len(tabs):
            self.switch_tab(tabs[idx])
            self.page.update()

    def on_tab_click(self, e):
        self.switch_tab(str(e.control.data))
        self.page.update()

    def _build_match_score_rows(self, colors, human_color, sample, row_width: float):
        rows = []
        for st in sample.player_stats(colors):
            c = st.color
            is_winner = c == sample.winner
            name_label = (
                COLOR_NAMES[c]
                + (" · Du" if c == human_color else "")
                + (" · Sieger" if is_winner else "")
            )
            army_note = " (Größte Rittermacht)" if st.has_army else ""
            road_note = " (Längste Straße)" if st.has_road else ""
            hand_note = f" (+{st.knights_in_hand} Hand)" if st.knights_in_hand else ""
            dev_notes = [
                f"{count}× {label}" if count > 1 else label
                for label, count in (
                    ("Erfindung", st.yop_played),
                    ("Monopol", st.monopoly_played),
                    ("Straßenbau", st.road_building_played),
                )
                if count > 0
            ]
            dev_suffix = f" · Aktionen: {', '.join(dev_notes)}" if dev_notes else ""
            detail_text = (
                f"SP-Karten vom Stapel: {st.vp_cards} · "
                f"Ritter: {st.knights}{hand_note}{army_note} · "
                f"Straßen: {st.road_length}{road_note} · "
                f"{st.settlements} Siedl., {st.cities} Städte{dev_suffix}"
            )
            rows.append(ft.Row([
                ft.Text(
                    name_label,
                    color=COLORS[c],
                    weight=ft.FontWeight.BOLD if is_winner else ft.FontWeight.NORMAL,
                ),
                ft.Text(
                    f"{st.points} Siegpunkte",
                    color=INK,
                    size=12,
                    weight=ft.FontWeight.BOLD if is_winner else ft.FontWeight.NORMAL,
                ),
                ft.Container(
                    ft.Text(detail_text, size=11, color=ACCENT if st.vp_cards > 0 else MUTED),
                    width=max(200, row_width),
                ),
            ], wrap=True, alignment=ft.MainAxisAlignment.SPACE_BETWEEN, spacing=6, run_spacing=2))
        return rows

    def _build_win_distribution_bar(self, colors, wins_by_seat, decided: int):
        if decided <= 0:
            return ft.Text("Noch keine entschiedenen Partien.", size=10, color=MUTED)
        segments = [
            ft.Container(
                height=6,
                expand=wins,
                bgcolor=COLORS[colors[i]],
                border_radius=3,
                tooltip=f"{COLOR_NAMES[colors[i]]}: {wins}",
            )
            for i, wins in enumerate(wins_by_seat)
            if wins > 0
        ]
        summary = " · ".join(f"{COLOR_NAMES[colors[i]]} {wins_by_seat[i]}" for i in range(len(colors)))
        return ft.Column([
            ft.Row(segments, spacing=2),
            ft.Text(f"Siege je Farbe: {summary}", size=10, color=MUTED),
        ], spacing=3)

    def refresh(self):
        s = self.session
        self.header_board_badge.value = (
            f"Brett #{s.seed} · Startplatz {s.seat + 1} · "
            f"{'Zufallshäfen' if s.random_ports else 'Feste Häfen'}"
        )
        ai_human = (s.human_ai_placements(s.ai_placements_cache)
                    if self.show_ai_opening and s.ai_placements_cache is not None else None)
        self.canvas.shapes = opening_shapes(s, self.geometry, show_targets=not self.busy,
                                            show_pips=self.pips.value, show_node_pips=self.node_pips.value,
                                            ai_human_placements=ai_human)
        if ai_human is not None:
            catan_map = s.game.state.board.map
            (n1, _), (n2, _) = ai_human
            ai_rounds = s.victory_rounds_for_spots(n1, n2)
            ai_rounds_note = "nicht erreichbar" if math.isinf(ai_rounds) else f"≈ {math.ceil(ai_rounds - 1e-9)} Runden"
            self.ai_opening_text.visible = True
            self.ai_opening_text.value = (
                f"KI-Wahl (Startplatz {s.seat + 1}): 1. {describe_node(catan_map, n1)} · "
                f"2. {describe_node(catan_map, n2)} · {ai_rounds_note}"
            )
            self.ai_opening_btn.content = "KI-Eröffnung ausblenden"
            self.ai_opening_btn.style = ft.ButtonStyle(bgcolor=AI_COLOR, color=BACKGROUND)
        else:
            self.ai_opening_text.visible = False
            self.ai_opening_btn.content = "KI-Eröffnung zeigen"
            self.ai_opening_btn.style = ft.ButtonStyle(bgcolor="#14222D", color=INK)
        self.node_pips.visible = not s.complete
        self.node_pips_hint.visible = not s.complete and self.node_pips.value
        self.players.controls = [ft.Text(f"{i + 1}. {COLOR_NAMES[c]}" + (" · Du" if c == s.human else ""),
                                        color=COLORS[c], size=12,
                                        weight=ft.FontWeight.BOLD if c == s.human else ft.FontWeight.NORMAL)
                                 for i, c in enumerate(s.game.state.colors)]
        own_count = len(s.game.state.buildings_by_color[s.human][SETTLEMENT])
        matching = self.history_store.matching_attempt(s) if s.complete else None
        if s.complete:
            self.status.value = "Eröffnung fertig"
            if matching is not None:
                self.detail.value = (
                    f"Im Verlauf: {format_percent(matching.win_rate)} gewonnen "
                    f"({matching.wins}/{matching.decided} Siege). Weitere Partien werden ergänzt."
                )
            else:
                self.detail.value = "Alle Plätze übernehmen dieselbe KI. Wähle die Anzahl der Partien."
        elif not s.human_turn:
            self.status.value = f"{COLOR_NAMES[s.game.state.current_color()]} platziert …"
            self.detail.value = f"Du bist auf Startplatz {s.seat + 1}."
        elif s.selected_node is None:
            self.status.value = f"Deine {'erste' if own_count == 0 else 'zweite'} Siedlung"
            self.detail.value = "Tippe auf eine helle Kreuzung."
        elif s.selected_edge is None:
            self.status.value = "Wähle die Straßenrichtung"
            self.detail.value = "Tippe auf einen markierten Straßenpunkt neben deiner Siedlung."
        else:
            self.status.value = "Siedlung und Straße gewählt"
            self.detail.value = "Bestätigen oder eine andere Kreuzung / Straße wählen."
        self.production.controls = resource_chips(s.production(include_selected=True))
        cards = s.starting_resources()
        if own_count == 1 and s.selected_node is not None:
            cards = Counter(t.resource for t in s.game.state.board.map.adjacent_tiles[s.selected_node] if t.resource)
        self.start_cards.value = ("Startkarten: " + ", ".join(f"{v} {RESOURCE_NAMES[r]}" for r, v in cards.items() if v)) if any(cards.values()) else "Startkarten erhältst du an deiner zweiten Siedlung."
        rounds = s.victory_rounds_preview()
        self.victory_preview.value = ("Tippe einen Siedlungsplatz an." if rounds is None else
                                      "Ohne Produktion nicht erreichbar" if math.isinf(rounds) else
                                      f"≈ {math.ceil(rounds - 1e-9)} Runden")
        preview_count = own_count + (s.selected_node is not None)
        provisional = preview_count == 1
        self.victory_context.visible = provisional or s.selected_node is not None
        self.victory_context.value = ("Vorläufig · zweite Siedlung noch offen." if provisional else
                                      "Vorschau deiner unbestätigten Platzierung.")
        prefix = ("Vorläufig (1 Siedlung): " if provisional else
                  "Vorschau: " if s.selected_node is not None else "Sieg-Schätzwert: ")
        self.live_victory.value = ("Sieg-Schätzung beim Antippen einer Kreuzung." if rounds is None else
                                   prefix + self.victory_preview.value)
        self.opening_actions.visible = not s.complete or bool(s.history)
        self.commit_btn.visible = not s.complete
        self.undo_btn.content = "Letzte Platzierung ändern" if s.complete else "Zurück"
        self.commit_btn.disabled = self.busy or s.selected_edge is None
        self.undo_btn.disabled = self.busy or not s.history
        self.simulation_actions.visible = s.complete
        self.sim_btn.content = "Weitere simulieren" if (s.results.samples or matching is not None) else "Simulieren"
        self.sim_btn.disabled = self.busy
        self.dice_mode.value = s.dice_mode
        self.dice_hint.value = (("Alle 36 Würfelkombinationen einmal ziehen, dann neu mischen." if s.dice_mode == "deck36"
                                else "Zwei unabhängige Würfel bei jedem Zug.") +
                               " Moduswechsel löscht die Simulationsergebnisse.")
        for control in (self.new_btn, self.retry_btn, self.setup_start_btn, self.seat, self.ports, self.seed,
                        self.load_btn, self.count, self.dice_mode, self.replay_board_btn,
                        self.load_attempt_btn, self.delete_attempt_btn, self.ai_opening_btn,
                        self.apply_ai_opening_btn, self.import_btn, self.paste_import_btn):
            control.disabled = self.busy
        self.stop_btn.visible = self.busy and s.complete
        self.render_results()
        self.render_history()
        self.page.update()

    def render_results(self):
        s, results = self.session, self.session.results
        self.results_panel.visible = bool(results.samples)
        decided = results.decided
        self.result_title.value = f"Du gewinnst {results.wins[s.human]} von {decided} Partien"
        self.result_mode.value = DICE_MODES[s.dice_mode]
        if results.limited:
            self.result_title.value += f" · {results.limited} am Zuglimit"
        self.result_rows.controls = []
        for i, c in enumerate(s.game.state.colors):
            wins = results.wins[c]
            self.result_rows.controls.append(ft.Column([
                ft.Row([ft.Text(f"{i + 1}. {COLOR_NAMES[c]}" + (" · Du" if c == s.human else ""), color=COLORS[c], expand=True),
                        ft.Text(f"{wins} Siege", color=INK, size=12)]),
                ft.ProgressBar(value=wins / decided if decided else 0, color=COLORS[c], bgcolor="#2B3B49", height=5),
            ], spacing=4))
        previous = self.previous
        self.previous_text.visible = bool(previous and previous[0] == (s.seed, s.seat, s.random_ports, s.dice_mode))
        if self.previous_text.visible:
            self.previous_text.value = f"Voriger Versuch auf diesem Brett: {previous[1]} von {previous[2]} gewonnen."
        matching = self.history_store.matching_attempt(s)
        self.saved_attempt_text.visible = matching is not None
        if matching is not None:
            self.saved_attempt_text.value = (
                f"Gespeicherter Gesamtstand dieser Eröffnung: {format_percent(matching.win_rate)} gewonnen "
                f"({matching.wins}/{matching.decided} Siege)."
            )
        if not results.samples:
            self.sample_rows.controls = []
            self.sample_picker.value = None
            self.sample_picker.options = []
            self.final_canvas.shapes = []
            self.final_render_key = None
            return
        if len(self.sample_picker.options) != len(results.samples):
            self.sample_picker.options = [ft.DropdownOption(str(sample.index),
                f"Partie {sample.index + 1} · " + ("Kein Sieger (Limit)" if sample.winner is None else
                                                   f"{COLOR_NAMES[sample.winner]} gewinnt"))
                for sample in results.samples]
        sample = next((sample for sample in results.samples if str(sample.index) == self.sample_picker.value),
                      results.samples[0])
        self.sample_picker.value = str(sample.index)
        colors = s.game.state.colors
        self.sample_rows.controls = []
        for item in results.samples[-12:]:
            is_selected = item.index == sample.index
            winner_color = COLORS.get(item.winner, MUTED)
            if item.winner is None:
                headline = f"#{item.index + 1} · Zuglimit"
                subline = f"{item.turns} Züge · {item.seconds:.1f} s"
            else:
                headline = (
                    f"#{item.index + 1} · {COLOR_NAMES[item.winner]} gewinnt"
                    + (" (Du)" if item.winner == s.human else "")
                )
                winner_stats = next(st for st in item.player_stats(colors) if st.color == item.winner)
                subline = (
                    f"{item.turns} Züge · {winner_stats.points} SP · "
                    f"{winner_stats.vp_cards} SP-Karten · {winner_stats.knights} Ritter"
                )
            self.sample_rows.controls.append(ft.Container(
                ft.Row([
                    ft.Text(headline, color=winner_color, size=12, weight=ft.FontWeight.BOLD),
                    ft.Text(subline, color=MUTED, size=11),
                ], wrap=True, alignment=ft.MainAxisAlignment.SPACE_BETWEEN, spacing=6),
                padding=ft.Padding.symmetric(horizontal=10, vertical=7),
                bgcolor="#213444" if is_selected else "#14222D",
                border=ft.Border.all(1.5, ACCENT if is_selected else "#273947"),
                border_radius=10,
                data=str(item.index),
                on_click=self.select_sample_chip,
            ))
        render_key = (sample, self.width - 36, self.pips.value)
        if render_key == self.final_render_key:
            return
        self.final_geometry = BoardGeometry(s.game.state.board.map, self.width - 36)
        self.final_canvas.width = self.final_geometry.width
        self.final_canvas.height = self.final_geometry.height
        self.final_canvas.shapes = board_shapes(s.game.state.board.map, sample.board, self.final_geometry,
                                                show_pips=self.pips.value)
        self.final_title.value = (f"Partie {sample.index + 1} · " +
                                  ("Kein Sieger" if sample.winner is None else
                                   f"{COLOR_NAMES[sample.winner]} gewinnt" + (" · Du" if sample.winner == s.human else "")))
        self.final_title.color = COLORS.get(sample.winner, INK)
        self.final_detail.value = (f"{sample.turns} Züge · {sample.seconds:.1f} s" +
                                   (" · Am Simulationslimit beendet" if sample.winner is None else ""))
        activity = sample.activity
        bought = ", ".join(f"{count} {name}" for name, count in zip(DEV_NAMES, activity.cards_bought) if count) or "keine"
        played = ", ".join(f"{count} {name}" for name, count in zip(DEV_NAMES, activity.cards_played) if count) or "keine"
        vp_drawn_total = activity.cards_bought[4] if len(activity.cards_bought) > 4 else 0
        knights_bought = activity.cards_bought[0] if activity.cards_bought else 0
        knights_played = activity.cards_played[0] if activity.cards_played else 0
        self.final_activity.value = (
            f"Entwicklungskarten gekauft: {bought}\n"
            f"Gespielt: {played}\n"
            f"Stapel-Fokus: {vp_drawn_total} Siegpunkt-Karten gezogen · "
            f"{knights_bought} Ritter gezogen / {knights_played} gespielt\n"
            f"Spielerhandel: {activity.player_trades} · Bank-/Hafenhandel: {activity.bank_trades}"
            f" · Angebote: {activity.offers}"
        )
        self.final_awards.controls = []
        for label, holder, counts, unit in (
            ("Größte Rittermacht", sample.awards.largest_army, sample.awards.knights, "gespielte Ritter"),
            ("Längste Handelsstraße", sample.awards.longest_road, sample.awards.road_lengths, "Straßen"),
        ):
            description = "Noch nicht vergeben"
            if holder is not None:
                count = counts[colors.index(holder)]
                description = (COLOR_NAMES[holder] + (" · Du" if holder == s.human else "") +
                               f" · {count} {unit} · 2 Siegpunkte")
            self.final_awards.controls.append(ft.Text(f"{label}: {description}",
                                                      color=COLORS.get(holder, MUTED), size=12))
        self.final_scores.controls = self._build_match_score_rows(colors, s.human, sample, self.width - 36)
        self.final_render_key = render_key

    def _set_history_match_controls_visible(self, visible: bool):
        self.history_match_picker.visible = visible
        self.history_match_chips.visible = visible
        self.history_match_scores.visible = visible
        if not visible:
            self.history_match_picker.options = []
            self.history_match_picker.value = None
            self.history_match_chips.controls = []
            self.history_match_scores.controls = []

    def _draw_review_canvas(self, catan_map, canvas_width: float, render_key, shapes_builder):
        if render_key == self.history_render_key:
            return
        self.review_geometry = BoardGeometry(catan_map, canvas_width)
        self.review_canvas.width = self.review_geometry.width
        self.review_canvas.height = self.review_geometry.height
        self.review_canvas.shapes = shapes_builder(self.review_geometry)
        self.history_render_key = render_key

    def render_history(self):
        store = self.history_store
        self.nav_bar.destinations[1].badge = str(store.total_boards) if store.total_boards else None
        self.tab_buttons["history"].content = f"Verlauf ({store.total_boards})" if store.total_boards else "Verlauf"
        if store.total_boards == 0:
            self.history_empty.visible = True
            self.history_body.visible = False
            self.board_chips.controls = []
            self.board_picker.value = None
            self.board_picker.options = []
            self.attempt_rows.controls = []
            self.spot_seat_chips.visible = False
            self.spot_seat_chips.controls = []
            self._set_history_match_controls_visible(False)
            self.review_canvas.shapes = []
            self.history_render_key = None
            return
        self.history_empty.visible = False
        self.history_body.visible = True
        sort_mode = self.board_sort.value if self.board_sort.value in BOARD_SORT_MODES else "best_win_rate"
        all_boards = store.sorted_boards(sort_mode)
        current_key = (self.session.seed, self.session.random_ports)
        has_current = current_key in store.boards
        self.history_filter_btn.disabled = not has_current
        filter_active = self.history_current_only and has_current
        self.history_filter_btn.style = ft.ButtonStyle(
            bgcolor=ACCENT if filter_active else "#14222D",
            color=BACKGROUND if filter_active else INK,
        )
        boards = [store.boards[current_key]] if filter_active else all_boards
        self.history_summary.value = (
            f"{store.total_boards} {'Brett' if store.total_boards == 1 else 'Bretter'} · "
            f"{store.total_attempts} {'Versuch' if store.total_attempts == 1 else 'Versuche'} · "
            "Gut > 50 %"
        )
        self.board_picker.options = [
            ft.DropdownOption(
                f"{b.seed}:{int(b.random_ports)}",
                f"Brett {b.seed} ({'Zufallshäfen' if b.random_ports else 'Feste Häfen'}) · "
                f"Best {format_percent(b.best_win_rate)} · Gesamt {format_percent(b.overall_win_rate)} "
                f"({len(b.attempts)})" + (" · Aktuell" if b.key == current_key else ""),
            )
            for b in all_boards
        ]
        if filter_active:
            board = store.boards[current_key]
        elif self.history_board_key in store.boards:
            board = store.boards[self.history_board_key]
        elif has_current:
            board = store.boards[current_key]
        else:
            board = boards[0]
        self.history_board_key = board.key
        self.board_picker.value = f"{board.seed}:{int(board.random_ports)}"
        self.current_board_btn.visible = has_current and board.key != current_key
        self.board_chips.controls = [
            ft.Container(
                ft.Column([
                    ft.Text(
                        f"Brett {b.seed}" + (" ★" if b.key == current_key else ""),
                        size=11,
                        color=BACKGROUND if b.key == board.key else INK,
                        weight=ft.FontWeight.BOLD,
                    ),
                    ft.Text(
                        f"Best {format_percent(b.best_win_rate)} · {len(b.attempts)} V.",
                        size=10,
                        color=BACKGROUND if b.key == board.key else MUTED,
                    ),
                ], spacing=1),
                padding=ft.Padding.symmetric(horizontal=10, vertical=6),
                bgcolor=ACCENT if b.key == board.key else "#14222D",
                border=ft.Border.all(1, ACCENT if b.key == board.key else "#273947"),
                border_radius=10,
                data=f"{b.seed}:{int(b.random_ports)}",
                on_click=self.select_history_board_chip,
            )
            for b in boards
        ]
        ports_label = "Zufällige Häfen" if board.random_ports else "Feste Anordnung"
        self.board_stats_text.value = (
            f"Brett {board.seed} · {ports_label} · Bestwert: {format_percent(board.best_win_rate)} · "
            f"Gesamt: {format_percent(board.overall_win_rate)} ({board.overall_wins}/{board.overall_decided} Siege)"
        )
        attempts = board.sorted_attempts()
        selected = next((a for a in attempts if a.key == self.history_attempt_key), attempts[0])
        self.history_attempt_key = selected.key
        catan_map, colors = board_layout(board.seed, board.random_ports)
        self.attempt_rows.controls = []
        for rank, attempt in enumerate(attempts, 1):
            _, _, _, est_rounds = attempt_analysis(catan_map, attempt)
            n1, n2 = attempt.human_nodes
            is_selected = attempt.key == selected.key
            verdict_color = VERDICT_COLORS[attempt.verdict]
            limit_note = f" · {attempt.limited} am Limit" if attempt.limited else ""
            rounds_note = f" · ≈ {est_rounds} Runden" if est_rounds is not None else ""
            matches_note = f" · {len(attempt.samples)} Endstände" if attempt.samples else ""
            self.attempt_rows.controls.append(ft.Container(
                ft.Column([
                    ft.Row([
                        ft.Text(f"#{rank} · {format_percent(attempt.win_rate)} gewonnen",
                                color=verdict_color, size=14, weight=ft.FontWeight.BOLD, expand=True),
                        ft.Container(
                            ft.Text(VERDICT_SHORT[attempt.verdict], size=11, color=BACKGROUND,
                                    weight=ft.FontWeight.BOLD),
                            bgcolor=verdict_color,
                            padding=ft.Padding.symmetric(horizontal=8, vertical=3),
                            border_radius=6,
                        ),
                    ]),
                    ft.Text(
                        f"{attempt.wins} von {attempt.decided} Siegen{limit_note} · "
                        f"Startplatz {attempt.seat + 1} ({COLOR_NAMES[colors[attempt.seat]]}) · "
                        f"{DICE_MODES[attempt.dice_mode]}{rounds_note}{matches_note}",
                        size=11, color=MUTED,
                    ),
                    ft.Text(f"1. {describe_node(catan_map, n1)}\n2. {describe_node(catan_map, n2)}",
                            size=11, color=INK),
                    self._build_win_distribution_bar(colors, attempt.wins_by_seat, attempt.decided),
                ], spacing=4),
                padding=12,
                bgcolor="#213444" if is_selected else "#14222D",
                border=ft.Border.all(1.5, ACCENT if is_selected else "#273947"),
                border_radius=12,
                data=attempt.key,
                on_click=self.select_history_attempt,
            ))

        mode = self.history_view_mode if self.history_view_mode in ("attempt", "spots", "matches") else "attempt"
        for mode_key, btn in (
            ("attempt", self.mode_attempt_btn),
            ("spots", self.mode_spots_btn),
            ("matches", self.mode_matches_btn),
        ):
            is_mode = mode == mode_key
            btn.style = ft.ButtonStyle(
                bgcolor=ACCENT if is_mode else "#101923",
                color=BACKGROUND if is_mode else INK,
            )
        canvas_width = max(200, self.width - 44)
        if mode == "attempt":
            self.spot_seat_chips.visible = False
            self._set_history_match_controls_visible(False)
            production, starting_cards, _, est_rounds = attempt_analysis(catan_map, selected)
            rank_idx = attempts.index(selected) + 1
            self.review_title.value = (
                f"Versuch #{rank_idx} · {format_percent(selected.win_rate)} gewonnen "
                f"({VERDICT_SHORT[selected.verdict]})"
            )
            self.review_title.color = VERDICT_COLORS[selected.verdict]
            self.review_detail.value = (
                f"Startplatz {selected.seat + 1} ({COLOR_NAMES[colors[selected.seat]]}) · "
                f"{DICE_MODES[selected.dice_mode]}"
                + (f" · ≈ {est_rounds} Runden bis 10 SP" if est_rounds is not None else "")
            )
            self.review_production.visible = True
            self.review_production.controls = resource_chips(production)
            cards_text = ", ".join(f"{v} {RESOURCE_NAMES[r]}" for r, v in starting_cards.items() if v)
            self.review_cards.visible = True
            self.review_cards.value = (f"Startkarten (2. Siedlung): {cards_text}"
                                       if cards_text else "Startkarten (2. Siedlung): keine")
            self.review_legend.value = "1 / 2 markiert deine erste und zweite Siedlung im 4-Spieler-Eröffnungsbild."
            render_key = ("attempt", board.key, selected.key, canvas_width, self.pips.value)
            self._draw_review_canvas(
                catan_map, canvas_width, render_key,
                lambda geom: attempt_review_shapes(
                    catan_map, opening_snapshot(catan_map, colors, selected),
                    selected.human_nodes, geom, show_pips=self.pips.value,
                ),
            )
        elif mode == "spots":
            self._set_history_match_controls_visible(False)
            self.spot_seat_chips.visible = True
            self.spot_seat_chips.controls = [
                ft.Container(
                    ft.Text(
                        label,
                        size=11,
                        color=BACKGROUND if self.history_spot_seat == seat_key else INK,
                        weight=ft.FontWeight.BOLD,
                    ),
                    padding=ft.Padding.symmetric(horizontal=9, vertical=5),
                    bgcolor=ACCENT if self.history_spot_seat == seat_key else "#101923",
                    border=ft.Border.all(1, ACCENT if self.history_spot_seat == seat_key else "#273947"),
                    border_radius=8,
                    data=seat_key,
                    on_click=self.select_spot_seat,
                )
                for seat_key, label in [(None, "Alle")] + [(i, f"Platz {i + 1}") for i in range(4)]
            ]
            spots = store.spot_stats(board.seed, board.random_ports, seat=self.history_spot_seat)
            decided_spots = [st for st in spots.values() if st.win_rate is not None]
            good_count = sum(st.verdict == "good" for st in spots.values())
            bad_count = sum(st.verdict == "bad" for st in spots.values())
            neutral_count = len(decided_spots) - good_count - bad_count
            seat_note = "" if self.history_spot_seat is None else f" · Platz {self.history_spot_seat + 1}"
            self.review_title.value = f"Kreuzungs-Vergleich · {len(spots)} getestete Siedlungsplätze{seat_note}"
            self.review_title.color = INK
            self.review_detail.value = (
                f"{good_count} gut (> 50 %) · {neutral_count} mittel (25–50 %) · {bad_count} schlecht (< 25 %)"
            )
            self.review_production.visible = False
            self.review_production.controls = []
            self.review_cards.visible = True
            lines = []
            if self.selected_review_node is not None and 0 <= self.selected_review_node < 54:
                focused_stat = spots.get(self.selected_review_node)
                if focused_stat is not None:
                    lines.append(
                        f"Ausgewählt (K{focused_stat.node}): {format_percent(focused_stat.win_rate)} "
                        f"({focused_stat.wins}/{focused_stat.decided} Siege · {focused_stat.attempts} Versuche) · "
                        f"{describe_node(catan_map, focused_stat.node)}"
                    )
                else:
                    lines.append(
                        f"Ausgewählt (K{self.selected_review_node}): Noch nicht getestet · "
                        f"{describe_node(catan_map, self.selected_review_node)}"
                    )
            if decided_spots:
                best_spot, worst_spot = decided_spots[0], decided_spots[-1]
                lines.append(
                    f"Bester Platz: {format_percent(best_spot.win_rate)} ({best_spot.wins}/{best_spot.decided}) · "
                    f"{describe_node(catan_map, best_spot.node)}"
                )
                if worst_spot.node != best_spot.node:
                    lines.append(
                        f"Schwächster Platz: {format_percent(worst_spot.win_rate)} "
                        f"({worst_spot.wins}/{worst_spot.decided}) · {describe_node(catan_map, worst_spot.node)}"
                    )
            elif not lines:
                lines.append("Noch keine entschiedenen Partien auf diesen Kreuzungen.")
            self.review_cards.value = "\n".join(lines)
            self.review_legend.value = (
                "Grün > 50 % (gut) · Gold 25–50 % (mittel) · Rot < 25 % (schlecht) · "
                "Ring: gewählter Versuch · Tippen zeigt Detailwerte"
            )
            render_key = (
                "spots", board.key, self.history_spot_seat, self.selected_review_node,
                tuple((st.node, st.wins, st.decided) for st in spots.values()),
                selected.human_nodes, canvas_width, self.pips.value,
            )
            self._draw_review_canvas(
                catan_map, canvas_width, render_key,
                lambda geom: spot_comparison_shapes(
                    catan_map, spots, geom, show_pips=self.pips.value,
                    selected_nodes=selected.human_nodes, focused_node=self.selected_review_node,
                ),
            )
        else:
            self.spot_seat_chips.visible = False
            self.review_production.visible = False
            self.review_production.controls = []
            if not selected.samples:
                self._set_history_match_controls_visible(False)
                self.review_title.value = "Endstände · keine Einzelpartien gespeichert"
                self.review_title.color = INK
                self.review_detail.value = "Für ältere Verläufe liegen noch keine Einzelpartien vor."
                self.review_cards.visible = True
                self.review_cards.value = "Neue Simulationen speichern bis zu 24 Endstände pro Versuch."
                self.review_legend.value = "1 / 2 markiert deine gespeicherte Eröffnung."
                render_key = ("matches-empty", board.key, selected.key, canvas_width, self.pips.value)
                self._draw_review_canvas(
                    catan_map, canvas_width, render_key,
                    lambda geom: attempt_review_shapes(
                        catan_map, opening_snapshot(catan_map, colors, selected),
                        selected.human_nodes, geom, show_pips=self.pips.value,
                    ),
                )
                return

            self._set_history_match_controls_visible(True)
            self.review_cards.visible = True
            self.history_match_picker.options = [
                ft.DropdownOption(
                    str(sm.index),
                    f"Partie {sm.index + 1} · "
                    + ("Kein Sieger (Limit)" if sm.winner is None else f"{COLOR_NAMES[sm.winner]} gewinnt"),
                )
                for sm in selected.samples
            ]
            sample = next((sm for sm in selected.samples if str(sm.index) == self.history_match_index),
                          selected.samples[0])
            self.history_match_index = str(sample.index)
            self.history_match_picker.value = str(sample.index)
            human_color = colors[selected.seat]
            self.history_match_chips.controls = [
                ft.Container(
                    ft.Text(
                        f"#{sm.index + 1} " + ("Limit" if sm.winner is None else COLOR_NAMES[sm.winner]),
                        size=11,
                        color=BACKGROUND if sm.index == sample.index else COLORS.get(sm.winner, MUTED),
                        weight=ft.FontWeight.BOLD,
                    ),
                    padding=ft.Padding.symmetric(horizontal=9, vertical=5),
                    bgcolor=ACCENT if sm.index == sample.index else "#101923",
                    border=ft.Border.all(1, ACCENT if sm.index == sample.index else "#273947"),
                    border_radius=8,
                    data=str(sm.index),
                    on_click=self.select_history_match_chip,
                )
                for sm in selected.samples
            ]
            self.review_title.value = (
                f"Partie {sample.index + 1} · "
                + ("Kein Sieger" if sample.winner is None else
                   f"{COLOR_NAMES[sample.winner]} gewinnt" + (" · Du" if sample.winner == human_color else ""))
            )
            self.review_title.color = COLORS.get(sample.winner, INK)
            self.review_detail.value = (
                f"{sample.turns} Züge · {sample.seconds:.1f} s · {DICE_MODES[selected.dice_mode]}"
            )
            vp_drawn_total = sample.activity.cards_bought[4] if len(sample.activity.cards_bought) > 4 else 0
            knights_played_total = sample.activity.cards_played[0] if sample.activity.cards_played else 0
            self.review_cards.value = (
                f"Gezogene SP-Karten im Spiel: {vp_drawn_total} · Gespielte Ritter gesamt: {knights_played_total} · "
                f"Handel: {sample.activity.player_trades} Spieler / {sample.activity.bank_trades} Bank"
            )
            self.history_match_scores.controls = self._build_match_score_rows(
                colors, human_color, sample, canvas_width,
            )
            self.review_legend.value = "Stadt: Haus mit Punkt · R: Räuber"
            render_key = ("matches", board.key, selected.key, sample, canvas_width, self.pips.value)
            self._draw_review_canvas(
                catan_map, canvas_width, render_key,
                lambda geom: board_shapes(catan_map, sample.board, geom, show_pips=self.pips.value),
            )

    def change_board_sort(self, e):
        self.history_notice.visible = False
        self.render_history()
        self.page.update()

    def toggle_history_filter(self, e):
        self.history_current_only = not self.history_current_only
        self.history_attempt_key = None
        self.history_match_index = None
        self.selected_review_node = None
        self.history_notice.visible = False
        self.render_history()
        self.page.update()

    def select_history_board_chip(self, e):
        self.board_picker.value = str(e.control.data)
        self.select_history_board(None)

    def select_history_board(self, e):
        if not self.board_picker.value:
            return
        try:
            seed_part, ports_part = self.board_picker.value.split(":")
            key = (int(seed_part), bool(int(ports_part)))
        except ValueError:
            return
        if key in self.history_store.boards:
            self.history_board_key = key
            self.history_attempt_key = None
            self.history_match_index = None
            self.selected_review_node = None
            self.history_notice.visible = False
            self.render_history()
            self.page.update()

    def focus_current_board(self, e):
        key = (self.session.seed, self.session.random_ports)
        if key in self.history_store.boards:
            self.history_board_key = key
            self.history_attempt_key = None
            self.history_match_index = None
            self.selected_review_node = None
            self.history_notice.visible = False
            self.render_history()
            self.page.update()

    def select_history_attempt(self, e):
        self.history_attempt_key = e.control.data
        self.history_match_index = None
        self.history_notice.visible = False
        self.render_history()
        self.page.update()

    def show_attempt_view(self, e):
        self.history_view_mode = "attempt"
        self.render_history()
        self.page.update()

    def show_spots_view(self, e):
        self.history_view_mode = "spots"
        self.render_history()
        self.page.update()

    def show_matches_view(self, e):
        self.history_view_mode = "matches"
        self.render_history()
        self.page.update()

    def select_spot_seat(self, e):
        self.history_spot_seat = e.control.data
        self.render_history()
        self.page.update()

    def tap_review_board(self, e):
        if self.busy or self.history_view_mode != "spots" or e.local_position is None:
            return
        if self.history_board_key not in self.history_store.boards:
            return
        hit = self.review_geometry.hit(e.local_position.x, e.local_position.y, range(54), ())
        if not hit or hit[0] != "node":
            return
        self.selected_review_node = None if self.selected_review_node == hit[1] else hit[1]
        self.render_history()
        self.page.update()

    def select_history_match(self, e):
        self.history_match_index = self.history_match_picker.value
        self.render_history()
        self.page.update()

    def select_history_match_chip(self, e):
        self.history_match_index = str(e.control.data)
        self.render_history()
        self.page.update()

    async def play_history_board(self, e):
        if self.busy or self.history_board_key not in self.history_store.boards:
            return
        board = self.history_store.boards[self.history_board_key]
        attempts = board.sorted_attempts()
        selected = next((a for a in attempts if a.key == self.history_attempt_key), attempts[0])
        self.ports.value = "random" if board.random_ports else "fixed"
        self.switch_tab("play")
        await self.replace_session(board.seed, selected.seat)

    def load_history_attempt(self, e):
        if self.busy or self.history_board_key not in self.history_store.boards:
            return
        board = self.history_store.boards[self.history_board_key]
        attempts = board.sorted_attempts()
        selected = next((a for a in attempts if a.key == self.history_attempt_key), attempts[0])
        if self.session.results.decided:
            self.previous = ((self.session.seed, self.session.seat, self.session.random_ports, self.session.dice_mode),
                             self.session.results.wins[self.session.human], self.session.results.decided)
        self.session.close()
        self.session = reconstruct_session(board, selected)
        self.show_ai_opening = False
        self.seed.value = str(board.seed)
        self.ports.value = "random" if board.random_ports else "fixed"
        self.geometry = BoardGeometry(self.session.game.state.board.map, self.width)
        self.progress.visible = self.progress_text.visible = False
        self.show_error()
        self.switch_tab("play")
        self.refresh()

    async def delete_history_attempt(self, e):
        if self.busy or self.history_board_key is None or self.history_attempt_key is None:
            return
        seed, random_ports = self.history_board_key
        if self.history_store.delete_attempt(seed, random_ports, self.history_attempt_key):
            self.history_attempt_key = None
            self.history_match_index = None
            self.history_notice.value = "Versuch aus dem Verlauf gelöscht."
            self.history_notice.visible = True
            await self.save_history()
            self.refresh()

    async def export_history(self, e):
        sort_mode = self.board_sort.value if self.board_sort.value in BOARD_SORT_MODES else "best_win_rate"
        payload = self.history_store.to_export_json(sort_mode=sort_mode)
        self.last_exported_json = payload
        if self._has_page_services():
            try:
                saved = await self.file_picker.save_file(
                    dialog_title="Eröffnungsverlauf exportieren",
                    file_name="catan-eroeffnungen.json",
                    file_type=ft.FilePickerFileType.CUSTOM,
                    allowed_extensions=["json"],
                    src_bytes=payload.encode("utf-8"),
                )
                if saved is None and not getattr(self.page, "web", False):
                    self.history_notice.value = "Export abgebrochen."
                else:
                    self.history_notice.value = "JSON-Datei exportiert."
            except Exception:
                await self.clipboard.set(payload)
                self.history_notice.value = "Direktdownload nicht verfügbar – JSON in Zwischenablage kopiert."
        else:
            self.history_notice.value = "JSON-Export bereit."
        self.history_notice.visible = True
        self.page.update()

    async def copy_history(self, e):
        sort_mode = self.board_sort.value if self.board_sort.value in BOARD_SORT_MODES else "best_win_rate"
        payload = self.history_store.to_export_json(sort_mode=sort_mode)
        self.last_exported_json = payload
        if self._has_page_services():
            try:
                await self.clipboard.set(payload)
                self.history_notice.value = "JSON in Zwischenablage kopiert."
            except Exception as exc:
                self.history_notice.value = f"Zwischenablage nicht verfügbar: {exc}"
        else:
            self.history_notice.value = "JSON in Zwischenablage kopiert."
        self.history_notice.visible = True
        self.page.update()

    async def _apply_imported_json(self, raw: str):
        try:
            added, updated = self.history_store.merge_import_json(raw)
        except ValueError as exc:
            self.history_notice.value = f"Import fehlgeschlagen: {exc}"
            self.history_notice.visible = True
            self.page.update()
            return
        if added == 0 and updated == 0:
            self.history_notice.value = "Keine neuen oder neueren Einträge im JSON gefunden."
        else:
            self.history_notice.value = f"Importiert: {added} neue, {updated} aktualisierte Versuche."
            self.history_attempt_key = None
            self.history_match_index = None
            self.selected_review_node = None
            await self.save_history()
        self.history_notice.visible = True
        self.refresh()

    async def import_history(self, e):
        if self.busy:
            return
        raw = None
        if self._has_page_services():
            try:
                files = await self.file_picker.pick_files(
                    dialog_title="Eröffnungsverlauf importieren",
                    file_type=ft.FilePickerFileType.CUSTOM,
                    allowed_extensions=["json"],
                    allow_multiple=False,
                    with_data=True,
                )
                if not files:
                    self.history_notice.value = "Import abgebrochen."
                    self.history_notice.visible = True
                    self.page.update()
                    return
                picked = files[0]
                if picked.bytes is not None:
                    raw = picked.bytes.decode("utf-8")
                elif picked.path:
                    from pathlib import Path
                    raw = Path(picked.path).read_text(encoding="utf-8")
            except Exception:
                raw = None
        if raw is None and self._has_page_services():
            try:
                raw = await self.clipboard.get()
            except Exception:
                raw = None
        if not raw:
            self.history_notice.value = "Dateiauswahl/Zwischenablage nicht verfügbar – nutze 'JSON einfügen'."
            self.history_notice.visible = True
            self.page.update()
            return
        await self._apply_imported_json(raw)

    async def paste_import_history(self, e):
        if self.busy:
            return
        if self._has_page_services():
            try:
                raw = await self.clipboard.get()
            except Exception as exc:
                self.history_notice.value = f"Zwischenablage nicht verfügbar: {exc}"
                self.history_notice.visible = True
                self.page.update()
                return
        else:
            raw = self.last_exported_json
        if not raw:
            self.history_notice.value = "Zwischenablage ist leer."
            self.history_notice.visible = True
            self.page.update()
            return
        await self._apply_imported_json(raw)

    def toggle_pips(self, e):
        self.refresh()

    def select_sample(self, e):
        self.render_results()
        self.page.update()

    def select_sample_chip(self, e):
        self.sample_picker.value = str(e.control.data)
        self.render_results()
        self.page.update()

    def change_dice_mode(self, e):
        if not self.busy and self.dice_mode.value != self.session.dice_mode:
            self.session.dice_mode = self.dice_mode.value
            self.previous = None
            self.progress.visible = self.progress_text.visible = False
            self.show_error()
        self.refresh()

    def tap(self, e):
        if self.busy or not self.session.human_turn or e.local_position is None:
            return
        hit = self.geometry.hit(e.local_position.x, e.local_position.y,
                                self.session.legal_nodes, self.session.legal_roads)
        if not hit:
            return
        self.show_error()
        if hit[0] == "node":
            self.session.select_node(hit[1])
        else:
            self.session.select_road(hit[1])
        self.refresh()

    async def advance(self):
        self.busy = True
        self.refresh()
        try:
            await self.session.advance_bots(self.refresh)
        except Exception as exc:
            self.show_error(f"Computerplatzierung fehlgeschlagen: {exc}")
        finally:
            self.busy = False
            self.refresh()

    async def commit(self, e):
        if self.busy:
            return
        try:
            self.session.commit()
            self.show_error()
            await self.advance()
        except ValueError as exc:
            self.show_error(str(exc))
            self.refresh()

    def undo(self, e):
        if not self.busy:
            self.session.undo()
            self.show_error()
            self.refresh()

    async def toggle_ai_opening(self, e):
        if self.busy:
            return
        if self.show_ai_opening:
            self.show_ai_opening = False
            self.refresh()
            return
        self.busy = True
        self.refresh()
        try:
            await self.session.compute_ai_opening_placements()
            self.show_ai_opening = True
            self.show_error()
        except Exception as exc:
            self.show_ai_opening = False
            self.show_error(f"KI-Eröffnung konnte nicht berechnet werden: {exc}")
        finally:
            self.busy = False
            self.refresh()

    async def apply_ai_opening(self, e):
        if self.busy:
            return
        self.busy = True
        self.refresh()
        try:
            placements = await self.session.compute_ai_opening_placements()
            if self.session.results.decided:
                self.previous = ((self.session.seed, self.session.seat,
                                  self.session.random_ports, self.session.dice_mode),
                                 self.session.results.wins[self.session.human], self.session.results.decided)
            self.session.apply_opening_placements(placements)
            self.geometry = BoardGeometry(self.session.game.state.board.map, self.width)
            self.progress.visible = self.progress_text.visible = False
            self.show_ai_opening = True
            self.show_error()
        except Exception as exc:
            self.show_error(f"KI-Eröffnung konnte nicht übernommen werden: {exc}")
        finally:
            self.busy = False
            self.refresh()

    async def replace_session(self, seed=None, seat=None):
        if self.busy:
            return
        if self.session.results.decided:
            self.previous = ((self.session.seed, self.session.seat, self.session.random_ports, self.session.dice_mode),
                             self.session.results.wins[self.session.human], self.session.results.decided)
        self.session.close()
        self.session = OpeningSession(seed, seat, self.ports.value == "random", dice_mode=self.session.dice_mode)
        self.show_ai_opening = False
        self.seed.value = str(self.session.seed)
        self.geometry = BoardGeometry(self.session.game.state.board.map, self.width)
        self.progress.visible = self.progress_text.visible = False
        self.show_error()
        await self.advance()

    async def new_game(self, e):
        seat = None if self.seat.value == "random" else int(self.seat.value)
        if self.active_tab != "play":
            self.switch_tab("play")
        await self.replace_session(seat=seat)

    async def retry(self, e):
        # Retry the actual port setting/seat, even if settings for the next board changed.
        self.ports.value = "random" if self.session.random_ports else "fixed"
        if self.active_tab != "play":
            self.switch_tab("play")
        await self.replace_session(self.session.seed, self.session.seat)

    async def load(self, e):
        try:
            seed = int(self.seed.value)
            if not 0 <= seed < 2**63:
                raise ValueError
            seat = None if self.seat.value == "random" else int(self.seat.value)
            self.switch_tab("play")
            await self.replace_session(seed, seat)
        except ValueError:
            self.show_error("Der Brett-Code muss eine ganze Zahl zwischen 0 und 9223372036854775807 sein.")
            self.refresh()

    def quick_count(self, e):
        if not self.busy:
            self.count.value = str(e.control.data)
            self.page.update()

    def stop(self, e):
        self.session.cancel()
        self.progress_text.value = "Wird gestoppt …"
        self.page.update()

    async def simulate(self, e):
        if self.busy:
            return
        try:
            count = int(self.count.value)
            if not 1 <= count <= MAX_SIMULATIONS:
                raise ValueError
        except (ValueError, TypeError):
            self.show_error(f"Wähle 1 bis {MAX_SIMULATIONS} Simulationen.")
            self.refresh()
            return
        self.show_error()
        existing = self.history_store.matching_attempt(self.session)
        self.session.initial_sample_index = existing.next_index if existing else 0
        existing_indices = {sample.index for sample in self.session.results.samples}
        self.busy = True
        self.progress.visible = self.progress_text.visible = True
        self.progress.value = 0
        self.progress_text.value = f"Partie 1 von {count} …"
        self.refresh()
        rendered_count = len(self.session.results.samples)
        def progress(done, target, turns):
            nonlocal rendered_count
            self.progress.value = done / target
            self.progress_text.value = (f"{done} von {target} Partien fertig" if not turns else
                                        f"{done} von {target} Partien fertig · Zug {turns}")
            if len(self.session.results.samples) != rendered_count:
                self.render_results()
                rendered_count = len(self.session.results.samples)
            self.page.update()
        try:
            await self.session.simulate(count, progress)
            if self.session.cancelled:
                self.progress_text.value = "Gestoppt. Abgeschlossene Partien bleiben erhalten."
            else:
                self.progress_text.value = f"Fertig · {len(self.session.results.samples)} Partien insgesamt"
        except Exception as exc:
            self.show_error(f"Simulation fehlgeschlagen: {exc}")
            self.progress_text.value = "Berechnung angehalten."
        finally:
            new_samples = [sample for sample in self.session.results.samples
                           if sample.index not in existing_indices]
            if new_samples:
                recorded = self.history_store.record_samples(self.session, new_samples)
                if recorded is not None:
                    self.history_board_key = (self.session.seed, self.session.random_ports)
                    self.history_attempt_key = recorded.key
                    self.history_notice.visible = False
                    await self.save_history()
            self.busy = False
            self.refresh()


async def main(page: ft.Page):
    app = TrainerApp(page)
    await app.start()


if __name__ == "__main__":
    ft.run(main)

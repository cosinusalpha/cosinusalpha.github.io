"""Run with `flet run src/main.py`; publish with `python tools/build_web.py`."""

from __future__ import annotations

import asyncio
import math
from collections import Counter
import flet as ft
import flet.canvas as cv

from catanatron.models.enums import SETTLEMENT
from trainer.engine import OpeningSession, COLOR_NAMES, RESOURCE_NAMES, MAX_SIMULATIONS, AI_NAME, DEV_NAMES, DICE_MODES
from trainer.board import BoardGeometry
from trainer.history import (
    attempt_analysis, BOARD_SORT_MODES, board_layout, describe_node, format_percent, HistoryStore,
    opening_snapshot, reconstruct_session, STORAGE_KEY, VERDICT_SHORT,
)
from trainer.view import (
    ACCENT, attempt_review_shapes, BACKGROUND, board_shapes, COLORS, INK, MUTED, opening_shapes,
    PANEL, resource_chips, spot_comparison_shapes, VERDICT_COLORS,
)


class TrainerApp:
    def __init__(self, page: ft.Page):
        self.page = page
        self.prefs = ft.SharedPreferences()
        self.file_picker = ft.FilePicker()
        self.clipboard = ft.Clipboard()
        self.history_store = HistoryStore()
        self.history_board_key: tuple[int, bool] | None = None
        self.history_attempt_key = None
        self.history_view_mode = "attempt"
        self.history_render_key = None
        self.last_exported_json = ""
        self.session = OpeningSession()
        self.busy = False
        self.previous = None
        self.width = self.board_width()
        self.geometry = BoardGeometry(self.session.game.state.board.map, self.width)
        self.canvas = cv.Canvas(width=self.width, height=self.geometry.height)
        self.board_touch = ft.GestureDetector(content=self.canvas, on_tap_up=self.tap)
        self.pips = ft.Switch(label="Wahrscheinlichkeitspunkte", value=True,
                              active_color=ACCENT, label_text_style=ft.TextStyle(size=13, color=INK),
                              on_change=self.toggle_pips)
        self.node_pips = ft.Switch(label="Punktesumme an Kreuzungen", value=False,
                                   active_color=ACCENT, label_text_style=ft.TextStyle(size=13, color=INK),
                                   on_change=self.toggle_pips)
        self.node_pips_hint = ft.Text("Summe der angrenzenden Würfelpunkte · erwartete Rohstoffe pro 36 Würfe",
                                      size=11, color=MUTED, visible=False)
        self.status = ft.Text(size=16, weight=ft.FontWeight.BOLD, color=INK)
        self.detail = ft.Text(size=12, color=MUTED)
        self.live_victory = ft.Text(size=12, color=ACCENT, max_lines=2)
        self.error = ft.Text(size=12, color="#F17F77", visible=False)
        self.progress = ft.ProgressBar(value=0, color=ACCENT, bgcolor="#283C49", visible=False)
        self.progress_text = ft.Text(size=12, color=MUTED, visible=False)
        self.players = ft.Row(wrap=True, spacing=12)
        self.production = ft.Row(wrap=True, spacing=6, run_spacing=6)
        self.start_cards = ft.Text(size=12, color=MUTED)
        self.victory_preview = ft.Text(size=18, color=ACCENT, weight=ft.FontWeight.BOLD)
        self.victory_context = ft.Text(size=11, color=MUTED, visible=False)
        self.victory_panel = ft.Container(ft.Column([
            ft.Text("Runden bis 10 Siegpunkte", size=14, color=INK, weight=ft.FontWeight.BOLD),
            self.victory_preview, self.victory_context,
            ft.Text("Rohstoff-Schätzwert · 1 Runde = 4 Spielerzüge", size=11, color=MUTED),
            ft.ExpansionTile(title=ft.Text("Annahmen und Berechnung", size=12, color=MUTED), controls=[
                ft.Text("Fester Vergleichsplan ab 2 Start-Siedlungen: 4 weitere Siedlungen, 4 Stadtausbauten "
                        "und 8 zusätzliche Straßen ergeben 10 Siegpunkte. Bedarf: 12 Holz, 12 Lehm, 4 Wolle, "
                        "12 Getreide, 12 Erz. Startkarten und Bank-/Start-Hafenhandel zählen mit.\n"
                        "Solange erst eine Siedlung gewählt ist, zählt vorläufig nur deren Ertrag und Hafen; "
                        "der Ertrag und die Startkarten der zweiten Siedlung sind noch offen.\n"
                        "Gerechnet wird mit der durchschnittlichen Startproduktion, auch während des Ausbaus. "
                        "Spätere Produktionszuwächse, freie Bauplätze, Mitspieler, Räuber, Kartenlimit und Sonderpunkte "
                        "werden nicht eingerechnet. Ein Vergleichswert für Eröffnungen, keine Prognose der Spieldauer.",
                        size=11, color=MUTED),
            ]),
        ], spacing=6), padding=14, bgcolor=PANEL, border_radius=14)
        self.result_title = ft.Text(size=20, color=INK, weight=ft.FontWeight.BOLD)
        self.result_mode = ft.Text(size=12, color=MUTED)
        self.result_rows = ft.Column(spacing=8)
        self.sample_rows = ft.Column(spacing=6)
        self.sample_picker = ft.Dropdown(label="Endstand einer Partie", dense=True, text_size=13,
                                         on_select=self.select_sample)
        self.final_title = ft.Text(size=16, color=INK, weight=ft.FontWeight.BOLD)
        self.final_detail = ft.Text(size=12, color=MUTED)
        self.final_activity = ft.Text(size=12, color=MUTED)
        self.final_awards = ft.Column(spacing=6)
        self.final_scores = ft.Column(spacing=6)
        self.final_geometry = BoardGeometry(self.session.game.state.board.map, self.width - 36)
        self.final_canvas = cv.Canvas(width=self.final_geometry.width, height=self.final_geometry.height)
        self.final_render_key = None
        self.previous_text = ft.Text(size=12, color=MUTED, visible=False)
        self.saved_attempt_text = ft.Text(size=12, color=ACCENT, visible=False)
        self.results_panel = ft.Container(ft.Column([
            self.result_title, self.result_mode, self.previous_text, self.saved_attempt_text, self.result_rows,
            ft.Text("Einzelne Partien", color=MUTED, size=12), self.sample_rows,
            self.sample_picker, self.final_title, self.final_detail, self.final_awards, self.final_activity,
            ft.Container(self.final_canvas, alignment=ft.Alignment.CENTER, bgcolor="#142631", border_radius=12),
            ft.Text("Stadt: Haus mit Punkt · R: Räuber", color=MUTED, size=11), self.final_scores,
            ft.Text("Bei wenigen Partien schwankt das Ergebnis stark. Alle vier Plätze spielen mit derselben KI.",
                    color=MUTED, size=11),
        ], spacing=12), padding=18, bgcolor=PANEL, border_radius=16, visible=False)
        self.history_summary = ft.Text(size=12, color=MUTED)
        self.history_empty = ft.Text(
            "Noch keine simulierten Bretter gespeichert. Nach einer Simulation werden deine Eröffnungen "
            "hier pro Brett nach % gewonnen sortiert.",
            size=12, color=MUTED,
        )
        self.export_btn = ft.OutlinedButton("JSON exportieren", icon=ft.Icons.DOWNLOAD, on_click=self.export_history)
        self.copy_export_btn = ft.TextButton("JSON kopieren", icon=ft.Icons.CONTENT_COPY, on_click=self.copy_history)
        self.history_notice = ft.Text(size=11, color=ACCENT, visible=False)
        self.board_sort = ft.Dropdown(
            label="Brett-Sortierung", value="best_win_rate", dense=True, text_size=13,
            options=[ft.DropdownOption(key, label) for key, label in BOARD_SORT_MODES.items()],
            on_select=self.change_board_sort,
        )
        self.board_picker = ft.Dropdown(label="Gespieltes Brett", dense=True, text_size=13,
                                        on_select=self.select_history_board)
        self.current_board_btn = ft.TextButton("Aktuelles Brett zeigen", icon=ft.Icons.MY_LOCATION,
                                               on_click=self.focus_current_board, visible=False)
        self.board_stats_text = ft.Text(size=12, color=MUTED)
        self.attempt_rows = ft.Column(spacing=8)
        self.mode_attempt_btn = ft.Button("Gewählter Versuch", icon=ft.Icons.HOME,
                                          on_click=self.show_attempt_view, height=38,
                                          style=ft.ButtonStyle(bgcolor=ACCENT, color=BACKGROUND))
        self.mode_spots_btn = ft.OutlinedButton("Gute / schlechte Plätze (%)", icon=ft.Icons.ANALYTICS,
                                                on_click=self.show_spots_view, height=38)
        self.review_title = ft.Text(size=15, color=INK, weight=ft.FontWeight.BOLD)
        self.review_detail = ft.Text(size=12, color=MUTED)
        self.review_production = ft.Row(wrap=True, spacing=6, run_spacing=6)
        self.review_cards = ft.Text(size=12, color=MUTED)
        self.review_geometry = BoardGeometry(self.session.game.state.board.map, self.width - 36)
        self.review_canvas = cv.Canvas(width=self.review_geometry.width, height=self.review_geometry.height)
        self.review_legend = ft.Text(size=11, color=MUTED)
        self.replay_board_btn = ft.OutlinedButton("Dieses Brett spielen", icon=ft.Icons.REPLAY,
                                                  on_click=self.play_history_board)
        self.load_attempt_btn = ft.TextButton("Diese Eröffnung laden", icon=ft.Icons.RESTORE,
                                              on_click=self.load_history_attempt)
        self.delete_attempt_btn = ft.TextButton("Versuch löschen", icon=ft.Icons.DELETE_OUTLINE,
                                                on_click=self.delete_history_attempt)
        self.history_body = ft.Column([
            self.history_summary,
            ft.Row([self.export_btn, self.copy_export_btn], wrap=True),
            self.history_notice,
            self.board_sort,
            self.board_picker,
            self.current_board_btn,
            self.board_stats_text,
            ft.Text("Platzierungen auf diesem Brett · sortiert nach % gewonnen", size=12, color=MUTED),
            self.attempt_rows,
            ft.Row([self.mode_attempt_btn, self.mode_spots_btn], wrap=True),
            self.review_title,
            self.review_detail,
            self.review_production,
            self.review_cards,
            ft.Container(self.review_canvas, alignment=ft.Alignment.CENTER, bgcolor="#142631", border_radius=12),
            self.review_legend,
            ft.Row([self.replay_board_btn, self.load_attempt_btn, self.delete_attempt_btn], wrap=True),
        ], spacing=10, visible=False)
        self.history_panel = ft.Container(ft.Column([
            ft.Text("Brett-Verlauf & Platzierungs-Analyse", size=18, color=INK, weight=ft.FontWeight.BOLD),
            self.history_empty,
            self.history_body,
        ], spacing=10), padding=18, bgcolor=PANEL, border_radius=16)
        self.commit_btn = ft.Button("Platzierung bestätigen", icon=ft.Icons.CHECK,
                                    on_click=self.commit, height=46,
                                    style=ft.ButtonStyle(bgcolor=ACCENT, color=BACKGROUND))
        self.undo_btn = ft.TextButton("Zurück", icon=ft.Icons.UNDO, on_click=self.undo)
        self.new_btn = ft.OutlinedButton("Neues Brett", icon=ft.Icons.SHUFFLE, on_click=self.new_game)
        self.retry_btn = ft.TextButton("Dieses Brett erneut", icon=ft.Icons.REPLAY, on_click=self.retry)
        self.count = ft.TextField(label="Simulationen", value="5", width=128, dense=True,
                                  keyboard_type=ft.KeyboardType.NUMBER,
                                  input_filter=ft.InputFilter(allow=True, regex_string=r"[0-9]"))
        self.sim_btn = ft.Button("Simulieren", icon=ft.Icons.PLAY_ARROW, on_click=self.simulate, height=46,
                                 style=ft.ButtonStyle(bgcolor=ACCENT, color=BACKGROUND))
        self.stop_btn = ft.TextButton("Stoppen", icon=ft.Icons.STOP, on_click=self.stop, visible=False)
        self.dice_mode = ft.Dropdown(label="Würfelmodus", value=self.session.dice_mode, dense=True,
                                     options=[ft.DropdownOption(key, label) for key, label in DICE_MODES.items()],
                                     on_select=self.change_dice_mode)
        self.dice_hint = ft.Text(size=11, color=MUTED)
        self.seat = ft.Dropdown(label="Startplatz", value="random", width=154, dense=True,
                                options=[ft.DropdownOption("random", "Zufällig")] +
                                [ft.DropdownOption(str(i), f"Startplatz {i + 1}") for i in range(4)])
        self.ports = ft.Dropdown(label="Häfen", value="fixed", width=154, dense=True,
                                 options=[ft.DropdownOption("fixed", "Feste Anordnung"),
                                          ft.DropdownOption("random", "Zufällig")])
        self.seed = ft.TextField(label="Brett-Code", value=str(self.session.seed), width=185, dense=True,
                                 keyboard_type=ft.KeyboardType.NUMBER)
        self.load_btn = ft.TextButton("Code laden", on_click=self.load)
        quick = ft.Row([ft.TextButton(str(n), data=n, on_click=self.quick_count)
                        for n in (1, 5, 10, 25, 50, 100)], wrap=True, spacing=0)
        self.opening_actions = ft.Row([self.commit_btn, self.undo_btn], wrap=True)
        self.simulation_actions = ft.Column([self.dice_mode, self.dice_hint,
                                             ft.Row([self.count, self.sim_btn, self.stop_btn], wrap=True), quick])
        self.root = ft.Column([
            ft.Row([ft.Container(ft.Icon(ft.Icons.GRID_VIEW, color=BACKGROUND, size=25),
                                 padding=10, bgcolor=ACCENT, border_radius=12),
                    ft.Column([ft.Text("Catan", size=25, color=INK, weight=ft.FontWeight.BOLD),
                               ft.Text("Eröffnungstrainer", color=MUTED, size=13)], spacing=0)], spacing=12),
            ft.Text("Platziere zwei Siedlungen und Straßen. Lass die KI anschließend weiterspielen.",
                    size=13, color=MUTED),
            ft.Container(ft.Column([self.players, self.status, ft.Container(self.detail, height=34),
                                     ft.Container(self.live_victory, height=34), self.error], spacing=6),
                         padding=16, bgcolor=PANEL, border_radius=14),
            ft.Container(self.board_touch, alignment=ft.Alignment.CENTER,
                         bgcolor="#142631", border_radius=16),
            self.pips,
            self.node_pips, self.node_pips_hint,
            self.opening_actions,
            ft.Text("Erwartete Produktion pro 36 Würfe · ohne Räuber", size=11, color=MUTED),
            self.production, self.start_cards, self.victory_panel,
            self.simulation_actions, self.progress, self.progress_text, self.results_panel,
            ft.Row([self.new_btn, self.retry_btn], wrap=True),
            self.history_panel,
            ft.Divider(color="#293A47"),
            ft.Text("Nächstes Brett", size=13, color=INK, weight=ft.FontWeight.BOLD),
            ft.Row([self.seat, self.ports], wrap=True),
            ft.Row([self.seed, self.load_btn], wrap=True),
            ft.Text("1 → 2 → 3 → 4 → 4 → 3 → 2 → 1\nHäfen: H Holz · L Lehm · W Wolle · G Getreide · E Erz",
                    size=11, color=MUTED),
            ft.Text(f"Simulation: {AI_NAME}",
                    size=10, color=MUTED),
            ft.TextButton("Quellcode und Herkunft", url="smart/source.tar.gz"),
        ], spacing=12, horizontal_alignment=ft.CrossAxisAlignment.STRETCH)
        page.title = "Catan · Eröffnungstrainer"
        page.bgcolor = BACKGROUND
        page.theme_mode = ft.ThemeMode.DARK
        page.theme = ft.Theme(color_scheme_seed=ACCENT, font_family="Roboto")
        page.padding = 16
        page.scroll = ft.ScrollMode.AUTO
        page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
        page.on_resize = self.resize
        page.on_disconnect = self.disconnect
        self.root.width = min(720, max(280, (page.width or 640) - 32))
        page.add(self.root)

    def board_width(self):
        return min(688, max(248, (self.page.width or 640) - 32))

    def _has_page_services(self) -> bool:
        return isinstance(self.page, ft.Page)

    async def load_history(self):
        if not self._has_page_services():
            return
        try:
            raw = await self.prefs.get(STORAGE_KEY)
        except Exception:
            return
        self.history_store = HistoryStore.from_storage_json(raw)

    async def save_history(self):
        if not self._has_page_services():
            return
        try:
            await self.prefs.set(STORAGE_KEY, self.history_store.to_storage_json())
        except Exception as exc:
            self.show_error(f"Verlauf konnte nicht gespeichert werden: {exc}")

    async def start(self):
        await self.load_history()
        await self.advance()

    def show_error(self, message=""):
        self.error.value = message
        self.error.visible = bool(message)

    def resize(self, e):
        self.width = self.board_width()
        self.root.width = min(720, max(280, (self.page.width or 640) - 32))
        self.canvas.width = self.width
        self.geometry = BoardGeometry(self.session.game.state.board.map, self.width)
        self.canvas.height = self.geometry.height
        self.refresh()

    def disconnect(self, e):
        self.session.close()

    def refresh(self):
        s = self.session
        self.canvas.shapes = opening_shapes(s, self.geometry, show_targets=not self.busy,
                                            show_pips=self.pips.value, show_node_pips=self.node_pips.value)
        self.node_pips.visible = not s.complete
        self.node_pips_hint.visible = not s.complete and self.node_pips.value
        self.players.controls = [ft.Text(f"{i + 1}. {COLOR_NAMES[c]}" + (" · Du" if c == s.human else ""),
                                        color=COLORS[c], size=12,
                                        weight=ft.FontWeight.BOLD if c == s.human else ft.FontWeight.NORMAL)
                                 for i, c in enumerate(s.game.state.colors)]
        own_count = len(s.game.state.buildings_by_color[s.human][SETTLEMENT])
        matching = self.history_store.matching_attempt(s) if s.complete else None
        if s.complete:
            self.status.value = "Eröffnung fertig"
            if matching is not None:
                self.detail.value = (
                    f"Im Verlauf: {format_percent(matching.win_rate)} gewonnen "
                    f"({matching.wins}/{matching.decided} Siege). Weitere Partien werden ergänzt."
                )
            else:
                self.detail.value = "Alle Plätze übernehmen dieselbe KI. Wähle die Anzahl der Partien."
        elif not s.human_turn:
            self.status.value = f"{COLOR_NAMES[s.game.state.current_color()]} platziert …"
            self.detail.value = f"Du bist auf Startplatz {s.seat + 1}."
        elif s.selected_node is None:
            self.status.value = f"Deine {'erste' if own_count == 0 else 'zweite'} Siedlung"
            self.detail.value = "Tippe auf eine helle Kreuzung."
        elif s.selected_edge is None:
            self.status.value = "Wähle die Straßenrichtung"
            self.detail.value = "Tippe auf einen markierten Straßenpunkt neben deiner Siedlung."
        else:
            self.status.value = "Siedlung und Straße gewählt"
            self.detail.value = "Bestätigen oder eine andere Kreuzung / Straße wählen."
        self.production.controls = resource_chips(s.production(include_selected=True))
        cards = s.starting_resources()
        if own_count == 1 and s.selected_node is not None:
            cards = Counter(t.resource for t in s.game.state.board.map.adjacent_tiles[s.selected_node] if t.resource)
        self.start_cards.value = ("Startkarten: " + ", ".join(f"{v} {RESOURCE_NAMES[r]}" for r, v in cards.items() if v)) if any(cards.values()) else "Startkarten erhältst du an deiner zweiten Siedlung."
        rounds = s.victory_rounds_preview()
        self.victory_preview.value = ("Tippe einen Siedlungsplatz an." if rounds is None else
                                      "Ohne Produktion nicht erreichbar" if math.isinf(rounds) else
                                      f"≈ {math.ceil(rounds - 1e-9)} Runden")
        preview_count = own_count + (s.selected_node is not None)
        provisional = preview_count == 1
        self.victory_context.visible = provisional or s.selected_node is not None
        self.victory_context.value = ("Vorläufig · zweite Siedlung noch offen." if provisional else
                                      "Vorschau deiner unbestätigten Platzierung.")
        prefix = ("Vorläufig (1 Siedlung): " if provisional else
                  "Vorschau: " if s.selected_node is not None else "Sieg-Schätzwert: ")
        self.live_victory.value = ("Sieg-Schätzung beim Antippen einer Kreuzung." if rounds is None else
                                   prefix + self.victory_preview.value)
        self.opening_actions.visible = not s.complete or bool(s.history)
        self.commit_btn.visible = not s.complete
        self.undo_btn.content = "Letzte Platzierung ändern" if s.complete else "Zurück"
        self.commit_btn.disabled = self.busy or s.selected_edge is None
        self.undo_btn.disabled = self.busy or not s.history
        self.simulation_actions.visible = s.complete
        self.sim_btn.content = "Weitere simulieren" if (s.results.samples or matching is not None) else "Simulieren"
        self.sim_btn.disabled = self.busy
        self.dice_mode.value = s.dice_mode
        self.dice_hint.value = (("Alle 36 Würfelkombinationen einmal ziehen, dann neu mischen." if s.dice_mode == "deck36"
                                else "Zwei unabhängige Würfel bei jedem Zug.") +
                               " Moduswechsel löscht die Simulationsergebnisse.")
        for control in (self.new_btn, self.retry_btn, self.seat, self.ports, self.seed, self.load_btn, self.count,
                        self.dice_mode, self.replay_board_btn, self.load_attempt_btn, self.delete_attempt_btn):
            control.disabled = self.busy
        self.stop_btn.visible = self.busy and s.complete
        self.render_results()
        self.render_history()
        self.page.update()

    def render_results(self):
        s, results = self.session, self.session.results
        self.results_panel.visible = bool(results.samples)
        decided = results.decided
        self.result_title.value = f"Du gewinnst {results.wins[s.human]} von {decided} Partien"
        self.result_mode.value = DICE_MODES[s.dice_mode]
        if results.limited:
            self.result_title.value += f" · {results.limited} am Zuglimit"
        self.result_rows.controls = []
        for i, c in enumerate(s.game.state.colors):
            wins = results.wins[c]
            self.result_rows.controls.append(ft.Column([
                ft.Row([ft.Text(f"{i + 1}. {COLOR_NAMES[c]}" + (" · Du" if c == s.human else ""), color=COLORS[c], expand=True),
                        ft.Text(f"{wins} Siege", color=INK, size=12)]),
                ft.ProgressBar(value=wins / decided if decided else 0, color=COLORS[c], bgcolor="#2B3B49", height=5),
            ], spacing=4))
        self.sample_rows.controls = [ft.Text(
            f"{sample.index + 1}. {'Zuglimit' if sample.winner is None else COLOR_NAMES[sample.winner] + ' gewinnt'}"
            f" · {sample.turns} Züge · {sample.seconds:.1f} s",
            color=COLORS.get(sample.winner, MUTED), size=12,
        ) for sample in results.samples[-12:]]
        previous = self.previous
        self.previous_text.visible = bool(previous and previous[0] == (s.seed, s.seat, s.random_ports, s.dice_mode))
        if self.previous_text.visible:
            self.previous_text.value = f"Voriger Versuch auf diesem Brett: {previous[1]} von {previous[2]} gewonnen."
        matching = self.history_store.matching_attempt(s)
        self.saved_attempt_text.visible = matching is not None
        if matching is not None:
            self.saved_attempt_text.value = (
                f"Gespeicherter Gesamtstand dieser Eröffnung: {format_percent(matching.win_rate)} gewonnen "
                f"({matching.wins}/{matching.decided} Siege)."
            )
        if not results.samples:
            self.sample_picker.value = None
            self.sample_picker.options = []
            self.final_canvas.shapes = []
            self.final_render_key = None
            return
        if len(self.sample_picker.options) != len(results.samples):
            self.sample_picker.options = [ft.DropdownOption(str(sample.index),
                f"Partie {sample.index + 1} · " + ("Kein Sieger (Limit)" if sample.winner is None else
                                                   f"{COLOR_NAMES[sample.winner]} gewinnt"))
                for sample in results.samples]
        sample = next((sample for sample in results.samples if str(sample.index) == self.sample_picker.value),
                      results.samples[0])
        self.sample_picker.value = str(sample.index)
        render_key = (sample, self.width - 36, self.pips.value)
        if render_key == self.final_render_key:
            return
        self.final_geometry = BoardGeometry(s.game.state.board.map, self.width - 36)
        self.final_canvas.width = self.final_geometry.width
        self.final_canvas.height = self.final_geometry.height
        self.final_canvas.shapes = board_shapes(s.game.state.board.map, sample.board, self.final_geometry,
                                                show_pips=self.pips.value)
        self.final_title.value = (f"Partie {sample.index + 1} · " +
                                  ("Kein Sieger" if sample.winner is None else
                                   f"{COLOR_NAMES[sample.winner]} gewinnt" + (" · Du" if sample.winner == s.human else "")))
        self.final_title.color = COLORS.get(sample.winner, INK)
        self.final_detail.value = (f"{sample.turns} Züge · {sample.seconds:.1f} s" +
                                   (" · Am Simulationslimit beendet" if sample.winner is None else ""))
        activity = sample.activity
        bought = ", ".join(f"{count} {name}" for name, count in zip(DEV_NAMES, activity.cards_bought) if count) or "keine"
        played = ", ".join(f"{count} {name}" for name, count in zip(DEV_NAMES, activity.cards_played) if count) or "keine"
        self.final_activity.value = (f"Entwicklungskarten gekauft: {bought}\nGespielt: {played}\n"
                                     f"Spielerhandel: {activity.player_trades} · Bank-/Hafenhandel: {activity.bank_trades}"
                                     f" · Angebote: {activity.offers}")
        self.final_awards.controls = []
        for label, holder, counts, unit in (
            ("Größte Rittermacht", sample.awards.largest_army, sample.awards.knights, "gespielte Ritter"),
            ("Längste Handelsstraße", sample.awards.longest_road, sample.awards.road_lengths, "Straßen"),
        ):
            description = "Noch nicht vergeben"
            if holder is not None:
                count = counts[s.game.state.colors.index(holder)]
                description = (COLOR_NAMES[holder] + (" · Du" if holder == s.human else "") +
                               f" · {count} {unit} · 2 Siegpunkte")
            self.final_awards.controls.append(ft.Text(f"{label}: {description}",
                                                      color=COLORS.get(holder, MUTED), size=12))
        self.final_scores.controls = [ft.Row([
            ft.Text(COLOR_NAMES[c] + (" · Du" if c == s.human else "") +
                    (" · Sieger" if c == sample.winner else ""), color=COLORS[c], expand=True,
                    weight=ft.FontWeight.BOLD if c == sample.winner else ft.FontWeight.NORMAL),
            ft.Text(f"{points} Siegpunkte", color=INK, size=12),
        ]) for c, points in zip(s.game.state.colors, sample.points)]
        self.final_render_key = render_key

    def render_history(self):
        store = self.history_store
        if store.total_boards == 0:
            self.history_empty.visible = True
            self.history_body.visible = False
            self.board_picker.value = None
            self.board_picker.options = []
            self.attempt_rows.controls = []
            self.review_canvas.shapes = []
            self.history_render_key = None
            return
        self.history_empty.visible = False
        self.history_body.visible = True
        sort_mode = self.board_sort.value if self.board_sort.value in BOARD_SORT_MODES else "best_win_rate"
        boards = store.sorted_boards(sort_mode)
        self.history_summary.value = (
            f"{store.total_boards} {'Brett' if store.total_boards == 1 else 'Bretter'} · "
            f"{store.total_attempts} {'Versuch' if store.total_attempts == 1 else 'Versuche'} · "
            "Gut > 50 %"
        )
        current_key = (self.session.seed, self.session.random_ports)
        self.board_picker.options = [
            ft.DropdownOption(
                f"{b.seed}:{int(b.random_ports)}",
                f"Brett {b.seed} ({'Zufallshäfen' if b.random_ports else 'Feste Häfen'}) · "
                f"Best {format_percent(b.best_win_rate)} · Gesamt {format_percent(b.overall_win_rate)} "
                f"({len(b.attempts)})" + (" · Aktuell" if b.key == current_key else ""),
            )
            for b in boards
        ]
        if self.history_board_key in store.boards:
            board = store.boards[self.history_board_key]
        elif current_key in store.boards:
            board = store.boards[current_key]
        else:
            board = boards[0]
        self.history_board_key = board.key
        self.board_picker.value = f"{board.seed}:{int(board.random_ports)}"
        self.current_board_btn.visible = current_key in store.boards and board.key != current_key
        ports_label = "Zufällige Häfen" if board.random_ports else "Feste Anordnung"
        self.board_stats_text.value = (
            f"Brett {board.seed} · {ports_label} · Bestwert: {format_percent(board.best_win_rate)} · "
            f"Gesamt: {format_percent(board.overall_win_rate)} ({board.overall_wins}/{board.overall_decided} Siege)"
        )
        attempts = board.sorted_attempts()
        selected = next((a for a in attempts if a.key == self.history_attempt_key), attempts[0])
        self.history_attempt_key = selected.key
        catan_map, colors = board_layout(board.seed, board.random_ports)
        self.attempt_rows.controls = []
        for rank, attempt in enumerate(attempts, 1):
            _, _, _, est_rounds = attempt_analysis(catan_map, attempt)
            n1, n2 = attempt.human_nodes
            is_selected = attempt.key == selected.key
            verdict_color = VERDICT_COLORS[attempt.verdict]
            limit_note = f" · {attempt.limited} am Limit" if attempt.limited else ""
            rounds_note = f" · ≈ {est_rounds} Runden" if est_rounds is not None else ""
            self.attempt_rows.controls.append(ft.Container(
                ft.Column([
                    ft.Row([
                        ft.Text(f"#{rank} · {format_percent(attempt.win_rate)} gewonnen",
                                color=verdict_color, size=14, weight=ft.FontWeight.BOLD, expand=True),
                        ft.Container(
                            ft.Text(VERDICT_SHORT[attempt.verdict], size=11, color=BACKGROUND,
                                    weight=ft.FontWeight.BOLD),
                            bgcolor=verdict_color,
                            padding=ft.Padding.symmetric(horizontal=8, vertical=3),
                            border_radius=6,
                        ),
                    ]),
                    ft.Text(
                        f"{attempt.wins} von {attempt.decided} Siegen{limit_note} · "
                        f"Startplatz {attempt.seat + 1} ({COLOR_NAMES[colors[attempt.seat]]}) · "
                        f"{DICE_MODES[attempt.dice_mode]}{rounds_note}",
                        size=11, color=MUTED,
                    ),
                    ft.Text(f"1. {describe_node(catan_map, n1)}\n2. {describe_node(catan_map, n2)}",
                            size=11, color=INK),
                ], spacing=4),
                padding=12,
                bgcolor="#213444" if is_selected else "#14222D",
                border=ft.Border.all(1.5, ACCENT if is_selected else "#273947"),
                border_radius=12,
                data=attempt.key,
                on_click=self.select_history_attempt,
            ))

        attempt_active = self.history_view_mode == "attempt"
        self.mode_attempt_btn.style = ft.ButtonStyle(
            bgcolor=ACCENT if attempt_active else "#14222D",
            color=BACKGROUND if attempt_active else INK,
        )
        self.mode_spots_btn.style = ft.ButtonStyle(
            bgcolor=ACCENT if not attempt_active else "#14222D",
            color=BACKGROUND if not attempt_active else INK,
        )
        canvas_width = max(212, self.width - 36)
        if attempt_active:
            production, starting_cards, _, est_rounds = attempt_analysis(catan_map, selected)
            rank_idx = attempts.index(selected) + 1
            self.review_title.value = (
                f"Versuch #{rank_idx} · {format_percent(selected.win_rate)} gewonnen "
                f"({VERDICT_SHORT[selected.verdict]})"
            )
            self.review_title.color = VERDICT_COLORS[selected.verdict]
            self.review_detail.value = (
                f"Startplatz {selected.seat + 1} ({COLOR_NAMES[colors[selected.seat]]}) · "
                f"{DICE_MODES[selected.dice_mode]}"
                + (f" · ≈ {est_rounds} Runden bis 10 SP" if est_rounds is not None else "")
            )
            self.review_production.visible = True
            self.review_production.controls = resource_chips(production)
            cards_text = ", ".join(f"{v} {RESOURCE_NAMES[r]}" for r, v in starting_cards.items() if v)
            self.review_cards.value = (f"Startkarten (2. Siedlung): {cards_text}"
                                       if cards_text else "Startkarten (2. Siedlung): keine")
            self.review_legend.value = "1 / 2 markiert deine erste und zweite Siedlung im 4-Spieler-Eröffnungsbild."
            render_key = ("attempt", board.key, selected.key, canvas_width, self.pips.value)
            if render_key != self.history_render_key:
                self.review_geometry = BoardGeometry(catan_map, canvas_width)
                self.review_canvas.width = self.review_geometry.width
                self.review_canvas.height = self.review_geometry.height
                self.review_canvas.shapes = attempt_review_shapes(
                    catan_map, opening_snapshot(catan_map, colors, selected),
                    selected.human_nodes, self.review_geometry, show_pips=self.pips.value,
                )
                self.history_render_key = render_key
        else:
            spots = store.spot_stats(board.seed, board.random_ports)
            decided_spots = [st for st in spots.values() if st.win_rate is not None]
            good_count = sum(st.verdict == "good" for st in spots.values())
            bad_count = sum(st.verdict == "bad" for st in spots.values())
            neutral_count = len(decided_spots) - good_count - bad_count
            self.review_title.value = f"Kreuzungs-Vergleich · {len(spots)} getestete Siedlungsplätze"
            self.review_title.color = INK
            self.review_detail.value = (
                f"{good_count} gut (> 50 %) · {neutral_count} mittel (25–50 %) · {bad_count} schlecht (< 25 %)"
            )
            self.review_production.visible = False
            self.review_production.controls = []
            if decided_spots:
                best_spot, worst_spot = decided_spots[0], decided_spots[-1]
                lines = [
                    f"Bester Platz: {format_percent(best_spot.win_rate)} ({best_spot.wins}/{best_spot.decided}) · "
                    f"{describe_node(catan_map, best_spot.node)}"
                ]
                if worst_spot.node != best_spot.node:
                    lines.append(
                        f"Schwächster Platz: {format_percent(worst_spot.win_rate)} "
                        f"({worst_spot.wins}/{worst_spot.decided}) · {describe_node(catan_map, worst_spot.node)}"
                    )
                self.review_cards.value = "\n".join(lines)
            else:
                self.review_cards.value = "Noch keine entschiedenen Partien auf diesen Kreuzungen."
            self.review_legend.value = (
                "Grün > 50 % (gut) · Gold 25–50 % (mittel) · Rot < 25 % (schlecht) · Ring: gewählter Versuch"
            )
            render_key = (
                "spots", board.key,
                tuple((st.node, st.wins, st.decided) for st in spots.values()),
                selected.human_nodes, canvas_width, self.pips.value,
            )
            if render_key != self.history_render_key:
                self.review_geometry = BoardGeometry(catan_map, canvas_width)
                self.review_canvas.width = self.review_geometry.width
                self.review_canvas.height = self.review_geometry.height
                self.review_canvas.shapes = spot_comparison_shapes(
                    catan_map, spots, self.review_geometry,
                    show_pips=self.pips.value, selected_nodes=selected.human_nodes,
                )
                self.history_render_key = render_key

    def change_board_sort(self, e):
        self.history_notice.visible = False
        self.render_history()
        self.page.update()

    def select_history_board(self, e):
        if not self.board_picker.value:
            return
        try:
            seed_part, ports_part = self.board_picker.value.split(":")
            key = (int(seed_part), bool(int(ports_part)))
        except ValueError:
            return
        if key in self.history_store.boards:
            self.history_board_key = key
            self.history_attempt_key = None
            self.history_notice.visible = False
            self.render_history()
            self.page.update()

    def focus_current_board(self, e):
        key = (self.session.seed, self.session.random_ports)
        if key in self.history_store.boards:
            self.history_board_key = key
            self.history_attempt_key = None
            self.history_notice.visible = False
            self.render_history()
            self.page.update()

    def select_history_attempt(self, e):
        self.history_attempt_key = e.control.data
        self.history_notice.visible = False
        self.render_history()
        self.page.update()

    def show_attempt_view(self, e):
        self.history_view_mode = "attempt"
        self.render_history()
        self.page.update()

    def show_spots_view(self, e):
        self.history_view_mode = "spots"
        self.render_history()
        self.page.update()

    async def play_history_board(self, e):
        if self.busy or self.history_board_key not in self.history_store.boards:
            return
        board = self.history_store.boards[self.history_board_key]
        attempts = board.sorted_attempts()
        selected = next((a for a in attempts if a.key == self.history_attempt_key), attempts[0])
        self.ports.value = "random" if board.random_ports else "fixed"
        await self.replace_session(board.seed, selected.seat)

    def load_history_attempt(self, e):
        if self.busy or self.history_board_key not in self.history_store.boards:
            return
        board = self.history_store.boards[self.history_board_key]
        attempts = board.sorted_attempts()
        selected = next((a for a in attempts if a.key == self.history_attempt_key), attempts[0])
        if self.session.results.decided:
            self.previous = ((self.session.seed, self.session.seat, self.session.random_ports, self.session.dice_mode),
                             self.session.results.wins[self.session.human], self.session.results.decided)
        self.session.close()
        self.session = reconstruct_session(board, selected)
        self.seed.value = str(board.seed)
        self.ports.value = "random" if board.random_ports else "fixed"
        self.geometry = BoardGeometry(self.session.game.state.board.map, self.width)
        self.progress.visible = self.progress_text.visible = False
        self.show_error()
        self.refresh()

    async def delete_history_attempt(self, e):
        if self.busy or self.history_board_key is None or self.history_attempt_key is None:
            return
        seed, random_ports = self.history_board_key
        if self.history_store.delete_attempt(seed, random_ports, self.history_attempt_key):
            self.history_attempt_key = None
            self.history_notice.value = "Versuch aus dem Verlauf gelöscht."
            self.history_notice.visible = True
            await self.save_history()
            self.refresh()

    async def export_history(self, e):
        sort_mode = self.board_sort.value if self.board_sort.value in BOARD_SORT_MODES else "best_win_rate"
        payload = self.history_store.to_export_json(sort_mode=sort_mode)
        self.last_exported_json = payload
        if self._has_page_services():
            try:
                saved = await self.file_picker.save_file(
                    dialog_title="Eröffnungsverlauf exportieren",
                    file_name="catan-eroeffnungen.json",
                    file_type=ft.FilePickerFileType.CUSTOM,
                    allowed_extensions=["json"],
                    src_bytes=payload.encode("utf-8"),
                )
                if saved is None and not getattr(self.page, "web", False):
                    self.history_notice.value = "Export abgebrochen."
                else:
                    self.history_notice.value = "JSON-Datei exportiert."
            except Exception:
                await self.clipboard.set(payload)
                self.history_notice.value = "Direktdownload nicht verfügbar – JSON in Zwischenablage kopiert."
        else:
            self.history_notice.value = "JSON-Export bereit."
        self.history_notice.visible = True
        self.page.update()

    async def copy_history(self, e):
        sort_mode = self.board_sort.value if self.board_sort.value in BOARD_SORT_MODES else "best_win_rate"
        payload = self.history_store.to_export_json(sort_mode=sort_mode)
        self.last_exported_json = payload
        if self._has_page_services():
            try:
                await self.clipboard.set(payload)
                self.history_notice.value = "JSON in Zwischenablage kopiert."
            except Exception as exc:
                self.history_notice.value = f"Zwischenablage nicht verfügbar: {exc}"
        else:
            self.history_notice.value = "JSON in Zwischenablage kopiert."
        self.history_notice.visible = True
        self.page.update()

    def toggle_pips(self, e):
        self.refresh()

    def select_sample(self, e):
        self.render_results()
        self.page.update()

    def change_dice_mode(self, e):
        if not self.busy and self.dice_mode.value != self.session.dice_mode:
            self.session.dice_mode = self.dice_mode.value
            self.previous = None
            self.progress.visible = self.progress_text.visible = False
            self.show_error()
        self.refresh()

    def tap(self, e):
        if self.busy or not self.session.human_turn or e.local_position is None:
            return
        hit = self.geometry.hit(e.local_position.x, e.local_position.y,
                                self.session.legal_nodes, self.session.legal_roads)
        if not hit:
            return
        self.show_error()
        if hit[0] == "node":
            self.session.select_node(hit[1])
        else:
            self.session.select_road(hit[1])
        self.refresh()

    async def advance(self):
        self.busy = True
        self.refresh()
        try:
            await self.session.advance_bots(self.refresh)
        except Exception as exc:
            self.show_error(f"Computerplatzierung fehlgeschlagen: {exc}")
        finally:
            self.busy = False
            self.refresh()

    async def commit(self, e):
        if self.busy:
            return
        try:
            self.session.commit()
            self.show_error()
            await self.advance()
        except ValueError as exc:
            self.show_error(str(exc))
            self.refresh()

    def undo(self, e):
        if not self.busy:
            self.session.undo()
            self.show_error()
            self.refresh()

    async def replace_session(self, seed=None, seat=None):
        if self.busy:
            return
        if self.session.results.decided:
            self.previous = ((self.session.seed, self.session.seat, self.session.random_ports, self.session.dice_mode),
                             self.session.results.wins[self.session.human], self.session.results.decided)
        self.session.close()
        self.session = OpeningSession(seed, seat, self.ports.value == "random", dice_mode=self.session.dice_mode)
        self.seed.value = str(self.session.seed)
        self.geometry = BoardGeometry(self.session.game.state.board.map, self.width)
        self.progress.visible = self.progress_text.visible = False
        self.show_error()
        await self.advance()

    async def new_game(self, e):
        seat = None if self.seat.value == "random" else int(self.seat.value)
        await self.replace_session(seat=seat)

    async def retry(self, e):
        # Retry the actual port setting/seat, even if settings for the next board changed.
        self.ports.value = "random" if self.session.random_ports else "fixed"
        await self.replace_session(self.session.seed, self.session.seat)

    async def load(self, e):
        try:
            seed = int(self.seed.value)
            if not 0 <= seed < 2**63:
                raise ValueError
            seat = None if self.seat.value == "random" else int(self.seat.value)
            await self.replace_session(seed, seat)
        except ValueError:
            self.show_error("Der Brett-Code muss eine ganze Zahl zwischen 0 und 9223372036854775807 sein.")
            self.refresh()

    def quick_count(self, e):
        if not self.busy:
            self.count.value = str(e.control.data)
            self.page.update()

    def stop(self, e):
        self.session.cancel()
        self.progress_text.value = "Wird gestoppt …"
        self.page.update()

    async def simulate(self, e):
        if self.busy:
            return
        try:
            count = int(self.count.value)
            if not 1 <= count <= MAX_SIMULATIONS:
                raise ValueError
        except (ValueError, TypeError):
            self.show_error(f"Wähle 1 bis {MAX_SIMULATIONS} Simulationen.")
            self.refresh()
            return
        self.show_error()
        existing = self.history_store.matching_attempt(self.session)
        self.session.initial_sample_index = existing.next_index if existing else 0
        existing_indices = {sample.index for sample in self.session.results.samples}
        self.busy = True
        self.progress.visible = self.progress_text.visible = True
        self.progress.value = 0
        self.progress_text.value = f"Partie 1 von {count} …"
        self.refresh()
        rendered_count = len(self.session.results.samples)
        def progress(done, target, turns):
            nonlocal rendered_count
            self.progress.value = done / target
            self.progress_text.value = (f"{done} von {target} Partien fertig" if not turns else
                                        f"{done} von {target} Partien fertig · Zug {turns}")
            if len(self.session.results.samples) != rendered_count:
                self.render_results()
                rendered_count = len(self.session.results.samples)
            self.page.update()
        try:
            await self.session.simulate(count, progress)
            if self.session.cancelled:
                self.progress_text.value = "Gestoppt. Abgeschlossene Partien bleiben erhalten."
            else:
                self.progress_text.value = f"Fertig · {len(self.session.results.samples)} Partien insgesamt"
        except Exception as exc:
            self.show_error(f"Simulation fehlgeschlagen: {exc}")
            self.progress_text.value = "Berechnung angehalten."
        finally:
            new_samples = [sample for sample in self.session.results.samples
                           if sample.index not in existing_indices]
            if new_samples:
                recorded = self.history_store.record_samples(self.session, new_samples)
                if recorded is not None:
                    self.history_board_key = (self.session.seed, self.session.random_ports)
                    self.history_attempt_key = recorded.key
                    self.history_notice.visible = False
                    await self.save_history()
            self.busy = False
            self.refresh()


async def main(page: ft.Page):
    app = TrainerApp(page)
    await app.start()


if __name__ == "__main__":
    ft.run(main)

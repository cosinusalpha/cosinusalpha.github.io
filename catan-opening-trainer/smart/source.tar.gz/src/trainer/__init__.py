"""Opening practice, independent of the Flet presentation layer."""

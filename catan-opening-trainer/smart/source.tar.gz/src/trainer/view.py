"""Flet canvas presentation; all coordinates come from the engine's node IDs."""

import flet as ft
import flet.canvas as cv

from catanatron.models.enums import CITY, NodeRef
from catanatron.models.player import Color
from trainer.board import BoardGeometry
from trainer.engine import BoardSnapshot

BACKGROUND = "#101923"
PANEL = "#192632"
MUTED = "#A9BAC8"
INK = "#F4F6F8"
ACCENT = "#F3C56B"
COLORS = {Color.RED: "#F17F77", Color.BLUE: "#77B9F5", Color.ORANGE: "#F2B668", Color.WHITE: "#F1F3F5"}
TERRAINS = {"WOOD": "#386950", "BRICK": "#98634F", "SHEEP": "#739764", "WHEAT": "#BBA261", "ORE": "#718495", None: "#BCAA83"}
LABELS = {"WOOD": "Holz", "BRICK": "Lehm", "SHEEP": "Wolle", "WHEAT": "Getreide", "ORE": "Erz", None: "Wüste"}
SHORT = {"WOOD": "H", "BRICK": "L", "SHEEP": "W", "WHEAT": "G", "ORE": "E"}


def polygon(points, color, stroke=False, width=1):
    elements = [cv.Path.MoveTo(*points[0])]
    elements += [cv.Path.LineTo(*p) for p in points[1:]]
    elements.append(cv.Path.Close())
    return cv.Path(elements, ft.Paint(color=color, stroke_width=width,
                                      style=ft.PaintingStyle.STROKE if stroke else ft.PaintingStyle.FILL))


def house(x, y, size, color):
    return polygon([(x - size, y + size * .7), (x + size, y + size * .7),
                    (x + size, y - size * .3), (x, y - size),
                    (x - size, y - size * .3)], color)


def board_shapes(catan_map, board: BoardSnapshot, geometry, show_pips=True):
    """Draw a board without placement interactions, for openings or final results."""
    shapes = []
    radius = geometry.radius
    font = max(8, radius * .23)
    for coord, tile in catan_map.land_tiles.items():
        x, y = geometry.centers[coord]
        points = [geometry.nodes[tile.nodes[ref]] for ref in NodeRef]
        shapes.append(polygon(points, TERRAINS[tile.resource]))
        shapes.append(polygon(points, BACKGROUND, stroke=True, width=max(1.4, radius * .025)))
        shapes.append(cv.Text(x, y - radius * .40, LABELS[tile.resource],
                              style=ft.TextStyle(size=font, color="#FFFFFF", weight=ft.FontWeight.W_500),
                              alignment=ft.Alignment.CENTER))
        if tile.number is not None:
            shapes.append(cv.Circle(x, y + radius * .08, radius * .28, ft.Paint(color="#F2E8CE")))
            red = tile.number in (6, 8)
            shapes.append(cv.Text(x, y + radius * .06, str(tile.number),
                                  style=ft.TextStyle(size=radius * .36, color="#B43C32" if red else "#203039",
                                                     weight=ft.FontWeight.BOLD),
                                  alignment=ft.Alignment.CENTER))
            if show_pips:
                pips = 6 - abs(7 - tile.number)
                shapes.append(cv.Text(x, y + radius * .46, "·" * pips,
                                      style=ft.TextStyle(size=radius * .33, color="#FFF4D8"),
                                      alignment=ft.Alignment.CENTER))
        if coord == board.robber_coordinate and tile.number is None:
            shapes.append(cv.Text(x, y + radius * .15, "Räuber",
                                  style=ft.TextStyle(size=font, color="#2A3234"), alignment=ft.Alignment.CENTER))
        elif coord == board.robber_coordinate:
            rx, ry = x + radius * .54, y + radius * .05
            shapes.append(cv.Circle(rx, ry, radius * .16, ft.Paint(color=BACKGROUND)))
            shapes.append(cv.Text(rx, ry, "R", style=ft.TextStyle(size=font, color=INK,
                                                               weight=ft.FontWeight.BOLD),
                                  alignment=ft.Alignment.CENTER))
    for resource, nodes, (px, py) in geometry.ports:
        for n in nodes:
            x, y = geometry.nodes[n]
            shapes.append(cv.Line(x, y, px, py, ft.Paint(color="#78949F", stroke_width=1.5)))
        shapes.append(cv.Circle(px, py, radius * .29, ft.Paint(color="#263E4D")))
        shapes.append(cv.Text(px, py, "3:1" if resource is None else f"{SHORT[resource]} 2:1",
                              style=ft.TextStyle(size=font, color=INK, weight=ft.FontWeight.BOLD),
                              alignment=ft.Alignment.CENTER))
    for edge, color in board.roads:
        ax, ay = geometry.nodes[edge[0]]
        bx, by = geometry.nodes[edge[1]]
        shapes.append(cv.Line(ax, ay, bx, by, ft.Paint(color="#0C1620", stroke_width=radius * .19,
                                                     stroke_cap=ft.StrokeCap.ROUND)))
        shapes.append(cv.Line(ax, ay, bx, by, ft.Paint(color=COLORS[color], stroke_width=radius * .11,
                                                     stroke_cap=ft.StrokeCap.ROUND)))
    for node, (color, kind) in board.buildings:
        x, y = geometry.nodes[node]
        shapes.append(house(x, y, radius * .23, "#101923"))
        shapes.append(house(x, y, radius * .18, COLORS[color]))
        if kind == CITY:
            shapes.append(cv.Circle(x, y, radius * .06, ft.Paint(color="#1B2A34")))
    return shapes


def opening_shapes(session, geometry, show_targets=True, show_pips=True, show_node_pips=False):
    shapes = board_shapes(session.game.state.board.map,
                          BoardSnapshot.from_board(session.game.state.board), geometry, show_pips)
    radius = geometry.radius
    if show_targets and not show_node_pips:
        for n in session.legal_nodes:
            x, y = geometry.nodes[n]
            shapes.append(cv.Circle(x, y, max(4, radius * .13), ft.Paint(color="#E9F3EE")))
            shapes.append(cv.Circle(x, y, max(4, radius * .13),
                                    ft.Paint(color="#233943", style=ft.PaintingStyle.STROKE, stroke_width=1.3)))
    if session.selected_node is not None:
        x, y = geometry.nodes[session.selected_node]
        shapes.append(cv.Circle(x, y, radius * .33, ft.Paint(color=ACCENT, style=ft.PaintingStyle.STROKE, stroke_width=2)))
        if not show_node_pips:
            shapes.append(house(x, y, radius * .20, COLORS[session.human]))
        if show_targets:
            for edge in session.legal_roads:
                ax, ay = geometry.nodes[edge[0]]
                bx, by = geometry.nodes[edge[1]]
                selected = edge == session.selected_edge
                shapes.append(cv.Line(ax, ay, bx, by, ft.Paint(color=ACCENT if selected else "#E9EDDA",
                                                             stroke_width=radius * (.12 if selected else .055),
                                                             stroke_cap=ft.StrokeCap.ROUND)))
                mx, my = geometry.midpoint(edge)
                shapes.append(cv.Circle(mx, my, radius * .18, ft.Paint(color=ACCENT if selected else "#1B3342")))
                shapes.append(cv.Circle(mx, my, radius * .18,
                                        ft.Paint(color=ACCENT, style=ft.PaintingStyle.STROKE, stroke_width=1.5)))
    if show_targets and show_node_pips:
        for node in session.legal_nodes:
            x, y = geometry.nodes[node]
            selected = node == session.selected_node
            total = sum(6 - abs(7 - tile.number) for tile in session.game.state.board.map.adjacent_tiles[node]
                        if tile.resource is not None)
            size = max(8, radius * .20)
            shapes.append(cv.Circle(x, y, size, ft.Paint(color=ACCENT if selected else "#E9F3EE")))
            shapes.append(cv.Circle(x, y, size, ft.Paint(color="#233943", style=ft.PaintingStyle.STROKE,
                                                         stroke_width=1.3)))
            shapes.append(cv.Text(x, y, str(total), style=ft.TextStyle(size=max(10, radius * .23),
                                  color=BACKGROUND, weight=ft.FontWeight.BOLD), alignment=ft.Alignment.CENTER))
    return shapes


def resource_chips(production):
    return [ft.Container(ft.Text(f"{LABELS[r]}  {value}", size=12, color=INK),
                         bgcolor=TERRAINS[r], padding=ft.Padding.symmetric(horizontal=10, vertical=6), border_radius=8)
            for r, value in production.items()]

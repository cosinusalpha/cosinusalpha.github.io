"""Cooperative Catanatron AlphaBeta search for the single-threaded browser."""

import asyncio
import random
import time
from typing import Callable

from catanatron import Game
from catanatron.models.enums import Action
from catanatron.players.minimax import MAX_SEARCH_TIME_SECS
from catanatron.players.tree_search_utils import execute_spectrum
from catanatron.players.value import get_value_fn


async def decide_cooperatively(game: Game, should_stop: Callable[[], bool] | None = None) -> Action | None:
    """Use AlphaBeta's action order, chance probabilities, evaluator and cutoffs.

    Yield during the search and omit the unused debug tree. Hypothetical moves
    use an isolated RNG, so searching never advances the real game's stream.
    """
    player = game.state.current_player()
    actions = player.get_actions(game)
    if should_stop and should_stop():
        return None
    if len(actions) == 1:
        return actions[0]
    value_fn = get_value_fn(player.value_fn_builder_name, player.params.weights)
    last_yield = time.perf_counter()
    deadline = last_yield + MAX_SEARCH_TIME_SECS

    async def search(node, depth, alpha, beta):
        nonlocal last_yield
        if time.perf_counter() - last_yield >= 0.012:
            await asyncio.sleep(0.001)
            last_yield = time.perf_counter()
        if should_stop and should_stop():
            return None, 0.0
        if depth == 0 or node.winning_color() is not None or time.perf_counter() >= deadline:
            return None, value_fn(node, player.color)
        maximizing = node.state.current_color() == player.color
        best_action = None
        best_value = float("-inf") if maximizing else float("inf")
        for action in player.get_actions(node):
            expected_value = 0.0
            for outcome, probability in execute_spectrum(node, action):
                _, value = await search(outcome, depth - 1, alpha, beta)
                if should_stop and should_stop():
                    return None, 0.0
                expected_value += probability * value
            if (maximizing and expected_value > best_value) or (not maximizing and expected_value < best_value):
                best_action, best_value = action, expected_value
            if maximizing:
                alpha = max(alpha, best_value)
            else:
                beta = min(beta, best_value)
            if alpha >= beta:
                break
        return best_action, best_value

    root = game.copy()
    root.random = random.Random()
    root.random.setstate(game.state.random.getstate())
    root.state.random = root.random
    action, _ = await search(root, player.params.depth, float("-inf"), float("inf"))
    if should_stop and should_stop():
        return None
    return action if action is not None else actions[0]

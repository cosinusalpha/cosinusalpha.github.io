"""Persistent per-board opening history, win-rate ranking, spot analysis, and JSON export."""

from __future__ import annotations

import copy
from datetime import datetime, timezone
from dataclasses import dataclass, field
from functools import lru_cache
import json
import math
from typing import Literal

from catanatron.models.enums import Action, ActionType, RESOURCES, SETTLEMENT
from catanatron.models.map import PORT_DIRECTION_TO_NODEREFS
from catanatron.models.player import Color
from trainer.engine import (
    BoardSnapshot, COLOR_NAMES, create_game, DICE_MODES, DiceMode, OpeningSession, RESOURCE_NAMES, Sample,
)
from trainer.forecast import opening_trade_ratios, resource_budget_rounds

STORAGE_KEY = "catan_opening_trainer.history.v1"
SCHEMA_VERSION = 1
MAX_STORED_SAMPLES_PER_ATTEMPT = 24
SNAKE_SEATS = (0, 1, 2, 3, 3, 2, 1, 0)
PORT_SHORT = {"WOOD": "H", "BRICK": "L", "SHEEP": "W", "WHEAT": "G", "ORE": "E"}

Verdict = Literal["good", "neutral", "bad", "unrated"]
BoardSortMode = Literal["best_win_rate", "overall_win_rate", "recent"]

BOARD_SORT_MODES: dict[BoardSortMode, str] = {
    "best_win_rate": "Beste Siegquote (% gewonnen)",
    "overall_win_rate": "Gesamt-Siegquote (% gewonnen)",
    "recent": "Zuletzt gespielt",
}

VERDICT_LABELS: dict[Verdict, str] = {
    "good": "Gut (> 50 %)",
    "neutral": "Mittel (25–50 %)",
    "bad": "Schlecht (< 25 %)",
    "unrated": "Ohne Sieger",
}

VERDICT_SHORT: dict[Verdict, str] = {
    "good": "Gut",
    "neutral": "Mittel",
    "bad": "Schlecht",
    "unrated": "Limit",
}


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def classify_win_rate(win_rate: float | None) -> Verdict:
    """Classify win rate: strictly > 50% is good, 25%–50% neutral, < 25% bad."""
    if win_rate is None:
        return "unrated"
    if win_rate > 0.50:
        return "good"
    if win_rate >= 0.25:
        return "neutral"
    return "bad"


def format_percent(win_rate: float | None) -> str:
    if win_rate is None:
        return "— %"
    pct = round(win_rate * 100.0, 1)
    return f"{int(pct)} %" if pct.is_integer() else f"{pct:.1f} %"


@lru_cache(maxsize=64)
def board_layout(seed: int, random_ports: bool):
    game, _, _, _ = create_game(seed, seat=0, random_ports=random_ports)
    return game.state.board.map, tuple(game.state.colors)


def node_port_label(catan_map, node: int) -> str | None:
    for port in catan_map.ports_by_id.values():
        endpoints = {port.nodes[ref] for ref in PORT_DIRECTION_TO_NODEREFS[port.direction]}
        if node in endpoints:
            return "3:1" if port.resource is None else f"{PORT_SHORT[port.resource]} 2:1"
    return None


def describe_node(catan_map, node: int) -> str:
    tiles = [tile for tile in catan_map.adjacent_tiles[node] if tile.resource is not None]
    tiles.sort(key=lambda t: (6 - abs(7 - t.number), t.number or 0, t.resource or ""), reverse=True)
    pips = sum(6 - abs(7 - tile.number) for tile in tiles)
    parts = [f"{tile.number} {RESOURCE_NAMES[tile.resource]}" for tile in tiles] or ["Wüste"]
    port = node_port_label(catan_map, node)
    meta = f"{pips} Pkt" + (f" · {port}" if port else "")
    return f"{', '.join(parts)} ({meta})"


@dataclass
class AttemptRecord:
    seat: int
    dice_mode: DiceMode
    opening_placements: tuple[tuple[int, tuple[int, int]], ...]
    wins_by_seat: tuple[int, int, int, int] = (0, 0, 0, 0)
    decided: int = 0
    limited: int = 0
    next_index: int = 0
    updated_at: str = ""
    samples: list[Sample] = field(default_factory=list)

    @property
    def key(self):
        return (self.seat, self.dice_mode, self.opening_placements)

    @property
    def human_placements(self) -> tuple[tuple[int, tuple[int, int]], tuple[int, tuple[int, int]]]:
        return (self.opening_placements[self.seat], self.opening_placements[7 - self.seat])

    @property
    def human_nodes(self) -> tuple[int, int]:
        return (self.opening_placements[self.seat][0], self.opening_placements[7 - self.seat][0])

    @property
    def wins(self) -> int:
        return self.wins_by_seat[self.seat]

    @property
    def total_games(self) -> int:
        return self.decided + self.limited

    @property
    def win_rate(self) -> float | None:
        return self.wins / self.decided if self.decided > 0 else None

    @property
    def win_percent(self) -> float | None:
        return round(100.0 * self.wins / self.decided, 1) if self.decided > 0 else None

    @property
    def verdict(self) -> Verdict:
        return classify_win_rate(self.win_rate)

    def sort_key(self):
        return (
            self.decided > 0,
            self.win_rate if self.win_rate is not None else -1.0,
            self.decided,
            self.wins,
            self.updated_at,
        )

    def to_storage_dict(self) -> dict:
        colors = tuple(Color)
        return {
            "seat": self.seat,
            "dice_mode": self.dice_mode,
            "placements": [[node, [edge[0], edge[1]]] for node, edge in self.opening_placements],
            "wins": list(self.wins_by_seat),
            "decided": self.decided,
            "limited": self.limited,
            "next_index": self.next_index,
            "updated_at": self.updated_at,
            "samples": [s.to_storage_dict(colors) for s in self.samples[-MAX_STORED_SAMPLES_PER_ATTEMPT:]],
        }

    @classmethod
    def from_storage_dict(cls, data: dict) -> AttemptRecord:
        seat = int(data["seat"])
        dice_mode = data["dice_mode"]
        if seat not in range(4) or dice_mode not in DICE_MODES:
            raise ValueError("Invalid seat or dice mode")
        raw_placements = data["placements"] if "placements" in data else data["opening_placements"]
        if not isinstance(raw_placements, list) or len(raw_placements) != 8:
            raise ValueError("Invalid opening placements")
        placements = []
        for item in raw_placements:
            node, edge = item
            a, b = sorted((int(edge[0]), int(edge[1])))
            placements.append((int(node), (a, b)))
        raw_wins = data["wins_by_seat"] if isinstance(data.get("wins_by_seat"), list) else data["wins"]
        wins = tuple(int(v) for v in raw_wins)
        if len(wins) != 4 or any(v < 0 for v in wins):
            raise ValueError("Invalid wins_by_seat")
        decided = int(data["decided"])
        limited = int(data.get("limited", 0))
        next_index = int(data.get("next_index", decided + limited))
        if decided < 0 or limited < 0 or next_index < 0:
            raise ValueError("Negative counts")
        colors = tuple(Color)
        samples = []
        raw_samples = data.get("samples", [])
        if isinstance(raw_samples, list):
            for raw_sample in raw_samples:
                try:
                    samples.append(Sample.from_storage_dict(raw_sample, colors))
                except (KeyError, TypeError, ValueError, IndexError):
                    continue
        samples.sort(key=lambda s: s.index)
        samples = samples[-MAX_STORED_SAMPLES_PER_ATTEMPT:]
        return cls(
            seat=seat,
            dice_mode=dice_mode,
            opening_placements=tuple(placements),
            wins_by_seat=wins,
            decided=decided,
            limited=limited,
            next_index=next_index,
            updated_at=str(data.get("updated_at", "")),
            samples=samples,
        )


@dataclass(frozen=True)
class SpotStat:
    node: int
    attempts: int
    wins: int
    decided: int
    limited: int = 0

    @property
    def win_rate(self) -> float | None:
        return self.wins / self.decided if self.decided > 0 else None

    @property
    def win_percent(self) -> float | None:
        return round(100.0 * self.wins / self.decided, 1) if self.decided > 0 else None

    @property
    def verdict(self) -> Verdict:
        return classify_win_rate(self.win_rate)

    def sort_key(self):
        return (
            self.decided > 0,
            self.win_rate if self.win_rate is not None else -1.0,
            self.decided,
            self.wins,
            -self.node,
        )


@dataclass
class BoardRecord:
    seed: int
    random_ports: bool
    attempts: list[AttemptRecord] = field(default_factory=list)
    updated_at: str = ""

    @property
    def key(self) -> tuple[int, bool]:
        return (self.seed, self.random_ports)

    def sorted_attempts(self) -> list[AttemptRecord]:
        return sorted(self.attempts, key=lambda a: a.sort_key(), reverse=True)

    @property
    def best_attempt(self) -> AttemptRecord | None:
        ordered = self.sorted_attempts()
        return ordered[0] if ordered else None

    @property
    def best_win_rate(self) -> float | None:
        best = self.best_attempt
        return best.win_rate if best else None

    @property
    def overall_wins(self) -> int:
        return sum(a.wins for a in self.attempts)

    @property
    def overall_decided(self) -> int:
        return sum(a.decided for a in self.attempts)

    @property
    def overall_limited(self) -> int:
        return sum(a.limited for a in self.attempts)

    @property
    def overall_win_rate(self) -> float | None:
        return self.overall_wins / self.overall_decided if self.overall_decided > 0 else None

    def sort_key(self, mode: BoardSortMode = "best_win_rate"):
        if mode == "recent":
            return (self.updated_at, self.best_win_rate if self.best_win_rate is not None else -1.0, self.overall_decided)
        rate = self.overall_win_rate if mode == "overall_win_rate" else self.best_win_rate
        return (
            rate is not None,
            rate if rate is not None else -1.0,
            self.overall_decided,
            self.overall_wins,
            self.updated_at,
        )

    def to_storage_dict(self) -> dict:
        return {
            "seed": self.seed,
            "random_ports": self.random_ports,
            "updated_at": self.updated_at,
            "attempts": [a.to_storage_dict() for a in self.sorted_attempts()],
        }

    @classmethod
    def from_storage_dict(cls, data: dict) -> BoardRecord:
        seed = int(data["seed"])
        if not 0 <= seed < 2**63:
            raise ValueError("Invalid board seed")
        random_ports = bool(data.get("random_ports", False))
        attempts = []
        for raw_attempt in data.get("attempts", []):
            try:
                attempts.append(AttemptRecord.from_storage_dict(raw_attempt))
            except (KeyError, TypeError, ValueError):
                continue
        if not attempts:
            raise ValueError("Board has no valid attempts")
        record = cls(seed=seed, random_ports=random_ports, attempts=attempts,
                     updated_at=str(data.get("updated_at", "")))
        record.attempts = record.sorted_attempts()
        return record


def opening_snapshot(catan_map, colors, attempt: AttemptRecord) -> BoardSnapshot:
    roads = tuple(sorted((tuple(sorted(edge)), colors[seat])
                         for seat, (_, edge) in zip(SNAKE_SEATS, attempt.opening_placements)))
    buildings = tuple(sorted((node, (colors[seat], SETTLEMENT))
                             for seat, (node, _) in zip(SNAKE_SEATS, attempt.opening_placements)))
    desert = next(coord for coord, tile in catan_map.land_tiles.items() if tile.resource is None)
    return BoardSnapshot(roads, buildings, tuple(desert))


def attempt_analysis(catan_map, attempt: AttemptRecord):
    nodes = attempt.human_nodes
    production = dict.fromkeys(RESOURCES, 0)
    for node in nodes:
        for tile in catan_map.adjacent_tiles[node]:
            if tile.resource is not None:
                production[tile.resource] += 6 - abs(7 - tile.number)
    starting_cards = dict.fromkeys(RESOURCES, 0)
    for tile in catan_map.adjacent_tiles[nodes[1]]:
        if tile.resource is not None:
            starting_cards[tile.resource] += 1
    rounds = resource_budget_rounds(production, starting_cards, opening_trade_ratios(catan_map, nodes))
    estimated = None if math.isinf(rounds) else int(math.ceil(rounds - 1e-9))
    return production, starting_cards, rounds, estimated


def reconstruct_session(board: BoardRecord, attempt: AttemptRecord) -> OpeningSession:
    session = OpeningSession(board.seed, attempt.seat, board.random_ports, dice_mode=attempt.dice_mode)
    for step, (node, edge) in enumerate(attempt.opening_placements):
        if step in (attempt.seat, 7 - attempt.seat):
            session.history.append(copy.deepcopy(session.game))
        color = session.game.state.current_color()
        session.game.execute(Action(color, ActionType.BUILD_SETTLEMENT, node))
        session.game.execute(Action(color, ActionType.BUILD_ROAD, tuple(sorted(edge))))
    session.initial_sample_index = attempt.next_index
    return session


class HistoryStore:
    def __init__(self, boards: dict[tuple[int, bool], BoardRecord] | None = None):
        self.boards: dict[tuple[int, bool], BoardRecord] = dict(boards or {})

    @property
    def total_boards(self) -> int:
        return len(self.boards)

    @property
    def total_attempts(self) -> int:
        return sum(len(b.attempts) for b in self.boards.values())

    def get_board(self, seed: int, random_ports: bool) -> BoardRecord | None:
        return self.boards.get((seed, random_ports))

    def sorted_boards(self, mode: BoardSortMode = "best_win_rate") -> list[BoardRecord]:
        if mode not in BOARD_SORT_MODES:
            raise ValueError("Unbekannte Sortierung.")
        return sorted(self.boards.values(), key=lambda b: b.sort_key(mode), reverse=True)

    def matching_attempt(self, session: OpeningSession) -> AttemptRecord | None:
        if not session.complete:
            return None
        board = self.boards.get((session.seed, session.random_ports))
        if not board:
            return None
        target = (session.seat, session.dice_mode, session.opening_placements())
        return next((attempt for attempt in board.attempts if attempt.key == target), None)

    def record_samples(self, session: OpeningSession, new_samples: list[Sample],
                       now: str | None = None) -> AttemptRecord | None:
        if not session.complete or not new_samples:
            return None
        timestamp = now or utc_now_iso()
        placements = session.opening_placements()
        board_key = (session.seed, session.random_ports)
        board = self.boards.get(board_key)
        if board is None:
            board = BoardRecord(seed=session.seed, random_ports=session.random_ports, updated_at=timestamp)
            self.boards[board_key] = board

        colors = session.game.state.colors
        delta_wins = [0, 0, 0, 0]
        delta_decided = 0
        delta_limited = 0
        max_next_index = 0
        for sample in new_samples:
            max_next_index = max(max_next_index, sample.index + 1)
            if sample.winner is None:
                delta_limited += 1
            else:
                delta_decided += 1
                delta_wins[colors.index(sample.winner)] += 1

        target_key = (session.seat, session.dice_mode, placements)
        attempt = next((item for item in board.attempts if item.key == target_key), None)
        if attempt is None:
            attempt = AttemptRecord(
                seat=session.seat,
                dice_mode=session.dice_mode,
                opening_placements=placements,
                wins_by_seat=tuple(delta_wins),
                decided=delta_decided,
                limited=delta_limited,
                next_index=max_next_index,
                updated_at=timestamp,
            )
            board.attempts.append(attempt)
        else:
            attempt.wins_by_seat = tuple(a + b for a, b in zip(attempt.wins_by_seat, delta_wins))
            attempt.decided += delta_decided
            attempt.limited += delta_limited
            attempt.next_index = max(attempt.next_index, max_next_index)
            attempt.updated_at = timestamp

        merged_samples = {sample.index: sample for sample in attempt.samples}
        for sample in new_samples:
            merged_samples[sample.index] = sample
        attempt.samples = [merged_samples[idx] for idx in sorted(merged_samples)[-MAX_STORED_SAMPLES_PER_ATTEMPT:]]

        board.updated_at = timestamp
        board.attempts = board.sorted_attempts()
        return attempt

    def delete_attempt(self, seed: int, random_ports: bool, attempt_key) -> bool:
        board_key = (seed, random_ports)
        board = self.boards.get(board_key)
        if not board:
            return False
        before = len(board.attempts)
        board.attempts = [a for a in board.attempts if a.key != attempt_key]
        if len(board.attempts) == before:
            return False
        if not board.attempts:
            del self.boards[board_key]
        else:
            board.attempts = board.sorted_attempts()
            board.updated_at = max((a.updated_at for a in board.attempts), default=board.updated_at)
        return True

    def spot_stats(self, seed: int, random_ports: bool, seat: int | None = None) -> dict[int, SpotStat]:
        board = self.boards.get((seed, random_ports))
        if not board:
            return {}
        buckets: dict[int, list[int]] = {}
        for attempt in board.attempts:
            if seat is not None and attempt.seat != seat:
                continue
            for node in attempt.human_nodes:
                counts = buckets.setdefault(node, [0, 0, 0, 0])
                counts[0] += 1
                counts[1] += attempt.wins
                counts[2] += attempt.decided
                counts[3] += attempt.limited
        stats = [SpotStat(node=node, attempts=c[0], wins=c[1], decided=c[2], limited=c[3])
                 for node, c in buckets.items()]
        stats.sort(key=lambda s: s.sort_key(), reverse=True)
        return {stat.node: stat for stat in stats}

    def to_storage_json(self) -> str:
        payload = {
            "version": SCHEMA_VERSION,
            "boards": [board.to_storage_dict() for board in self.sorted_boards("recent")],
        }
        return json.dumps(payload, separators=(",", ":"))

    def merge_import_json(self, raw: str) -> tuple[int, int]:
        """Merge boards and attempts from storage or export JSON; return (added, updated) attempts."""
        if not raw or not isinstance(raw, str):
            raise ValueError("Kein JSON-Text zum Importieren vorhanden.")
        try:
            data = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise ValueError("Ungültiges JSON-Format.") from exc
        if not isinstance(data, dict) or not isinstance(data.get("boards"), list):
            raise ValueError("JSON enthält keine gültigen Verlaufs-Boards.")
        imported_boards: list[BoardRecord] = []
        for raw_board in data["boards"]:
            if not isinstance(raw_board, dict):
                continue
            try:
                imported_boards.append(BoardRecord.from_storage_dict(raw_board))
            except (KeyError, TypeError, ValueError):
                continue
        if not imported_boards:
            raise ValueError("Keine importierbaren Verlaufs-Einträge im JSON gefunden.")
        added = 0
        updated = 0
        for incoming_board in imported_boards:
            target = self.boards.get(incoming_board.key)
            if target is None:
                self.boards[incoming_board.key] = incoming_board
                added += len(incoming_board.attempts)
                continue
            existing_by_key = {a.key: a for a in target.attempts}
            for inc in incoming_board.attempts:
                cur = existing_by_key.get(inc.key)
                if cur is None:
                    target.attempts.append(inc)
                    existing_by_key[inc.key] = inc
                    added += 1
                    continue
                merged_samples = {s.index: s for s in cur.samples}
                before_sample_keys = set(merged_samples)
                inc_rank = (inc.decided + inc.limited, inc.next_index, inc.updated_at)
                cur_rank = (cur.decided + cur.limited, cur.next_index, cur.updated_at)
                for sample in inc.samples:
                    if inc_rank > cur_rank or sample.index not in merged_samples:
                        merged_samples[sample.index] = sample
                changed = set(merged_samples) != before_sample_keys
                if inc_rank > cur_rank:
                    cur.wins_by_seat = inc.wins_by_seat
                    cur.decided = inc.decided
                    cur.limited = inc.limited
                    cur.next_index = inc.next_index
                    cur.updated_at = inc.updated_at
                    changed = True
                cur.samples = [merged_samples[idx] for idx in sorted(merged_samples)[-MAX_STORED_SAMPLES_PER_ATTEMPT:]]
                if changed:
                    updated += 1
            target.attempts = target.sorted_attempts()
            target.updated_at = max((a.updated_at for a in target.attempts), default=target.updated_at)
        return added, updated

    @classmethod
    def from_storage_json(cls, raw: str | None) -> HistoryStore:
        if not raw or not isinstance(raw, str):
            return cls()
        try:
            data = json.loads(raw)
            if not isinstance(data, dict):
                return cls()
            boards = {}
            for raw_board in data.get("boards", []):
                try:
                    board = BoardRecord.from_storage_dict(raw_board)
                    boards[board.key] = board
                except (KeyError, TypeError, ValueError):
                    continue
            return cls(boards)
        except (json.JSONDecodeError, TypeError, ValueError):
            return cls()

    def to_export_json(self, sort_mode: BoardSortMode = "best_win_rate", exported_at: str | None = None) -> str:
        ordered_boards = self.sorted_boards(sort_mode)
        total_wins = sum(b.overall_wins for b in ordered_boards)
        total_decided = sum(b.overall_decided for b in ordered_boards)
        total_limited = sum(b.overall_limited for b in ordered_boards)
        exported_boards = []
        for board in ordered_boards:
            catan_map, colors = board_layout(board.seed, board.random_ports)
            tiles = [
                {
                    "id": tile_id,
                    "coord": list(coord),
                    "resource": tile.resource,
                    "resource_label": "Wüste" if tile.resource is None else RESOURCE_NAMES[tile.resource],
                    "number": tile.number,
                }
                for coord, tile in sorted(catan_map.land_tiles.items(), key=lambda item: item[1].id)
                for tile_id in (tile.id,)
            ]
            ports = [
                {
                    "id": port.id,
                    "resource": port.resource,
                    "label": "3:1" if port.resource is None else f"{PORT_SHORT[port.resource]} 2:1",
                    "nodes": sorted(port.nodes[ref] for ref in PORT_DIRECTION_TO_NODEREFS[port.direction]),
                }
                for port in sorted(catan_map.ports_by_id.values(), key=lambda p: p.id)
            ]
            spots = [
                {
                    "node": stat.node,
                    "description": describe_node(catan_map, stat.node),
                    "attempts": stat.attempts,
                    "wins": stat.wins,
                    "decided": stat.decided,
                    "limited": stat.limited,
                    "win_percent": stat.win_percent,
                    "verdict": stat.verdict,
                }
                for stat in self.spot_stats(board.seed, board.random_ports).values()
            ]
            attempts_out = []
            for rank, attempt in enumerate(board.sorted_attempts(), 1):
                production, starting_cards, _, estimated_rounds = attempt_analysis(catan_map, attempt)
                (n1, e1), (n2, e2) = attempt.human_placements
                saved_matches = [
                    {
                        "index": sample.index,
                        "winner_seat": colors.index(sample.winner) if sample.winner is not None else -1,
                        "winner_color": COLOR_NAMES[sample.winner] if sample.winner is not None else None,
                        "turns": sample.turns,
                        "points": list(sample.points),
                        "players": [
                            {
                                "seat": st.seat,
                                "color": COLOR_NAMES[st.color],
                                "points": st.points,
                                "vp_cards": st.vp_cards,
                                "knights": st.knights,
                                "road_length": st.road_length,
                                "settlements": st.settlements,
                                "cities": st.cities,
                            }
                            for st in sample.player_stats(colors)
                        ],
                    }
                    for sample in attempt.samples
                ]
                attempts_out.append({
                    "rank": rank,
                    "seat": attempt.seat,
                    "seat_number": attempt.seat + 1,
                    "color": COLOR_NAMES[colors[attempt.seat]],
                    "dice_mode": attempt.dice_mode,
                    "dice_mode_label": DICE_MODES[attempt.dice_mode],
                    "wins": attempt.wins,
                    "decided": attempt.decided,
                    "limited": attempt.limited,
                    "win_percent": attempt.win_percent,
                    "verdict": attempt.verdict,
                    "wins_by_seat": list(attempt.wins_by_seat),
                    "next_index": attempt.next_index,
                    "updated_at": attempt.updated_at,
                    "estimated_rounds_to_10vp": estimated_rounds,
                    "production_per_36_rolls": production,
                    "starting_cards": starting_cards,
                    "human_settlements": [
                        {"order": 1, "node": n1, "road": list(e1), "description": describe_node(catan_map, n1)},
                        {"order": 2, "node": n2, "road": list(e2), "description": describe_node(catan_map, n2)},
                    ],
                    "opening_placements": [[node, list(edge)] for node, edge in attempt.opening_placements],
                    "saved_matches": saved_matches,
                })
            exported_boards.append({
                "seed": board.seed,
                "random_ports": board.random_ports,
                "ports_mode": "Zufällig" if board.random_ports else "Feste Anordnung",
                "updated_at": board.updated_at,
                "best_win_percent": round(board.best_win_rate * 100.0, 1) if board.best_win_rate is not None else None,
                "overall_wins": board.overall_wins,
                "overall_decided": board.overall_decided,
                "overall_limited": board.overall_limited,
                "overall_win_percent": (round(board.overall_win_rate * 100.0, 1)
                                        if board.overall_win_rate is not None else None),
                "tiles": tiles,
                "ports": ports,
                "tested_spots": spots,
                "attempts": attempts_out,
            })
        payload = {
            "format": "catan-opening-trainer-history",
            "version": SCHEMA_VERSION,
            "exported_at": exported_at or utc_now_iso(),
            "sort_mode": sort_mode,
            "thresholds": {
                "good_gt_percent": 50.0,
                "neutral_min_percent": 25.0,
            },
            "summary": {
                "boards_count": len(ordered_boards),
                "attempts_count": sum(len(b.attempts) for b in ordered_boards),
                "wins": total_wins,
                "decided": total_decided,
                "limited": total_limited,
                "win_percent": round(100.0 * total_wins / total_decided, 1) if total_decided > 0 else None,
            },
            "boards": exported_boards,
        }
        return json.dumps(payload, indent=2, ensure_ascii=False)

"""Hex-board geometry and touch hit testing, shared by rendering and tests."""

from __future__ import annotations

import math
from catanatron.models.enums import NodeRef
from catanatron.models.map import PORT_DIRECTION_TO_NODEREFS
from catanatron.models.tiles import Port

ANGLES = {ref: math.radians(-90 + 60 * i) for i, ref in enumerate(NodeRef)}


class BoardGeometry:
    def __init__(self, catan_map, width=600):
        self.width = width
        self.height = width * 0.91
        self.radius = width / 10.7
        self.cx, self.cy = width / 2, self.height / 2
        self.centers = {}
        self.nodes = {}
        for coord, tile in catan_map.land_tiles.items():
            q, _, r = coord
            x = self.cx + math.sqrt(3) * self.radius * (q + r / 2)
            y = self.cy + 1.5 * self.radius * r
            self.centers[coord] = (x, y)
            for ref, node in tile.nodes.items():
                a = ANGLES[ref]
                self.nodes[node] = (x + math.cos(a) * self.radius, y + math.sin(a) * self.radius)
        self.ports = []
        for tile in catan_map.tiles.values():
            if not isinstance(tile, Port):
                continue
            refs = PORT_DIRECTION_TO_NODEREFS[tile.direction]
            nodes = tuple(tile.nodes[ref] for ref in refs)
            ax, ay = self.nodes[nodes[0]]
            bx, by = self.nodes[nodes[1]]
            mx, my = (ax + bx) / 2, (ay + by) / 2
            dx, dy = mx - self.cx, my - self.cy
            norm = math.hypot(dx, dy)
            self.ports.append((tile.resource, nodes,
                               (mx + dx / norm * self.radius * 0.67,
                                my + dy / norm * self.radius * 0.67)))

    def midpoint(self, edge):
        a, b = (self.nodes[n] for n in edge)
        return ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)

    def hit(self, x, y, nodes, roads):
        targets = [(math.hypot(x - self.nodes[n][0], y - self.nodes[n][1]), "node", n) for n in nodes]
        targets += [(math.hypot(x - self.midpoint(e)[0], y - self.midpoint(e)[1]), "road", e) for e in roads]
        if not targets:
            return None
        distance, kind, value = min(targets, key=lambda t: t[0])
        # Legal intersections have >1 edge between them, so these touch targets
        # can be generous. Compare nodes and edge midpoints together to avoid
        # swallowing a road tap with its settlement's target.
        return (kind, value) if distance <= min(24, self.radius * 0.7) else None

"""An analytical resource-budget comparison, without playing future turns.

The reference plan adds four settlements, four city upgrades and eight roads
to the two starting settlements: four cities + two settlements = ten points.
Production stays fixed at its opening level. Fractional expected resources and
bank exchanges make this a mean-income benchmark, not E[time to win].
"""

from catanatron.models.enums import RESOURCES
from catanatron.models.map import PORT_DIRECTION_TO_NODEREFS


VICTORY_BUDGET = {"WOOD": 12, "BRICK": 12, "SHEEP": 4, "WHEAT": 12, "ORE": 12}


def opening_trade_ratios(catan_map, nodes):
    """Only ports actually touched by one of the starting settlements apply."""
    nodes = set(nodes)
    ratios = dict.fromkeys(RESOURCES, 4)
    for port in catan_map.ports_by_id.values():
        endpoints = {port.nodes[ref] for ref in PORT_DIRECTION_TO_NODEREFS[port.direction]}
        if not nodes.intersection(endpoints):
            continue
        if port.resource is None:
            ratios = {resource: min(ratio, 3) for resource, ratio in ratios.items()}
        else:
            ratios[port.resource] = 2
    return ratios


def resource_budget_rounds(production, hand, trade_ratios):
    """Rounds until mean opening income covers the reference construction bill.

`production` is cards per 36 rolls. Four rolls per round gives cards / 9.
Reserve each resource's own construction cost; exchange surplus at its port
ratio to cover deficits. The balance is monotone, so bisection solves its
piecewise-linear zero without random draws, turn stepping or game search.
"""
    def balance(rounds):
        available = {r: hand.get(r, 0) + production.get(r, 0) * rounds / 9 - VICTORY_BUDGET[r]
                     for r in RESOURCES}
        return sum(value / trade_ratios[r] if value > 0 else value for r, value in available.items())

    if balance(0) >= 0:
        return 0.0
    if not any(production.values()):
        return float("inf")
    low, high = 0.0, 1.0
    while balance(high) < 0:
        high *= 2
    for _ in range(48):
        mid = (low + high) / 2
        if balance(mid) < 0:
            low = mid
        else:
            high = mid
    return high

"""Catanatron adapter: opening transactions and independent game continuations."""

from __future__ import annotations

import asyncio
import copy
import random
import time
from collections import Counter
from dataclasses import dataclass, field
from typing import Callable, Literal

from catanatron import Game
from catanatron.models.enums import Action, ActionPrompt, ActionType, FastBuildingType, RESOURCES, SETTLEMENT, CITY, NodeRef
from catanatron.models.map import (
    BASE_MAP_TEMPLATE, BASE_NUMBERS_IN_SPIRAL_ORDER, CatanMap, initialize_tiles, PORT_DIRECTION_TO_NODEREFS,
)
from catanatron.models.player import Color
from catanatron.models.spiral import spiral_land_coordinates
from catanatron.players.minimax import AlphaBetaPlayer
from catanatron.state_functions import player_key
from trainer.ai import decide_cooperatively
from trainer.smart import EngineClient
from trainer.forecast import opening_trade_ratios, resource_budget_rounds


CORNERS = ((2, -2, 0), (2, 0, -2), (0, 2, -2),
           (-2, 2, 0), (-2, 0, 2), (0, -2, 2))
MAX_TURNS = 600
MAX_ACTIONS = 30_000
MAX_SIMULATIONS = 1000
DiceMode = Literal["deck36", "dice"]
DICE_MODES = {"deck36": "36er-Kartenstapel", "dice": "Normale Würfel"}
AI_DEPTH = 2
AI_NAME = "v89w · Tiefe 2 · max. 5 abgelehnte Angebote pro Zug · Entwicklungskarten"
DEV_NAMES = ("Ritter", "Erfindung", "Monopol", "Straßenbau", "Siegpunkt")
COLOR_NAMES = {Color.RED: "Rot", Color.BLUE: "Blau", Color.ORANGE: "Orange", Color.WHITE: "Weiß"}
RESOURCE_NAMES = {"WOOD": "Holz", "BRICK": "Lehm", "SHEEP": "Wolle", "WHEAT": "Getreide", "ORE": "Erz"}


class TrainingGame(Game):
    """The official victory condition applies on the winning player's turn."""

    def winning_color(self):
        color = self.state.colors[self.state.current_turn_index]
        key = player_key(self.state, color)
        return color if self.state.player_state[f"{key}_ACTUAL_VICTORY_POINTS"] >= self.vps_to_win else None

    def copy(self):
        result = super().copy()
        result.__class__ = TrainingGame
        return result


def create_game(seed: int, seat: int | None = None, random_ports: bool = False):
    rng = random.Random(seed)
    # Fixed ports use the BASE template's stable resource order; random ports
    # follow the variable-board option in the supplied 3D Almanac.
    ports = None if random_ports else list(reversed(BASE_MAP_TEMPLATE.port_resources))
    tiles = initialize_tiles(BASE_MAP_TEMPLATE, shuffled_port_resources_param=ports,
                             number_placement="random", rng=rng)
    corner = rng.choice(CORNERS)
    number_iter = iter(BASE_NUMBERS_IN_SPIRAL_ORDER)
    for coord in spiral_land_coordinates(tiles, corner):
        tile = tiles[coord]
        tile.number = next(number_iter) if tile.resource is not None else None
    # These players identify seats in the opening mirror. Rust chooses every
    # actual bot move; the mirror never calls their Python decision methods.
    game = TrainingGame([AlphaBetaPlayer(c, AlphaBetaPlayer.Params(depth=AI_DEPTH)) for c in Color], seed=seed ^ 0x19C47,
                        catan_map=CatanMap.from_tiles(tiles))
    seat = rng.randrange(4) if seat is None else seat
    if seat not in range(4):
        raise ValueError("Startplatz muss zwischen 1 und 4 liegen.")
    return game, game.state.colors[seat], seat, corner


@dataclass(frozen=True)
class BoardSnapshot:
    """Only the changing board pieces; the session already owns the static map."""

    roads: tuple[tuple[tuple[int, int], Color], ...]
    buildings: tuple[tuple[int, tuple[Color, FastBuildingType]], ...]
    robber_coordinate: tuple[int, int, int]

    @classmethod
    def from_board(cls, board):
        return cls(
            tuple(sorted((edge, color) for edge, color in board.roads.items() if edge[0] < edge[1])),
            tuple(sorted(board.buildings.items())),
            tuple(board.robber_coordinate),
        )

    @classmethod
    def from_engine(cls, result, catan_map, colors):
        coord = next(coord for coord, tile in catan_map.land_tiles.items() if tile.id == result["robber"])
        return cls(tuple(sorted((tuple(sorted((a, b))), colors[seat]) for a, b, seat in result["roads"])),
                   tuple(sorted((node, (colors[seat], CITY if city else SETTLEMENT))
                                for node, seat, city in result["buildings"])), coord)


@dataclass(frozen=True)
class Activity:
    cards_bought: tuple[int, ...] = (0, 0, 0, 0, 0)
    cards_played: tuple[int, ...] = (0, 0, 0, 0)
    player_trades: int = 0
    bank_trades: int = 0
    offers: int = 0

    @classmethod
    def from_engine(cls, data):
        return cls(tuple(data["cards_bought"]), tuple(data["cards_played"]),
                   data["player_trades"], data["bank_trades"], data["offers"])


@dataclass(frozen=True)
class Awards:
    largest_army: Color | None = None
    longest_road: Color | None = None
    knights: tuple[int, ...] = (0, 0, 0, 0)
    road_lengths: tuple[int, ...] = (0, 0, 0, 0)

    @classmethod
    def from_engine(cls, data, colors):
        return cls(colors[data["largest_army"]] if data["largest_army"] >= 0 else None,
                   colors[data["longest_road"]] if data["longest_road"] >= 0 else None,
                   tuple(data["knights"]), tuple(data["road_lengths"]))


@dataclass(frozen=True)
class PlayerMatchStats:
    seat: int
    color: Color
    points: int
    settlements: int
    cities: int
    knights: int
    road_length: int
    has_army: bool
    has_road: bool
    vp_cards: int
    knights_in_hand: int = 0
    yop_played: int = 0
    monopoly_played: int = 0
    road_building_played: int = 0


@dataclass(frozen=True)
class Sample:
    index: int
    seed: int
    winner: Color | None
    turns: int
    seconds: float
    points: tuple[int, ...]
    board: BoardSnapshot
    activity: Activity = field(default_factory=Activity)
    awards: Awards = field(default_factory=Awards)
    devs_in_hand: tuple[tuple[int, ...], ...] = ()
    devs_played: tuple[tuple[int, ...], ...] = ()

    @classmethod
    def from_engine_result(cls, index: int, seed: int, seconds: float, result: dict, catan_map, colors) -> Sample:
        winner = colors[result["winner"]] if result["winner"] >= 0 else None
        devs_in_hand = tuple(tuple(int(v) for v in row) for row in result.get("devs_in_hand", ()))
        devs_played = tuple(tuple(int(v) for v in row) for row in result.get("devs_played", ()))
        return cls(
            index=index,
            seed=seed,
            winner=winner,
            turns=result["turns"],
            seconds=seconds,
            points=tuple(result["points"]),
            board=BoardSnapshot.from_engine(result, catan_map, colors),
            activity=Activity.from_engine(result["activity"]),
            awards=Awards.from_engine(result["awards"], colors),
            devs_in_hand=devs_in_hand,
            devs_played=devs_played,
        )

    def player_stats(self, colors) -> tuple[PlayerMatchStats, ...]:
        settlement_counts = Counter()
        city_counts = Counter()
        for _, (owner, kind) in self.board.buildings:
            if kind == CITY:
                city_counts[owner] += 1
            else:
                settlement_counts[owner] += 1
        stats = []
        for seat, color in enumerate(colors):
            points = self.points[seat] if seat < len(self.points) else 0
            settlements = settlement_counts[color]
            cities = city_counts[color]
            in_hand = self.devs_in_hand[seat] if seat < len(self.devs_in_hand) else ()
            played = self.devs_played[seat] if seat < len(self.devs_played) else ()
            knights = max(
                self.awards.knights[seat] if seat < len(self.awards.knights) else 0,
                played[0] if len(played) > 0 else 0,
            )
            knights_in_hand = in_hand[0] if len(in_hand) > 0 else 0
            yop_played = played[1] if len(played) > 1 else 0
            monopoly_played = played[2] if len(played) > 2 else 0
            road_building_played = played[3] if len(played) > 3 else 0
            road_length = self.awards.road_lengths[seat] if seat < len(self.awards.road_lengths) else 0
            has_army = self.awards.largest_army == color
            has_road = self.awards.longest_road == color
            board_and_award_vp = settlements + 2 * cities + (2 if has_army else 0) + (2 if has_road else 0)
            vp_cards = (in_hand[4] + (played[4] if len(played) > 4 else 0)
                        if len(in_hand) > 4 else max(0, points - board_and_award_vp))
            stats.append(PlayerMatchStats(
                seat=seat,
                color=color,
                points=points,
                settlements=settlements,
                cities=cities,
                knights=knights,
                road_length=road_length,
                has_army=has_army,
                has_road=has_road,
                vp_cards=vp_cards,
                knights_in_hand=knights_in_hand,
                yop_played=yop_played,
                monopoly_played=monopoly_played,
                road_building_played=road_building_played,
            ))
        return tuple(stats)

    def to_storage_dict(self, colors) -> dict:
        color_to_seat = {color: idx for idx, color in enumerate(colors)}
        payload = {
            "index": self.index,
            "seed": self.seed,
            "winner": color_to_seat[self.winner] if self.winner is not None else -1,
            "turns": self.turns,
            "seconds": round(self.seconds, 2),
            "points": list(self.points),
            "robber": list(self.board.robber_coordinate),
            "roads": [[a, b, color_to_seat[c]] for (a, b), c in self.board.roads],
            "buildings": [[node, color_to_seat[c], 1 if kind == CITY else 0]
                          for node, (c, kind) in self.board.buildings],
            "activity": {
                "cards_bought": list(self.activity.cards_bought),
                "cards_played": list(self.activity.cards_played),
                "player_trades": self.activity.player_trades,
                "bank_trades": self.activity.bank_trades,
                "offers": self.activity.offers,
            },
            "awards": {
                "largest_army": (color_to_seat[self.awards.largest_army]
                                 if self.awards.largest_army is not None else -1),
                "longest_road": (color_to_seat[self.awards.longest_road]
                                 if self.awards.longest_road is not None else -1),
                "knights": list(self.awards.knights),
                "road_lengths": list(self.awards.road_lengths),
            },
        }
        if self.devs_in_hand:
            payload["devs_in_hand"] = [list(row) for row in self.devs_in_hand]
        if self.devs_played:
            payload["devs_played"] = [list(row) for row in self.devs_played]
        return payload

    @classmethod
    def from_storage_dict(cls, data: dict, colors) -> Sample:
        index = int(data["index"])
        seed = int(data["seed"])
        winner_idx = int(data.get("winner", -1))
        if winner_idx != -1 and not 0 <= winner_idx < len(colors):
            raise ValueError("Invalid winner seat")
        winner = None if winner_idx < 0 else colors[winner_idx]
        turns = int(data["turns"])
        seconds = float(data.get("seconds", 0.0))
        points = tuple(int(p) for p in data["points"])
        if len(points) != len(colors):
            raise ValueError("Invalid points length")
        robber_raw = tuple(int(v) for v in data["robber"])
        if len(robber_raw) != 3:
            raise ValueError("Invalid robber coordinate")
        roads = tuple(sorted(
            (tuple(sorted((int(a), int(b)))), colors[int(seat)])
            for a, b, seat in data["roads"]
        ))
        buildings = tuple(sorted(
            (int(node), (colors[int(seat)], CITY if int(is_city) else SETTLEMENT))
            for node, seat, is_city in data["buildings"]
        ))
        board = BoardSnapshot(roads=roads, buildings=buildings, robber_coordinate=robber_raw)
        act_raw = data.get("activity") or {}
        cards_bought = tuple(int(v) for v in act_raw.get("cards_bought", (0, 0, 0, 0, 0)))
        cards_played = tuple(int(v) for v in act_raw.get("cards_played", (0, 0, 0, 0)))
        if len(cards_bought) != 5 or len(cards_played) != 4:
            raise ValueError("Invalid activity counters")
        activity = Activity(
            cards_bought=cards_bought,
            cards_played=cards_played,
            player_trades=int(act_raw.get("player_trades", 0)),
            bank_trades=int(act_raw.get("bank_trades", 0)),
            offers=int(act_raw.get("offers", 0)),
        )
        aw_raw = data.get("awards") or {}
        army_idx = int(aw_raw.get("largest_army", -1))
        road_idx = int(aw_raw.get("longest_road", -1))
        if (army_idx != -1 and not 0 <= army_idx < len(colors)) or (
            road_idx != -1 and not 0 <= road_idx < len(colors)
        ):
            raise ValueError("Invalid award holder")
        knights = tuple(int(v) for v in aw_raw.get("knights", (0,) * len(colors)))
        road_lengths = tuple(int(v) for v in aw_raw.get("road_lengths", (0,) * len(colors)))
        if len(knights) != len(colors) or len(road_lengths) != len(colors):
            raise ValueError("Invalid award counts")
        awards = Awards(
            largest_army=None if army_idx < 0 else colors[army_idx],
            longest_road=None if road_idx < 0 else colors[road_idx],
            knights=knights,
            road_lengths=road_lengths,
        )
        devs_in_hand = tuple(tuple(int(v) for v in row) for row in data.get("devs_in_hand", ()))
        devs_played = tuple(tuple(int(v) for v in row) for row in data.get("devs_played", ()))
        if devs_in_hand and (len(devs_in_hand) != len(colors) or any(len(row) != 5 for row in devs_in_hand)):
            raise ValueError("Invalid devs_in_hand")
        if devs_played and (len(devs_played) != len(colors) or any(len(row) != 5 for row in devs_played)):
            raise ValueError("Invalid devs_played")
        return cls(
            index=index,
            seed=seed,
            winner=winner,
            turns=turns,
            seconds=seconds,
            points=points,
            board=board,
            activity=activity,
            awards=awards,
            devs_in_hand=devs_in_hand,
            devs_played=devs_played,
        )


@dataclass
class Results:
    samples: list[Sample] = field(default_factory=list)

    @property
    def wins(self):
        return Counter(s.winner for s in self.samples if s.winner is not None)

    @property
    def decided(self):
        return sum(s.winner is not None for s in self.samples)

    @property
    def limited(self):
        return len(self.samples) - self.decided


class OpeningSession:
    def __init__(self, seed: int | None = None, seat: int | None = None, random_ports=False,
                 dice_mode: DiceMode = "deck36"):
        self.seed = random.randrange(1, 2**31) if seed is None else seed
        self.random_ports = random_ports
        self.game, self.human, self.seat, self.corner = create_game(self.seed, seat, random_ports)
        self.selected_node: int | None = None
        self.selected_edge: tuple[int, int] | None = None
        self.history: list[TrainingGame] = []
        self.results = Results()
        self.initial_sample_index = 0
        self.dice_mode = dice_mode
        self.cancelled = False
        self.client = None
        self.ai_placements_cache: tuple[tuple[int, tuple[int, int]], ...] | None = None

    @property
    def dice_mode(self) -> DiceMode:
        return self._dice_mode

    @dice_mode.setter
    def dice_mode(self, value: DiceMode):
        if value not in DICE_MODES:
            raise ValueError("Unbekannter Würfelmodus.")
        if getattr(self, "_dice_mode", None) != value:
            self._dice_mode = value
            self.results = Results()
            self.initial_sample_index = 0

    def close(self):
        self.cancelled = True
        if self.client:
            self.client.close()
            self.client = None

    def cancel(self):
        self.cancelled = True
        if self.client:
            self.client.cancel()

    def engine_client(self):
        if self.client is None:
            self.client = EngineClient()
        return self.client

    def engine_position(self):
        """Preserve the exact existing board codes, topology and opening choices.

        Python keeps the small opening mirror for touch previews and undo. The
        Rust engine validates the opening and owns every complete continuation.
        """
        m = self.game.state.board.map
        resource = lambda r: -1 if r is None else RESOURCES.index(r)
        tiles = [{"resource": resource(m.tiles_by_id[i].resource), "number": m.tiles_by_id[i].number or 0,
                  "nodes": [m.tiles_by_id[i].nodes[ref] for ref in NodeRef]} for i in range(19)]
        ports = [{"resource": resource(p.resource),
                  "nodes": [p.nodes[ref] for ref in PORT_DIRECTION_TO_NODEREFS[p.direction]]}
                 for p in m.ports_by_id.values()]
        edges = sorted({tuple(sorted(edge)) for tile in m.land_tiles.values() for edge in tile.edges.values()})
        moves = []
        for record in self.game.state.action_records:
            a = record.action
            if a.action_type == ActionType.BUILD_SETTLEMENT:
                moves.append(("BUILD_SETTLEMENT", a.value, -1, -1))
            elif a.action_type == ActionType.BUILD_ROAD:
                moves.append(("BUILD_ROAD", edges.index(tuple(sorted(a.value))), -1, -1))
            else:
                raise ValueError("The opening contains a non-placement action")
        return {"op": "opening", "seed": str(self.seed), "board": {"tiles": tiles, "ports": ports}, "moves": moves}, edges

    async def sync_engine(self):
        position, edges = self.engine_position()
        result = await self.engine_client().request(**position)
        if result["current_player"] != self.game.state.color_to_index[self.game.state.current_color()]:
            raise RuntimeError("Opening turn differs between engines")
        if result["initial_phase"] != self.game.state.is_initial_build_phase:
            raise RuntimeError("Opening phase differs between engines")
        for i in range(4):
            hand = [self.game.state.player_state[f"P{i}_{r}_IN_HAND"] for r in RESOURCES]
            if result["hands"][i] != hand:
                raise RuntimeError("Opening resources differ between engines")
        return edges

    @property
    def complete(self):
        return not self.game.state.is_initial_build_phase

    @property
    def human_turn(self):
        return not self.complete and self.game.state.current_color() == self.human

    @property
    def legal_nodes(self):
        if not self.human_turn:
            return []
        return [a.value for a in self.game.playable_actions if a.action_type == ActionType.BUILD_SETTLEMENT]

    @property
    def legal_roads(self):
        if self.selected_node is None or not self.human_turn:
            return []
        preview = self.game.copy()
        preview.execute(Action(self.human, ActionType.BUILD_SETTLEMENT, self.selected_node))
        return [a.value for a in preview.playable_actions if a.action_type == ActionType.BUILD_ROAD]

    def select_node(self, node):
        if node not in self.legal_nodes:
            raise ValueError("Diese Kreuzung ist nicht frei oder verletzt die Abstandsregel.")
        self.selected_node = node
        self.selected_edge = None

    def select_road(self, edge):
        edge = tuple(sorted(edge))
        if edge not in self.legal_roads:
            raise ValueError("Die Straße muss an die gewählte Siedlung angrenzen.")
        self.selected_edge = edge

    def commit(self):
        if self.selected_node is None or self.selected_edge is None:
            raise ValueError("Wähle zuerst eine Siedlung und eine Straße.")
        if self.selected_node not in self.legal_nodes or self.selected_edge not in self.legal_roads:
            raise ValueError("Die Platzierung ist nicht mehr verfügbar.")
        self.history.append(copy.deepcopy(self.game))
        self.game.execute(Action(self.human, ActionType.BUILD_SETTLEMENT, self.selected_node))
        self.game.execute(Action(self.human, ActionType.BUILD_ROAD, self.selected_edge))
        self.selected_node = self.selected_edge = None
        self.results = Results()
        self.initial_sample_index = 0

    def undo(self):
        if not self.history:
            return False
        self.game = self.history.pop()
        self.selected_node = self.selected_edge = None
        self.results = Results()
        self.initial_sample_index = 0
        return True

    def opening_placements(self) -> tuple[tuple[int, tuple[int, int]], ...]:
        if not self.complete:
            raise ValueError("Die Eröffnung ist noch nicht fertig.")
        actions = [record.action for record in self.game.state.action_records]
        if len(actions) != 16:
            raise ValueError("Ungültige Anzahl an Eröffnungszügen.")
        placements = []
        for index in range(0, 16, 2):
            settlement, road = actions[index], actions[index + 1]
            if settlement.action_type != ActionType.BUILD_SETTLEMENT or road.action_type != ActionType.BUILD_ROAD:
                raise ValueError("Die Eröffnung enthält ungültige Züge.")
            edge = tuple(sorted(road.value))
            placements.append((int(settlement.value), (int(edge[0]), int(edge[1]))))
        return tuple(placements)

    async def advance_bots(self, on_step: Callable | None = None):
        while not self.complete and not self.human_turn:
            edges = await self.sync_engine()
            decision = await self.engine_client().request(op="choose")
            kind, value, _, _ = decision["action"]
            if kind == "BUILD_ROAD":
                value = edges[value]
            self.game.execute(Action(self.game.state.current_color(), ActionType(kind), value))
            if on_step:
                on_step()
            await asyncio.sleep(0.001)

    def human_ai_placements(self, placements: tuple[tuple[int, tuple[int, int]], ...]):
        """Extract the two snake-draft placements belonging to the human's seat."""
        if len(placements) != 8:
            raise ValueError("Ungültige Anzahl an Eröffnungszügen.")
        return (placements[self.seat], placements[7 - self.seat])

    async def compute_ai_opening_placements(self) -> tuple[tuple[int, tuple[int, int]], ...]:
        """Compute all 8 snake-draft opening placements chosen purely by the AI."""
        if self.ai_placements_cache is not None:
            return self.ai_placements_cache
        probe = OpeningSession(seed=self.seed, seat=self.seat, random_ports=self.random_ports,
                               dice_mode=self.dice_mode)
        probe.client = self.engine_client()
        try:
            while not probe.complete:
                edges = await probe.sync_engine()
                decision = await probe.engine_client().request(op="choose")
                kind, value, _, _ = decision["action"]
                if kind == "BUILD_ROAD":
                    value = edges[value]
                probe.game.execute(Action(probe.game.state.current_color(), ActionType(kind), value))
                await asyncio.sleep(0.001)
        except Exception:
            probe = OpeningSession(seed=self.seed, seat=self.seat, random_ports=self.random_ports,
                                   dice_mode=self.dice_mode)
            while not probe.complete:
                probe.game.execute(decide_cooperatively(probe.game))
        self.ai_placements_cache = probe.opening_placements()
        return self.ai_placements_cache

    def apply_opening_placements(self, placements: tuple[tuple[int, tuple[int, int]], ...]):
        """Reset opening to step 0 on this board/seat and apply all 8 placements."""
        if len(placements) != 8:
            raise ValueError("Ungültige Anzahl an Eröffnungszügen.")
        self.cancel()
        fresh_game, self.human, self.seat, self.corner = create_game(self.seed, self.seat, self.random_ports)
        self.game = fresh_game
        self.selected_node = None
        self.selected_edge = None
        self.history = []
        self.results = Results()
        self.initial_sample_index = 0
        for node, edge in placements:
            color = self.game.state.current_color()
            self.game.execute(Action(color, ActionType.BUILD_SETTLEMENT, int(node)))
            self.game.execute(Action(color, ActionType.BUILD_ROAD, tuple(sorted(edge))))

    def victory_rounds_for_spots(self, node1: int, node2: int):
        board_map = self.game.state.board.map
        prod = dict.fromkeys(RESOURCES, 0)
        for node in (node1, node2):
            for tile in board_map.adjacent_tiles[node]:
                if tile.resource:
                    prod[tile.resource] += 6 - abs(7 - tile.number)
        hand = Counter(tile.resource for tile in board_map.adjacent_tiles[node2]
                       if tile.resource is not None)
        return resource_budget_rounds(prod, hand, opening_trade_ratios(board_map, [node1, node2]))

    def production(self, include_selected=False):
        nodes = list(self.game.state.buildings_by_color[self.human][SETTLEMENT])
        if include_selected and self.selected_node is not None:
            nodes.append(self.selected_node)
        result = dict.fromkeys(RESOURCES, 0)
        for n in nodes:
            for tile in self.game.state.board.map.adjacent_tiles[n]:
                if tile.resource:
                    result[tile.resource] += 6 - abs(7 - tile.number)
        return result

    def starting_resources(self):
        key = player_key(self.game.state, self.human)
        return {r: self.game.state.player_state[f"{key}_{r}_IN_HAND"] for r in RESOURCES}

    def victory_rounds_preview(self):
        """Use every known starting spot, including an unconfirmed selection.

        With only one spot, the second free settlement's production and start
        cards are still unknown. Keep the same reference budget and use only
        the first spot's income/port for a provisional comparison.
        """
        nodes = list(self.game.state.buildings_by_color[self.human][SETTLEMENT])
        if self.selected_node is not None:
            nodes.append(self.selected_node)
        if not nodes:
            return None
        hand = self.starting_resources()
        if len(nodes) == 2 and self.selected_node is not None:
            hand = Counter(tile.resource for tile in self.game.state.board.map.adjacent_tiles[self.selected_node]
                           if tile.resource is not None)
        return resource_budget_rounds(self.production(include_selected=True), hand,
                                      opening_trade_ratios(self.game.state.board.map, nodes))

    def simulation_game(self, index):
        if not self.complete:
            raise ValueError("Die Eröffnung ist noch nicht fertig.")
        # Game.copy deliberately shares the RNG; deep-copy the opening here
        # instead so neither simulations nor undo alter another run.
        game = copy.deepcopy(self.game)
        seed = (self.seed * 1_000_003 + index * 97_409 + 0xCA7A) & 0xFFFFFFFFFFFFFFFF
        game.random = random.Random(seed)
        game.state.random = game.random
        game.random.shuffle(game.state.development_listdeck)
        return game, seed

    async def simulate(self, count: int, on_progress: Callable | None = None,
                       max_turns=MAX_TURNS, max_actions=MAX_ACTIONS):
        if not 1 <= count <= MAX_SIMULATIONS:
            raise ValueError(f"Wähle 1 bis {MAX_SIMULATIONS} Simulationen.")
        if not self.complete:
            raise ValueError("Platziere zuerst beide Siedlungen und Straßen.")
        self.cancelled = False
        await self.sync_engine()
        # A cancelled parallel batch can leave gaps. Never repeat a completed
        # game's index/seed when the user asks for additional simulations.
        initial = max(self.initial_sample_index,
                      max((sample.index + 1 for sample in self.results.samples), default=0))
        if self.cancelled:
            return
        if self.engine_client().browser:
            await self._simulate_browser(initial, count, on_progress, max_turns, max_actions)
            return
        for offset in range(count):
            index = initial + offset
            seed = (self.seed * 1_000_003 + index * 97_409 + 0xCA7A) & 0xFFFFFFFFFFFFFFFF
            started = time.perf_counter()
            last_update = started
            result = await self.engine_client().request(op="begin", seed=str(seed), dice_mode=self.dice_mode,
                                                        max_turns=max_turns, max_actions=max_actions)
            while not result["done"]:
                if self.cancelled:
                    return
                result = await self.engine_client().request(op="step", count=24)
                if self.cancelled:
                    return
                now = time.perf_counter()
                if on_progress and now - last_update >= 0.2:
                    on_progress(offset, count, result["turns"])
                    last_update = now
                await asyncio.sleep(0.001)
            if self.cancelled:
                return
            colors = self.game.state.colors
            self.results.samples.append(Sample.from_engine_result(
                index, seed, time.perf_counter() - started, result, self.game.state.board.map, colors,
            ))
            if on_progress:
                on_progress(offset + 1, count, 0)
            await asyncio.sleep(0.001)

    async def _simulate_browser(self, initial, count, on_progress, max_turns, max_actions):
        jobs = [{"index": index,
                 "seed": str((self.seed * 1_000_003 + index * 97_409 + 0xCA7A) & 0xFFFFFFFFFFFFFFFF)}
                for index in range(initial, initial + count)]
        colors = self.game.state.colors

        def receive(event):
            if event["event"] == "completed":
                result = event["result"]
                self.results.samples.append(Sample.from_engine_result(
                    event["index"], int(event["seed"]), event["seconds"], result,
                    self.game.state.board.map, colors,
                ))
                self.results.samples.sort(key=lambda sample: sample.index)
            if on_progress:
                on_progress(event["done"], count, event.get("turns", 0))

        result = await self.engine_client().request(op="batch", opening=self.engine_position()[0],
            jobs=jobs, dice_mode=self.dice_mode, max_turns=max_turns, max_actions=max_actions, on_event=receive)
        self.cancelled = self.cancelled or result["cancelled"]

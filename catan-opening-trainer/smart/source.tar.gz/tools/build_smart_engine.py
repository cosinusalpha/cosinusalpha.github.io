"""Build the pinned Rust runner and/or browser engine without training dependencies."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
ENGINE = ROOT / "vendor/smart_engine"
BUILD = ROOT / "build"


def main():
    meta = json.loads((ENGINE / "models/v89w.json").read_text())
    weights = (ENGINE / "models/v89w.bin").read_bytes()
    if len(weights) != meta["bytes"] or hashlib.sha256(weights).hexdigest() != meta["sha256"]:
        raise SystemExit("v89w model checksum mismatch")
    env = {**os.environ, "CARGO_TARGET_DIR": str(BUILD / "rust-target")}
    if "--web" in sys.argv:
        env["RUSTFLAGS"] = "-C target-feature=+simd128"
        subprocess.run(["wasm-pack", "build", str(ENGINE), "--release", "--target", "web",
                        "--out-dir", str(BUILD / "smart-engine"), "--no-default-features", "--features", "wasm"],
                       env=env, check=True)
    else:
        subprocess.run(["cargo", "build", "--locked", "--release", "--manifest-path", str(ENGINE / "Cargo.toml"),
                        "--no-default-features", "--features", "trainer", "--bin", "trainer-engine"], env=env, check=True)


if __name__ == "__main__":
    main()

"""Stage a browser benchmark; optionally retain an older smart/ build as baseline."""
import argparse
import json
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from trainer.engine import OpeningSession


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", type=Path, help="An older dist/smart directory (before rebuilding)")
    args = parser.parse_args()
    target = ROOT / "build/browser-benchmark"
    smart = target / "smart"
    smart.mkdir(parents=True, exist_ok=True)
    for source in (ROOT / "web/smart").glob("*.js"):
        shutil.copyfile(source, smart / source.name)
    for name in ("catan_engine.js", "catan_engine_bg.wasm"):
        shutil.copyfile(ROOT / "build/smart-engine" / name, smart / name)
    for name in ("v89w.bin", "v89w.json"):
        shutil.copyfile(ROOT / "vendor/smart_engine/models" / name, smart / name)
    if args.baseline:
        shutil.copytree(args.baseline, target / "baseline", dirs_exist_ok=True)
    fixtures = []
    for seed in (20261012, 83):
        session = OpeningSession(seed, 0)
        opening = session.engine_position()[0]
        # Deterministic legal placements isolate continuation performance from
        # changes in opening choices. The first fixture produces many trades.
        while not session.complete:
            session.game.execute(session.game.playable_actions[0])
        fixtures.append({"seed": seed, "opening": opening, "complete": session.engine_position()[0]})
    (target / "fixtures.json").write_text(json.dumps(fixtures))
    shutil.copyfile(ROOT / "tools/browser_benchmark.html", target / "index.html")
    print(f"Staged {target}")
    print("Serve the repository, then open /build/browser-benchmark/ in the target browser.")


if __name__ == "__main__":
    main()

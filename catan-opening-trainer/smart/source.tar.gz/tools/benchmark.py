"""Measure real complete-game continuations, not a rules-engine-only microbenchmark."""
import asyncio
import json
from pathlib import Path
import sys
import time

sys.path.insert(0,str(Path(__file__).resolve().parents[1] / "src"))
from trainer.engine import OpeningSession


async def main():
    session = OpeningSession(20261012,0)
    started = time.perf_counter()
    await session.advance_bots()
    while not session.complete:
        session.select_node(session.legal_nodes[0])
        session.select_road(session.legal_roads[0])
        session.commit()
        await session.advance_bots()
    opening_seconds = time.perf_counter() - started
    count = int(sys.argv[1]) if len(sys.argv) > 1 else 5
    await session.simulate(count)
    print(json.dumps({"environment":"native CPython; not an Android/browser measurement",
        "dice_mode":session.dice_mode,
        "opening_seconds":round(opening_seconds,3),"count":count,"decided":session.results.decided,
        "simulation_seconds":round(sum(s.seconds for s in session.results.samples),3),
        "games":[{"winner":s.winner.value if s.winner else None,"turns":s.turns,"seconds":round(s.seconds,3),
                  "cards_bought":list(s.activity.cards_bought),"cards_played":list(s.activity.cards_played),
                  "player_trades":s.activity.player_trades,"bank_trades":s.activity.bank_trades,
                  "offers":s.activity.offers}
                 for s in session.results.samples]},indent=2))
    session.close()


if __name__ == "__main__":
    asyncio.run(main())

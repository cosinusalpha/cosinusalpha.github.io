"""Build the Flet/Pyodide static app for the shared GitHub Pages subfolder."""
from pathlib import Path
import subprocess
import shutil
import sys
import tarfile
import tempfile

ROOT = Path(__file__).resolve().parents[1]
DIST = ROOT / "dist"


def main():
    subprocess.run([sys.executable, str(ROOT / "tools/build_smart_engine.py"), "--web"], cwd=ROOT, check=True)
    # Flet publish includes nested bytecode caches. Stage source explicitly so
    # tests/local runs do not bloat or contaminate the browser application.
    with tempfile.TemporaryDirectory(prefix="catan-web-") as temp:
        source = Path(temp) / "app"
        shutil.copytree(ROOT / "src", source,
                        ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.pyo"))
        for name in ("LICENSE", "NOTICE.md"):
            shutil.copyfile(ROOT / name, source / name)
        result = subprocess.run([
            sys.executable, "-c", "from flet.cli import main; raise SystemExit(main())",
            "publish", str(source / "main.py"),
            "--python-version", "3.12", "--distpath", str(DIST),
            "--base-url", "/catan-opening-trainer/", "--route-url-strategy", "hash",
            "--web-renderer", "canvaskit", "--app-name", "Catan Eröffnungstrainer",
            "--app-short-name", "Catan Trainer", "--app-description", "Übe deine CATAN-Eröffnung auf dem Handy.",
            "--pwa-background-color", "#101923", "--pwa-theme-color", "#101923",
        ], cwd=ROOT)
    if result.returncode:
        raise SystemExit(result.returncode)
    index = (DIST / "index.html").read_text()
    if '<base href="/catan-opening-trainer/">' not in index:
        raise SystemExit("Flet build did not apply the required Pages base URL.")
    with tarfile.open(DIST / "app.tar.gz") as archive:
        names = {m.name.lstrip("./") for m in archive.getmembers()}
        if any("__pycache__" in n or n.endswith(".pyc") for n in names):
            raise SystemExit("Unexpected bytecode cache in the browser build.")
        for required in ("main.py", "trainer/engine.py", "trainer/forecast.py", "catanatron/game.py", "requirements.txt"):
            if required not in names:
                raise SystemExit(f"Missing browser application module: {required}")
    (DIST / ".nojekyll").touch()
    smart = DIST / "smart"
    smart.mkdir(exist_ok=True)
    for name in ("catan_engine.js", "catan_engine_bg.wasm"):
        shutil.copyfile(ROOT / "build/smart-engine" / name, smart / name)
    for source_file in (ROOT / "web/smart").glob("*.js"):
        shutil.copyfile(source_file, smart / source_file.name)
    for name in ("v89w.bin", "v89w.json"):
        shutil.copyfile(ROOT / "vendor/smart_engine/models" / name, smart / name)
    # Publish the exact source/build recipe beside the compiled engine.
    with tarfile.open(smart / "source.tar.gz", "w:gz") as source_archive:
        for name in ("src", "vendor/smart_engine", "web/smart", "tools", "tests",
                     "pyproject.toml", "README.md", "NOTICE.md", "LICENSE"):
            source_archive.add(ROOT / name, arcname=name,
                               filter=lambda member: None if "__pycache__" in member.name or member.name.endswith(".pyc") else member)
    print(f"Web build verified: {DIST}")


if __name__ == "__main__":
    main()

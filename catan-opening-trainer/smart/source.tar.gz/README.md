# Catan Opening Trainer

Ein mobiler Eröffnungstrainer: Platziere zwei Siedlungen und angrenzende Straßen
in der regulären Reihenfolge. Anschließend übernimmt die gelernte v89w-KI (Tiefe 2)
alle vier Plätze und spielt die eingestellte Anzahl vollständiger Partien.

Adresse: **https://cosinusalpha.github.io/catan-opening-trainer/**

## Bedienung

1. Ein Brett und dein Startplatz werden zufällig gewählt. Die Computer platzieren
   bis zu deinem Zug.
2. Tippe auf eine helle Kreuzung und dann auf einen angrenzenden Straßenpunkt.
   Erst **Platzierung bestätigen** setzt beide Figuren.
3. Wiederhole dies für deine zweite Siedlung. Startkarten kommen nur aus dieser
   zweiten Siedlung.
4. Wähle **1–1000 Simulationen**, Standard **5**. Die Schnellwahl bietet
   1, 5, 10, 25, 50 und 100.
5. **Weitere simulieren** ergänzt neue unabhängige Partien. **Stoppen** erhält
   abgeschlossene Ergebnisse. **Dieses Brett erneut** wiederholt dasselbe Brett
   und denselben Startplatz; der vorige Versuch bleibt als Vergleich sichtbar.

**Zurück** nimmt deine letzte bestätigte Platzierung samt folgenden
Computerplatzierungen zurück. Der Brett-Code lädt ein Brett reproduzierbar.
Startplatz- und Hafeneinstellungen gelten für das nächste neue Brett.

Der Schalter **Wahrscheinlichkeitspunkte** blendet die Punkte unter den Zahlen
auf beiden Brettern ein oder aus. Er startet eingeschaltet und behält seine
Einstellung bis zum Neuladen der Seite.

Unter **Endstand einer Partie** kannst du jede abgeschlossene Simulation wählen.
Das Ergebnisbrett zeigt die finalen Straßen, Siedlungen, Städte und den Räuber
sowie den Sieger und die Siegpunkte aller vier Spieler. Städte sind Häuser mit
einem Punkt; **R** markiert den Räuber auf einem Zahlenfeld. Auch Partien ohne
Sieger am Simulationslimit sind auswählbar. Dein Eröffnungsbrett bleibt darüber
erhalten. Weitere Simulationen ändern die gewählte Partie nicht; eine geänderte
Eröffnung oder ein neues Brett löscht die bisherigen Endstände.

Zu jeder Partie stehen die tatsächlich gekauften und gespielten Entwicklungskarten,
abgeschlossene Spieler-Handelsgeschäfte, Bank-/Hafenhandel und die Zahl der Angebote.
Siegpunktkarten zählen zu den gekauften Karten und zu den finalen Siegpunkten.

## Regeln und Auswertung

- 4 Spieler, 10 Siegpunkte, Abstandsregel und Reihenfolge
  `1–2–3–4–4–3–2–1`.
- Gelände zufällig; Zahlen `5,2,6,3,8,10,9,12,11,4,8,10,9,4,5,6,3,11`
  gegen den Uhrzeigersinn von einer zufälligen der sechs Ecken, Wüste überspringen.
- Feste Häfen nutzen Catanatrons BASE-Template in einer stabilen Anordnung;
  sie sind kein Nachbau eines bestimmten gedruckten Hafenrahmens. Zufällige Häfen
  sind als variable Variante wählbar.
- Alle vier Plätze nutzen das gelernte v89w-Modell mit Expectimax-Suche der Tiefe 2.
  Auch die Computer-Eröffnungen nutzen dieses Modell.
  Angezeigt werden tatsächlich simulierte Siege, keine heuristisch geschätzten
  Gewinnwahrscheinlichkeiten.
- Die KI nutzt Spieler-, Bank- und Hafenhandel und kauft und spielt Entwicklungskarten.
  Die Konfiguration entspricht `vnets3w40a99x`: 40 Angebote werden genau bewertet;
  die besten drei erwarteten akzeptablen Angebote sowie ein optimistisches Angebot
  konkurrieren in der Suche mit Bauen und anderen Aktionen. Antworten und die Wahl
  des Handelspartners bewertet die KI aus der eigenen Perspektive. Die Simulation
  nutzt damit die stärkere Feilsch-Variante des Projekts.
- Entwicklungskarten: Ritter, Erfindung, Monopol, Straßenbau und Siegpunktkarten.
  Höchstens eine spielbare Entwicklungskarte pro Zug, nicht im Kaufzug; Siegpunktkarten
  werden automatisch gezählt. Die KI entscheidet selbst über Käufe und Einsatz.
- Eine von allen abgelehnte oder vom Anbieter abgebrochene Offerte kann im selben Zug
  nicht wiederholt werden. Diese Hausregel stammt aus dem eingebundenen Engine-Fork.
- Die Ergebnisse bewerten die Eröffnung unter dieser Bot-Policy, nicht eine garantierte
  optimale menschliche Spielweise.
- Jeder Durchlauf bekommt einen eigenen Zufallsstrom und eine neu gemischte
  Entwicklungskartenfolge. Ein Vergleichsversuch nutzt dieselben Seed-Indizes;
  unterschiedliche Spielaktionen können trotzdem andere Würfelfolgen verursachen.
- Bei 600 Zügen oder 30.000 Aktionen wird eine Partie abgebrochen. Solche Partien
  werden getrennt ausgewiesen und zählen nicht als Niederlagen.

## Lokal starten

Python 3.12, [uv](https://docs.astral.sh/uv/) und Rust stable installieren:

```bash
uv sync --group dev
uv run python tools/build_smart_engine.py
uv run flet run src/main.py --web
```

Die lokale Web-Entwicklung führt Python auf deinem Rechner aus. Die veröffentlichte
statische Flet-Version führt Python mit Pyodide direkt im Browser aus. Ein eigener
Web Worker führt Rust-Regeln, Suche und Modell als WebAssembly aus; die Oberfläche
bleibt während der Simulation bedienbar. PyTorch, ein Server oder Training werden
nicht benötigt. Die Desktop-Version nutzt denselben Rust-Code als Prozess.

Für den Web-Build zusätzlich `wasm-pack` und das Rust-WASM-Target installieren:

```bash
uv run pytest -q
uv run python tools/benchmark.py 5
rustup target add wasm32-unknown-unknown
cargo install wasm-pack --locked --version 0.15.0
uv run python tools/build_web.py
```

Der statische Build liegt in `dist/`; seine Basis-URL ist
`/catan-opening-trainer/`. Der Build prüft diese URL, die Python-Module und die Prüfsumme des Modells.

## GitHub Pages

`.github/workflows/web.yml` testet und baut nach jedem Push auf `main`. Der Build
wird immer als Actions-Artefakt **catan-opening-trainer-web** gespeichert.

Zur automatischen Veröffentlichung in das gemeinsame Repo
`cosinusalpha/cosinusalpha.github.io` braucht dieses private Quellcode-Repo ein
Actions-Secret **GH_PAGES_TOKEN** mit Schreibrecht auf das Pages-Repo. Dies ist
derselbe Secret-Name wie bei den vorhandenen Apps. Secrets anderer Repositories
werden von GitHub nicht automatisch übernommen.

Der Publish-Schritt synchronisiert ausschließlich `catan-opening-trainer/`.
Andere Apps und die Startseite bleiben erhalten. Ein fehlendes Secret wird als
Notice gemeldet; dann wird nur das Web-Artefakt erstellt.

Nach dem Einrichten des Secrets kann der Workflow unter **Actions → Test, build
and publish Catan Trainer → Run workflow** erneut gestartet werden.

Das Ziel ist die mobile Browser-Version; ein APK benötigt einen eigenen Rust-Adapter.

## Herkunft und Lizenz

Catanatron und der Rust-/v89w-Fork sind mit festen Ständen eingebunden; Details stehen in
[NOTICE.md](NOTICE.md). Der Code wird unter GPL-3.0-or-later bereitgestellt.
Es werden keine offiziellen CATAN-Grafiken oder Regelbuchdateien verteilt.

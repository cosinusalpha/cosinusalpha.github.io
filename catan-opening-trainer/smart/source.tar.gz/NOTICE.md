# Catanatron snapshot

`src/catanatron` contains the pure Python core and players of
[bcollazo/catanatron](https://github.com/bcollazo/catanatron), pinned to commit
`ecf931181b9a65bb4116a2153fb78c16f1438e00` (version 3.3.0).

The source files are unmodified. Optional `gym`, `web`, and `cli` modules are
omitted because the trainer uses its own Flet interface. The upstream GPL-3.0
license is included in `src/catanatron/LICENSE` and the repository root.

Vendoring the small Python core keeps the browser package reproducible and
avoids depending on older PyPI releases. Runtime dependencies are pinned in
`src/requirements.txt`.

The adapter in `src/trainer/engine.py` preserves randomized number-spiral corners,
opening transactions and an opening mirror for touch previews/undo. Rust validates
the exact board and opening; all bot decisions and full continuations use the
pinned v89w model and rules engine from the user's `settlers_of_catan_rl` fork.
Each simulation has an independent RNG and development-card deck.

`vendor/smart_engine/UPSTREAM.md` records the Rust engine's source commit,
model checksum, attribution and local adapter changes. The model and engine
run in WebAssembly in a separate browser worker, or the same native Rust runner
for desktop development. The model's search is depth 2 with `vnets3w40a99x`
trading; results and card/trade counters record actual completed games.

The author of Catanatron is Bryan Collazo; additional contributors are credited
in the upstream repository. The trainer is an independent personal project.
